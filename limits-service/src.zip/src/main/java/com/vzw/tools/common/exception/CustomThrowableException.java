package com.vzw.tools.common.exception;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
public class CustomThrowableException extends RuntimeException{
    private final String errorMessage;
    private final Throwable cause;

    public CustomThrowableException(String errorMessage){
        super(errorMessage);
        this.errorMessage = errorMessage;
        this.cause = null;
    }

    public CustomThrowableException(String errorMessage, Throwable cause){
        super(errorMessage, cause);
        this.errorMessage = errorMessage;
        this.cause = cause;
    }


}
