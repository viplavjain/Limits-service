
package com.vzw.tools.helpers.logging.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MaskUtil {
    private static final Logger logger = LoggerFactory.getLogger(MaskUtil.class);
    private static String[] globalSensitiveFields = new String[]{"ssn", "pin", "federalTaxId", "birthDate", "dateOfBirth", "taxId", "cardNumber", "cardType", "expiryMonth", "expiryYear", "expireDate", "cardExpiryDate", "cardUniqueid", "cardTypeDesc", "cardExpDate", "password"};

    public MaskUtil() {
    }

    public static String scrubJson(String jsonString, String pSensitiveDataFields) {
        try {
            if (null != jsonString) {
                int var4;
                String[] sensitiveDataFields;
                if (null != globalSensitiveFields) {
                    sensitiveDataFields = globalSensitiveFields;
                    int var3 = sensitiveDataFields.length;

                    for(var4 = 0; var4 < var3; ++var4) {
                        String sensitiveField = sensitiveDataFields[var4];
                        jsonString = LogScruberUtilities.removeJSONValue(sensitiveField, jsonString);
                    }
                }

                if (null != pSensitiveDataFields) {
                    sensitiveDataFields = pSensitiveDataFields.trim().split(",");
                    String[] var9 = sensitiveDataFields;
                    var4 = sensitiveDataFields.length;

                    for(int var10 = 0; var10 < var4; ++var10) {
                        String sensitiveField = var9[var10];
                        jsonString = LogScruberUtilities.removeJSONValue(sensitiveField, jsonString);
                    }
                }
            }

            return jsonString;
        } catch (Exception var7) {
            Exception exception = var7;
            logger.error("Error while scrub the json sensitive Data Fields {}", exception.getMessage());
            return jsonString;
        }
    }
}
