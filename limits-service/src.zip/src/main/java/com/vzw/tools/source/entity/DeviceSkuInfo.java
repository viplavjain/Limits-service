package com.vzw.tools.source.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class DeviceSkuInfo {

    private String deviceSku;
    private String virtualSimSku;
    private String skuType;
    private String prodCode1;
    private String prodCode2;
    private String prodCode3;
    private String prodCode4;
    private String prodCode5;
    private String btaEligiblity;
    private String upcCode;
    private String prepaySkuInd;
    private String edgeEligibleInd;
    private String edgeDpcGroup;
    private String edgeDpcItem;
    private String itemCost;
    private String imEquipID;
    private String upcCodeFull;
    private String edgeDeviceCap;
    private String instantCredit;
    private String ispuEligible;
    private String prop65;
    private PairedSkuInfo pairedSkuInfo;


}