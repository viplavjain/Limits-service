package com.vzw.tools.common.health;

import com.vzw.tools.common.constant.CommonConstants;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MemoryInfoBean {

    private long maxMemory;
    private long usedMemory;
    private long totalMemory;
    private long freeMemory;
    private long totalFreeMemory;
    private boolean isOutOfMemory;
    private long thresholdMemory;

    public static MemoryInfoBean getMemoryInfoBean() {
        Runtime runtime = Runtime.getRuntime();
        MemoryInfoBean memoryInfoBean = new MemoryInfoBean();
        long maxMemory = runtime.maxMemory();
        long totalMemory = runtime.totalMemory();
        long freeMemory = runtime.freeMemory();
        long usedMemory = totalMemory - freeMemory;
        long totalFreeMemory = maxMemory - usedMemory;
        long thresholdMemory = (long) Math.ceil(CommonConstants.MEMORY_THRESHOLD_PERCENT * totalMemory);
        memoryInfoBean.setMaxMemory(maxMemory);
        memoryInfoBean.setTotalMemory(totalMemory);
        memoryInfoBean.setFreeMemory(freeMemory);
        memoryInfoBean.setUsedMemory(usedMemory);
        memoryInfoBean.setTotalFreeMemory(totalFreeMemory);
        memoryInfoBean.setThresholdMemory(thresholdMemory);
        if (usedMemory > thresholdMemory) {
            memoryInfoBean.setOutOfMemory(true);
        }
        return memoryInfoBean;
    }

}
