package com.vzw.tools.persistence.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Getter
@Setter
@ToString
public class DeviceCassandraDto {

    private String displayName;
    private String sorId;
    private String imEquipId;
    private String upcCode;
    private String upcCodeFull;
    private String instorepickupflag;
    private String sorDisplayName;
    private String carrier;
    private String postpaidRestrictDate;
    private String prepaidRestrictDate;
    private String billToAccountEligibleFlag;
    private String edgeDeviceCap;
    private String edgeDPc;
    private String edgeDpcGroup;
    private String edgeEligibilityInd;
    private String imImageUrl;
    private String instantCredit;
    private String itemCost;
    private String sorPIBIndicator;
    private String prodCode1;
    private String prodCode2;
    private String prodCode3;
    private String prodCode4;
    private String prodCode5;
    private String prop65;
    private String sorProductFamily;
    private String sorSkuType;
    private String h1Tag;
    private String pairedImeiSku;
    private String manufacturer;
    private String globalReadyFlag;
    private String sorDeviceType;
    private String sorDeviceCategory;
    private String backupAssistCapableFlag;
    private String buddyUpgrdEligInd;
    private String dacc;
    private String deviceCapabilityInd;
    private String dsdsCapable;
    private String deviceFamilyType;
    private String hdVoiceInd;
    private String sorIMDeviceCategory;
    private String nfcCapableFlag;
    private String nfcCompatibleFlag;
    private String preferredSim;
    private String preferredSoftSim;
    private String alternateSim;
    private String restrictToFamilyInd;
    private String simClass4g;
    private String smsCapableFlag;
    private String wifiCallingInd;
    private String cdmaCapable;
    private String gsmCapable;
    private String eligibleNumShareOS;
    private String euiccCapable;
    private String numberShareCapable;
    private String vendorKey;
    private String v4b;
    private String e911AddrInd;
    private String virtualSimSku;
    private String esimOnly;
    private List<String> productSpecificationRelationship;
    private String sorFamilyName;
    private String operatingSystem;
    private List<String> productUniversalAccessories;
    private String universalFlag;
    private String seoUrlName;
    private String h1;
    private String FRP;
    private String CP12;
    private String CP24;
    private String PP;
    private String EFRP;
    private String SOR;
}