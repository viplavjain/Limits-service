package com.vzw.tools.persistence.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "spring.federateddatasource")
public class FederatedDBProperties {

    private String url;
    private String userName;
    private String password;

}
