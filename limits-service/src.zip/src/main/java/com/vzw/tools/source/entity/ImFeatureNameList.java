package com.vzw.tools.source.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
public class ImFeatureNameList {
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonProperty("imFeatureName")
    private List<String> imFeatureName;
}
