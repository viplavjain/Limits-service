package com.vzw.tools.common.exception;

public class FCToolsMSException extends Exception {
    private String code;
    private ErrorResponse errorResponse;

    public FCToolsMSException() {
    }

    public FCToolsMSException(String code, ErrorResponse errorResponse) {
        this.code = code;
        this.errorResponse = errorResponse;
    }

    public FCToolsMSException(String code, ErrorResponse errorResponse, String message) {
        super(message);
        this.code = code;
        this.errorResponse = errorResponse;
    }

    public FCToolsMSException(String message, String code) {
        super(message);
        this.setCode(code);
    }

    public FCToolsMSException(Throwable cause) {
        super(cause);
    }

    public FCToolsMSException(String message, String code, Throwable cause) {
        super(message, cause);
        this.setCode(code);
    }

    public FCToolsMSException(String message, String code, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
        this.setCode(code);
    }

    public FCToolsMSException(ErrorResponse errorResponse) {
        this.errorResponse = errorResponse;
    }

    public String getCode() {
        return this.code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public ErrorResponse getErrorResponse() {
        return this.errorResponse;
    }

    public void setErrorResponse(ErrorResponse errorResponse) {
        this.errorResponse = errorResponse;
    }

    public String toString() {
        return "FCToolsMSException [code=" + this.code + ", errorResponse=" + this.errorResponse + "]";
    }
}
