package com.vzw.tools.source.dao;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;


@Getter
@Setter
@ToString
public class DeviceDPIDAO {

    private String sku;
    private String skuType;
    private BigDecimal oneYearPrice;
    private BigDecimal twoYearPrice;
    private BigDecimal prepayPrice;
    private BigDecimal fullRetailPrice;
    private String locationCode;
    private String edgeSku;
    private BigDecimal edgeFullRetailPrice;
}

