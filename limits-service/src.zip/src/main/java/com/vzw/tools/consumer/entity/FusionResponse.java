package com.vzw.tools.consumer.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class FusionResponse {
    @JsonProperty("responseHeader")
    private ResponseHeader responseHeader;

    @JsonProperty("response")
    private Response response;

    public static class ResponseHeader {
        @JsonProperty("zkConnected")
        private boolean zkConnected;

        @JsonProperty("status")
        private int status;

        @JsonProperty("QTime")
        private int qTime;

        @JsonProperty("params")
        private Map<String, String> params;
    }

    @Data
    public static class Response {
        @JsonProperty("numFound")
        private int numFound;

        @JsonProperty("start")
        private int start;

        @JsonProperty("docs")
        private List<Doc> docs;
    }

    public static class Doc {
        @JsonProperty("sku_image_set_digital_url_s")
        private String sku_image_set_digital_url_s;

        @JsonProperty("product_e911Address_flag_b")
        private boolean product_e911Address_flag_b;

        @JsonProperty("sku.image_set_non_digital_url")
        private List<String> skuImageSetNonDigitalUrl;

        @JsonProperty("rollup_id_s")
        private String rollupId;

        @JsonProperty("brand_seo_url_name")
        private String brandSeoUrlName;

        @JsonProperty("product_Numbershare_flag_b")
        private boolean productNumbershareFlag;

        @JsonProperty("product_isvalidproduct_b")
        private boolean productIsValidProduct;

        @JsonProperty("sku.sor_product_family")
        private List<String> skuSorProductFamily;

        @JsonProperty("sku_sor_product_family_s")
        private String sku_sor_product_family_s;

        @JsonProperty("product_min_fullRetailPrice_f")
        private String product_min_fullRetailPrice_f;

        @JsonProperty("sku_sor_product_family_t")
        private List<String> skuSorProductFamilyT;

        @JsonProperty("sku.sim_sku")
        private List<String> skuSimSku;

        @JsonProperty("launchDateScore")
        private String launchDateScore;

        @JsonProperty("sku_default_display_flag_b")
        private String skuDefaultDisplayFlag;

        @JsonProperty("brand")
        private String brand;

        @JsonProperty("product_seo_url_name_s")
        private String product_seo_url_name_s;

        @JsonProperty("product_sor_device_type_s")
        private String product_sor_device_type_s;

        @JsonProperty("sku_showcase_flag_b")
        private String sku_showcase_flag_b;

        @JsonProperty("product_description_ss")
        private List<String> product_description_ss;

        @JsonProperty("product_features_phone_cap_display_name_ss")
        private List<String> product_features_phone_cap_display_name_ss;

        @JsonProperty("sku_id_s")
        private String sku_id_s;

        @JsonProperty("sku_marketing_color_s")
        private String sku_marketing_color_s;

        @JsonProperty("sku.memory")
        private List<String> skuMemory;

        @JsonProperty("product_display_name_s")
        private String product_display_name_s;

        @JsonProperty("sku_image_name_s")
        private String sku_image_name_s;

        @JsonProperty("product_display_name_t")
        private List<String> product_display_name_t;

        @JsonProperty("sku_capacity_unit_s")
        private String sku_capacity_unit_s;

        @JsonProperty("product_operating_system_s")
        private String product_operating_system_s;

        @JsonProperty("sku_sim_sku_s")
        private String sku_sim_sku_s;

        @JsonProperty("product_showcase_flag_b")
        private String product_showcase_flag_b;

        @JsonProperty("defaultImage_s")
        private String defaultImage_s;

        @JsonProperty("device_compatible_name")
        private List<String> device_compatible_name;

        @JsonProperty("sku.image_set")
        private List<String> skuImageSet;

        @JsonProperty("sku_filter_display_name_ss")
        private List<String> sku_filter_display_name_ss;

        @JsonProperty("product_sor_device_family_type_s")
        private String product_sor_device_family_type_s;

        @JsonProperty("sku_color_style_s")
        private String sku_color_style_s;

        @JsonProperty("color")
        private String color;

        @JsonProperty("color_seo_url_name")
        private String color_seo_url_name;

        @JsonProperty("revenueSaleScore")
        private String revenueSaleScore;

        @JsonProperty("sku_type_s")
        private String sku_type_s;

        @JsonProperty("sku_memory_s")
        private String sku_memory_s;

        @JsonProperty("sku_site_id_s")
        private String sku_site_id_s;

        @JsonProperty("quantity_i")
        private String quantity_i;

        @JsonProperty("isInStock_b")
        private String isInStock_b;

        @JsonProperty("isAvailable_b")
        private String isAvailable_b;

        @JsonProperty("inventoryStatus_s")
        private String inventoryStatus_s;

        @JsonProperty("critical_inventory_b")
        private String critical_inventory_b;

        @JsonProperty("fullRetailPrice_f")
        private double fullRetailPrice_f;

        @JsonProperty("preffered_Term_i")
        private String preffered_Term_i;

        @JsonProperty("sku_in_store_pickup_flag_b")
        private String sku_in_store_pickup_flag_b;
    }
}
