package com.vzw.tools.authoring.constant;

public class AuthoringConstants {
    public static String PRODUCT_OFFER= "productOffer.";
    public static String PRODUCT_SPECIFICATION_SKU= "productSpecificationSku.";
    public static String PRODUCT_SPECIFICATION_PRD= "productSpecificationPrd.";
    public static String PRODUCT_OFFER_GROUP= "productOfferGroup.";
    public static String PRODUCT_OFFER_PRICE= "productOfferPrice.";
    public static String NAME= "name";
    public static String PRODUCT_OFFERING_CHARACTERISTIC_VALUE = "productOfferingCharacteristicValue";
    public static String LOCALIZED_VALUE = "localizedValue";
    public static String VALUES = "values";
    public static String VALUE = "value";
    public static String PRODUCT_SPECIFICATION_CHARACTERISTIC_VALUE = "productSpecCharacteristicValue";
    public static String PRICE_RECORDS = "priceRecords";
    public static String PARAMETER = "parameter";
    public static String COMMITMENT = "Commitment";
    public static String VZ_PRICE_TYPE ="vz_price_type";
    public static String PRICE = "price";
    public static String DUTY_FREE_AMOUNT = "dutyFreeAmount";
    public static String CHARACTERISTICS = "characteristics";
    public static String PRODUCT_SPEC_CHARACTERISTIC ="productSpecCharacteristic";
    public static String LOCALIZED_NAME = "localizedName";
    public static String DOCUMENTNAME = "documentName";
    public static String DISPLAYNAME = "displayName";
    public static String DOCUMENT_DESCRIPTION ="document.description";
    public static String DESCRIPTION ="description";
    public static String EXTERNALID = "externalId";
    public static String OWNER = "owner";
    public static String TYPE = "type";


}
