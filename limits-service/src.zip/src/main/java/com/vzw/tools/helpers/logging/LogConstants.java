package com.vzw.tools.helpers.logging;

public class LogConstants {
    public static String DVS_RESPONSE_CORRELATION_ID = "x-vzw-txcorrelationid";
    public static String EXTERNAL_CORRELATION_ID = "external_correlation_id";
    public static String EXTERNAL_SYSTEM = "external_system";
    public static String EXTERNAL_SYSTEM_DVS = "DVS";
    public static String EXTERNAL_SYSTEM_PNO = "PNO";
    public static String EXTERNAL_SYSTEM_DB = "DB";
    public static String CORRELATION_ID = "CORRELATION_ID";
    public static String E2EREQUEST_ID = "E2EREQUEST_ID";
    public static String E2EREQUESTID = "E2EREQUESTID";
    public static String DOMAIN_CORRELATION_ID = "DOMAIN_CORRELATION_ID";
    public static final String CANARY_HEADER_NAME = "x-canary";
    public static final String TRACE_INFO_KEY = "cxpds_trace_info";
    public static final String EVENT_TYPE_REQUEST = "request";
    public static final String EVENT_TYPE_EXTERNAL_CALL = "external_request";
    public static final String ROUTE_TYPE = "route-type";
    public static final String LOG_PAYLOAD = "log_payload";
    public static final String CLIENT_ID = "CLIENT_ID";
    public static final String CUSTOM_LOG_LEVEL = "custom_log_level";
    public static final String SSO_JWT = "sso_jwt";

    public LogConstants() {
    }
}
