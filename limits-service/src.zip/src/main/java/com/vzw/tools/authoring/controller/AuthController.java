package com.vzw.tools.authoring.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.vzw.tools.authoring.service.AuthoringService;
import com.vzw.tools.common.exception.ConverterException;
import com.vzw.tools.common.exception.ErrorBuilder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import static com.vzw.tools.common.constant.CommonConstants.*;


@RestController
@Slf4j
public class AuthController {

    @Autowired
    private ErrorBuilder errorBuilder;

    @Autowired
    private AuthoringService authoringService;

    @GetMapping("/epc/{productType}/{env}")
    public Mono<ResponseEntity<JsonNode>> getEPC(@PathVariable String productType,
                                                 @PathVariable String env,
                                                 @RequestParam(value = "id", required = true) String id) throws JsonProcessingException, ConverterException {

        if(PROD_TYPE_DEVICE.equalsIgnoreCase(productType) || PROD_TYPE_ACCESSORY.equalsIgnoreCase(productType)){
            Mono<JsonNode> authoringData = authoringService.getEPCRecords(id, env);
            return authoringData.flatMap(res ->
                    Mono.just(ResponseEntity
                            .ok()
                            .contentType(MediaType.APPLICATION_JSON)
                            .body(res))
            ).onErrorMap(err -> errorBuilder.buildApplicationException(err));
        }
        else if(PROD_TYPE_PROMOTION.equalsIgnoreCase(productType)){
            Mono<JsonNode> authoringData = authoringService.getEPCDataForPromo(id, env);
            return authoringData.flatMap(res ->
                    Mono.just(ResponseEntity
                            .ok()
                            .contentType(MediaType.APPLICATION_JSON)
                            .body(res))
            ).onErrorMap(err -> errorBuilder.buildApplicationException(err));
        }
        else{
            return Mono.error(errorBuilder.buildBadRequest("Invalid product type"));
        }
    }


}
