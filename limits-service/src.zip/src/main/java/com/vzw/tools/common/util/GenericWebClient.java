package com.vzw.tools.common.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.tools.common.constant.CommonConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.concurrent.TimeoutException;

@Component
@Slf4j
public class GenericWebClient {
    private final WebClient webClient;
    private static final ObjectMapper objectMapper = new ObjectMapper();
    @Value("${spring.webclient.timeout:30}")
    public int timeoutInSeconds;

    @Autowired
    public GenericWebClient(WebClient webClient) {
        this.webClient = webClient;
    }

    public <T, R> Mono<R> callPostApi(String token, String apiPath, T requestBody,
                                      Class<R> responseType,String typeOfCall) {
        if(requestBody!=null) {
            return webClient.post().uri(apiPath)
                    .header("Authorization", token)
                    .header("Content-Type", "application/json")
                    .bodyValue(requestBody)
                    .retrieve()
                    .bodyToMono(responseType)
                    .timeout(Duration.ofSeconds(timeoutInSeconds))
                    .transform(monoResponseType -> handleLoggingAndError(monoResponseType, apiPath, responseType,typeOfCall));
        }
        else{
            return webClient.post().uri(apiPath)
                    .header("Authorization", token)
                    .header("Content-Type", "application/json")
                    //.bodyValue(requestBody == null ? Mono.empty() : requestBody)
                    .retrieve()
                    .bodyToMono(responseType)
                    .timeout(Duration.ofSeconds(timeoutInSeconds))
                    .transform(monoResponseType -> handleLoggingAndError(monoResponseType, apiPath, responseType,typeOfCall));
        }
    }

    /**
     * Reusable method for logging success and handling errors.
     */
    private <R> Mono<R> handleLoggingAndError(Mono<R> mono, String apiPath, Class<R> responseType,String typeOfCall) {
        return mono.doOnSuccess(response -> logResponse(apiPath, response,typeOfCall))
                .doOnError(error -> log.error("Error occurred while calling {} API: {}", typeOfCall,apiPath, error))
                .onErrorResume(WebClientResponseException.class, ex -> {
                    log.error("{} API call failed with status: {}, body: {}", typeOfCall, ex.getStatusCode(), ex.getResponseBodyAsString());
                    return getDefaultResponse(responseType, ex);
                })
                .onErrorResume(Exception.class, ex -> {
                    log.error("Unexpected error occurred while calling {} API: {}", typeOfCall,apiPath, ex);
                    return getDefaultResponse(responseType , ex);
                });
    }

    /**
     * Logs API response in JSON format.
     */
    private <R> void logResponse(String apiPath, R response,String typeOfCall) {
        try {
            log.info("Received response from {} API: {}, Response: {}",typeOfCall, apiPath, objectMapper.writeValueAsString(response));
        } catch (Exception e) {
            log.error("Error while logging response for API: {}", apiPath, e);
        }
    }

    /**
     * Returns a default instance of responseType if an error occurs.
     */
    private <R> Mono<R> getDefaultResponse(Class<R> responseType, Exception ex) {
        if (ex instanceof TimeoutException) {
            return Mono.error(new TimeoutException(CommonConstants.API_TIME_OUT));
        } else {
            try {
                R defaultInstance = responseType.getDeclaredConstructor().newInstance();
                log.info("Returning default instance of response type: {}", responseType.getSimpleName());
                return Mono.just(defaultInstance);
            } catch (Exception e) {
                log.error("Failed to create a default instance of response type: {}", responseType.getSimpleName(), e);
                return Mono.empty();
            }
        }
    }
}
