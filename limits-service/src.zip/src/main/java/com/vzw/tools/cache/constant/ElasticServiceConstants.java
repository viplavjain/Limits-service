package com.vzw.tools.cache.constant;

public class ElasticServiceConstants {

    private ElasticServiceConstants() {
    }

    public static final String ACCESSORY = "ACCESSORY";
    public static final String DEVICE = "DEVICE";
    public static final String SAP_ID = "_SAP_9999999";
    public static final String INVENTORY_DEVICE_QA = "inventory_devices_qa";
    public static final String INVENTORY_ACCESSORY_QA = "inventory_accessories_qa";
    public static final String DEVICE_QA = "devices_qa";
    public static final String ACCESSORY_QA = "accessories_qa";
    public static final String SMART_IMEI_DEVICES_QA = "smartimei_devices_qa";
    public static final String FEDERATED_CATALOG_ELASTIC_SEARCH = "spring.elasticsearch.";
    public static final String DEVICE_ID = "devprod_id";
    public static final String ACCESSORY_ID = "acc_prod_id";
    public static final String ERROR = "ID is not found";
    public static final String INVALID_PRODUCT_TYPE = "Invalid product type: ";
    public static final String PRICE_DEVICE_COMPOSITE = "price_devices_composite_qa";
    public static final String PRICE_ACCESSORY_COMPOSITE = "price_accessories_qa";
    public static final String PRICE = "price";
    public static final String PRICE_LIST = "price_list";
    public static final String LIST_PRICE = "list_price";
    public static final String FULL_RETAIL_PRICE_LIST = "fullRetailPriceListId";
    public static final String PROMOTION = "Promotion";
    public static final String PRICE_OFFERS_EXT_DETAILS_QA = "price_offers_ext_details_qa";
    public static final String OFFER_ID = "$$offerId$$";
    public static final String REQUEST_BODY="espromotion_request.json";
    public static final int BYTES =1024;
}