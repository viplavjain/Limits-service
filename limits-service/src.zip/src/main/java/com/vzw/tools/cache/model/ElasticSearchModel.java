package com.vzw.tools.cache.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ElasticSearchModel {
    private String instance;
    private String index;
    private String id;
}
