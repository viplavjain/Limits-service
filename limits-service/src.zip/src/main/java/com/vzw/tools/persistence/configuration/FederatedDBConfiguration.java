package com.vzw.tools.persistence.configuration;

import com.vzw.tools.persistence.properties.FederatedDBProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

@Configuration
public class FederatedDBConfiguration {

    private final FederatedDBProperties federatedDBProperties;

    public FederatedDBConfiguration(FederatedDBProperties federatedDBProperties) {
        this.federatedDBProperties = federatedDBProperties;
    }

    @Bean(name = "fedCatalogDataSource")
    public DataSource fedCatalogDataSourceQA1() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setUrl(federatedDBProperties.getUrl());
        dataSource.setUsername(federatedDBProperties.getUserName());
        dataSource.setPassword(federatedDBProperties.getPassword());
        return dataSource;
    }

    @Bean(name = "fedCatalogJdbcTemplate")
    public JdbcTemplate jdbcTemplateForQA1() {
        return new JdbcTemplate(fedCatalogDataSourceQA1());
    }

    public JdbcTemplate jdbcTemplateForEnv(String env) {
        if (env.equalsIgnoreCase("QA1")) {
            return jdbcTemplateForQA1();
        }
        return new JdbcTemplate();
    }

}
