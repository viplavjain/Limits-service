package com.vzw.tools.helpers.jdbc;

import com.vzw.tools.common.exception.ErrorBuilder;
import com.vzw.tools.source.dao.DeviceDPIDAO;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.internal.OracleTypes;
import org.elasticsearch.common.inject.Inject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import static com.vzw.tools.common.constant.CommonConstants.*;

@Component
@Slf4j
public class DeviceDpiJdbcReactiveHelper {

    private ReactiveStoredProcHelper reactiveStoredProcHelper;

    @Inject
    public DeviceDpiJdbcReactiveHelper(@Qualifier("dpiJdbcTemplate")JdbcTemplate jdbcTemplate) {
        super();
        this.reactiveStoredProcHelper = new ReactiveStoredProcHelper(jdbcTemplate);
    }
    @Autowired
    ErrorBuilder errorBuilder;

    @PostConstruct
    private void init() {
        log.trace("Entering into InstallmentLoanProcedure init()");
        List<SqlOutParameter> parameters = new ArrayList<>();
        parameters.add(new SqlOutParameter("P_RESULT_SET", OracleTypes.REF_CURSOR, (resultSet, i) -> setResultSet(resultSet)));
        reactiveStoredProcHelper.initialize(DPI_PKG, DPI_SP_DEVICE, parameters);
        log.trace("Exiting from InstallmentLoanProcedure init()");
    }

    private DeviceDPIDAO setResultSet(ResultSet resultSet) throws SQLException {
        return mapDeviceDPIResult(resultSet);
    }

    public DeviceDPIDAO mapDeviceDPIResult(ResultSet resultSet) throws SQLException {
        DeviceDPIDAO deviceDPIDAO = new DeviceDPIDAO();
        deviceDPIDAO.setSku((String) resultSet.getString(SKU));
        deviceDPIDAO.setSkuType((String) resultSet.getString(SKU_TYPE));
        deviceDPIDAO.setLocationCode((String) resultSet.getString(LOCATION_CODE));
        deviceDPIDAO.setFullRetailPrice((BigDecimal) resultSet.getBigDecimal(FULL_RETAIL_PRICE));
        deviceDPIDAO.setOneYearPrice((BigDecimal) resultSet.getBigDecimal(ONE_YEAR_PRICE));
        deviceDPIDAO.setTwoYearPrice((BigDecimal) resultSet.getBigDecimal(TWO_YEAR_PRICE));
        deviceDPIDAO.setPrepayPrice((BigDecimal) resultSet.getBigDecimal(PREPAY_PRICE));
        deviceDPIDAO.setEdgeSku((String) resultSet.getString(EDGE_SKU));
        deviceDPIDAO.setEdgeFullRetailPrice((BigDecimal) resultSet.getBigDecimal(EDGE_FULL_RETAIL_PRICE));
        return deviceDPIDAO;
    }
    //@LogExecutionTime
    public Mono<DeviceDPIDAO> retrieveDPIResponse(String sorId) {
        Map<String, Object> arguments = new HashMap<>();
        arguments.put(DEV_SKU_LIST, sorId);
        arguments.put(DATE, null);
        Mono<Map<String, Object>> monoResponse = reactiveStoredProcHelper
                .execute(DPI_PKG,DPI_SP_DEVICE, arguments)
                .subscribeOn(Schedulers.boundedElastic())
                .onErrorMap(e -> errorBuilder.buildApplicationException(e));
        return monoResponse.flatMap(data -> {
            log.trace("Exiting from retrieveDPIResponse {] "
                    , sorId);
            List<?> result = (List<?>) data.get("P_RESULT_SET");
            Optional<DeviceDPIDAO> dpiRes = result.stream().map(DeviceDPIDAO.class::cast).findFirst();
            if(dpiRes.isPresent()){
                return Mono.just(dpiRes.get());
            }
            return Mono.just(new DeviceDPIDAO());
        });

    }


}
