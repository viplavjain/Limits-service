package com.vzw.tools.helpers.jdbc;

import com.vzw.tools.common.exception.ErrorBuilder;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.common.inject.Inject;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import static com.vzw.tools.common.constant.CommonConstants.*;

@Component
@Slf4j
public class DMDAccessoryJdbcReactiveHelper {

    private final ReactiveStoredProcHelper reactiveStoredProcHelper;

    @Inject
    public DMDAccessoryJdbcReactiveHelper(@Qualifier("dmdJdbcTemplate")JdbcTemplate jdbcTemplate, ErrorBuilder errorBuilder) {
        super();
        this.reactiveStoredProcHelper = new ReactiveStoredProcHelper(jdbcTemplate);
        this.errorBuilder = errorBuilder;
    }

    private final ErrorBuilder errorBuilder;

    @PostConstruct
    private void init() {
        log.trace("Entering into AccessoryProcedure init()");
        List<SqlOutParameter> parameters = new ArrayList<>();
        parameters.add(new SqlOutParameter("P_RESULT_SET", oracle.jdbc.OracleTypes.REF_CURSOR, (resultSet, i) -> setResultSet(resultSet)));
        reactiveStoredProcHelper.initialize(DMD_PKG, SP_ACCESSORY, parameters);
        log.trace("Exiting from AccessoryProcedure init()");
    }

    private String setResultSet(ResultSet resultSet) throws SQLException {
        return resultSet.getString("ACCESSORYINFO");
    }
    //@LogExecutionTime
    public Mono<String> retrieveDMDAccessoryResponse(String sorId) {
        Map<String, Object> arguments = new HashMap<>();
        arguments.put(ACC_SKU_LIST, sorId);
        arguments.put(DATE, null);
        Mono<Map<String, Object>> monoResponse = reactiveStoredProcHelper
                .execute(DMD_PKG,SP_ACCESSORY, arguments)
                .subscribeOn(Schedulers.boundedElastic())
                .onErrorMap(errorBuilder::buildApplicationException);
        return monoResponse.flatMap(data -> {
            List<?> result = (List<?>) data.get("P_RESULT_SET");
            Optional<String> dmdXmlResponse = result.stream().map(String.class::cast).findFirst();
            return dmdXmlResponse.map(Mono::just).orElseGet(() -> Mono.error(errorBuilder.buildApplicationException(new RuntimeException("DMD Accessory data is empty"))));
        });

    }


}
