package com.vzw.tools.source.configuration;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.tools.common.constant.CommonConstants;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class RunTimeMapInitializer {

    private static HashMap<String, HashMap<String, String>> listRuntimeMap = new HashMap<>();

    @PostConstruct
    private void init() {

        HashMap<String, String> authorizationMap = retrieveGenericKeyMap(CommonConstants.AUTHORIZATION_JSON_PATH,CommonConstants.EPC,CommonConstants.CONFIG_JSON);
        HashMap<String, String> sourceDMDMap = retrieveGenericKeyMap(CommonConstants.SOURCE_JSON_PATH,CommonConstants.DMD,CommonConstants.CONFIG_JSON);
        HashMap<String, String> sourceDPIMap = retrieveGenericKeyMap(CommonConstants.SOURCE_JSON_PATH,CommonConstants.DPI,CommonConstants.CONFIG_JSON);
        HashMap<String, String> persistentMap = retrieveGenericKeyMap(CommonConstants.PERSISTENCE_JSON_PATH,CommonConstants.CASSANDRA,CommonConstants.CONFIG_JSON);
        HashMap<String, String> cacheMap = retrieveGenericKeyMap(CommonConstants.CACHE_JSON_PATH,CommonConstants.REDIS,CommonConstants.CONFIG_JSON);
        HashMap<String,String> fedCatalogMap = retrieveGenericKeyMap(CommonConstants.PERSISTENCE_JSON_PATH,CommonConstants.FEDERATED,CommonConstants.CONFIG_JSON);
        HashMap<String, String> elasticSearchMap = retrieveGenericKeyMap(CommonConstants.ELASTICSEARCH_JSON_PATH, CommonConstants.ELASTICSEARCH, CommonConstants.CONFIG_JSON);
        HashMap<String,String> fusionMap = retrieveGenericKeyMap(CommonConstants.CONSUMER_JSON_PATH,CommonConstants.FUSION,CommonConstants.CONFIG_JSON);
        HashMap<String,String> cxpCatalogMap = retrieveGenericKeyMap(CommonConstants.CONSUMER_JSON_PATH,CommonConstants.CXP_CATALOG,CommonConstants.CONFIG_JSON);

        //Maps for Accessories
        HashMap<String, String> authorizationAccsMap = retrieveGenericKeyMap(CommonConstants.AUTHORIZATION_JSON_PATH,CommonConstants.EPC,CommonConstants.ACCESSORIES_JSON);
        HashMap<String, String> sourceDMDAccsMap = retrieveGenericKeyMap(CommonConstants.SOURCE_JSON_PATH,CommonConstants.DMD,CommonConstants.ACCESSORIES_JSON);
        HashMap<String, String> sourceDPIAccsMap = retrieveGenericKeyMap(CommonConstants.SOURCE_JSON_PATH,CommonConstants.DPI,CommonConstants.ACCESSORIES_JSON);
        HashMap<String, String> persistentAccsMap = retrieveGenericKeyMap(CommonConstants.PERSISTENCE_JSON_PATH,CommonConstants.CASSANDRA,CommonConstants.ACCESSORIES_JSON);
        HashMap<String, String> cacheAccsMap = retrieveGenericKeyMap(CommonConstants.CACHE_JSON_PATH,CommonConstants.REDIS,CommonConstants.ACCESSORIES_JSON);
        HashMap<String,String> fedCatalogAccsMap = retrieveGenericKeyMap(CommonConstants.PERSISTENCE_JSON_PATH,CommonConstants.FEDERATED,CommonConstants.ACCESSORIES_JSON);
        HashMap<String,String> fusionAccsMap = retrieveGenericKeyMap(CommonConstants.CONSUMER_JSON_PATH,CommonConstants.FUSION,CommonConstants.ACCESSORIES_JSON);
        HashMap<String,String> cxpCatalogAcssMap = retrieveGenericKeyMap(CommonConstants.CONSUMER_JSON_PATH,CommonConstants.CXP_CATALOG,CommonConstants.ACCESSORIES_JSON);
        HashMap<String, String> elasticSearchAcssMap = retrieveGenericKeyMap(CommonConstants.ELASTICSEARCH_JSON_PATH, CommonConstants.ELASTICSEARCH,CommonConstants.ACCESSORIES_JSON);
        listRuntimeMap.put(CommonConstants.AUTHORIZATION, authorizationMap);
        listRuntimeMap.put(CommonConstants.SOURCE, concatenateMaps(Arrays.asList(sourceDMDMap,sourceDPIMap)));
        listRuntimeMap.put(CommonConstants.PERSISTENCE, persistentMap);
        listRuntimeMap.put(CommonConstants.CACHE, cacheMap);
        listRuntimeMap.put(CommonConstants.FEDERATEDCATALOG,fedCatalogMap);
        listRuntimeMap.put(CommonConstants.ELASTICSEARCH, elasticSearchMap);
        listRuntimeMap.put(CommonConstants.FUSION,fusionMap);
        listRuntimeMap.put(CommonConstants.CXP_CATALOG,cxpCatalogMap);

        listRuntimeMap.put(CommonConstants.AUTHORIZATION_ACCS, authorizationAccsMap);
        listRuntimeMap.put(CommonConstants.SOURCE_ACCS, concatenateMaps(Arrays.asList(sourceDMDAccsMap,sourceDPIAccsMap)));
        listRuntimeMap.put(CommonConstants.PERSISTENCE_ACCS, persistentAccsMap);
        listRuntimeMap.put(CommonConstants.CACHE_ACCS, cacheAccsMap);
        listRuntimeMap.put(CommonConstants.FEDERATEDCATALOG_ACCS,fedCatalogAccsMap);
        listRuntimeMap.put(CommonConstants.FUSION_ACCS,fusionAccsMap);
        listRuntimeMap.put(CommonConstants.CXP_CATALOG_ACCS,cxpCatalogAcssMap);
        listRuntimeMap.put(CommonConstants.ELASTICSEARCH_ACCS, elasticSearchAcssMap);

    }

    public HashMap<String,String> concatenateMaps(List<Map<String,String>> mapList){
        HashMap<String,String> result = new HashMap<>();
        for(Map<String,String> map : mapList){
            map.forEach((key,value) -> result.putIfAbsent(key,value));
        }
        return result;
    }

    public HashMap<String, String> getSourceMap(String productType) {
        if(CommonConstants.PROD_TYPE_ACCESSORY.equalsIgnoreCase(productType))
            return listRuntimeMap.get(CommonConstants.SOURCE_ACCS);
        else
            return listRuntimeMap.get(CommonConstants.SOURCE);
    }

    public HashMap<String, String> getPersistentMap(String productType)
    {
        if(CommonConstants.PROD_TYPE_ACCESSORY.equalsIgnoreCase(productType))
            return listRuntimeMap.get(CommonConstants.PERSISTENCE_ACCS);
        else
            return listRuntimeMap.get(CommonConstants.PERSISTENCE);
    }

    public HashMap<String, String> getAuthorizationMap(String productType) {
        if(CommonConstants.PROD_TYPE_ACCESSORY.equalsIgnoreCase(productType))
            return listRuntimeMap.get(CommonConstants.AUTHORIZATION_ACCS);
        else
            return listRuntimeMap.get(CommonConstants.AUTHORIZATION);
    }

    public HashMap<String, String> getCacheMap(String productType) {
        if(CommonConstants.PROD_TYPE_ACCESSORY.equalsIgnoreCase(productType))
            return listRuntimeMap.get(CommonConstants.CACHE_ACCS);
        else
            return listRuntimeMap.get(CommonConstants.CACHE);
    }

	public HashMap<String, String> getElasticSearchMap(String productType) {
		if (CommonConstants.PROD_TYPE_ACCESSORY.equalsIgnoreCase(productType))
			return listRuntimeMap.get(CommonConstants.ELASTICSEARCH_ACCS);
		else
			return listRuntimeMap.get(CommonConstants.ELASTICSEARCH);
	}
  
    public HashMap<String, String> getFusionMap() {
        return listRuntimeMap.get(CommonConstants.FUSION);
    }
    
    public HashMap<String, String> getFedCatalogMap(String productType) {
        if(CommonConstants.PROD_TYPE_ACCESSORY.equalsIgnoreCase(productType))
            return listRuntimeMap.get(CommonConstants.FEDERATEDCATALOG_ACCS);
        else
            return listRuntimeMap.get(CommonConstants.FEDERATEDCATALOG);
    }

    public HashMap<String, String> getFusionMap(String productType) {
        if(CommonConstants.PROD_TYPE_ACCESSORY.equalsIgnoreCase(productType))
            return listRuntimeMap.get(CommonConstants.FUSION_ACCS);
        else
            return listRuntimeMap.get(CommonConstants.FUSION);
    }

    public HashMap<String, String> getCxpCatalogMap(String productType) {
        if(CommonConstants.PROD_TYPE_ACCESSORY.equalsIgnoreCase(productType))
            return listRuntimeMap.get(CommonConstants.CXP_CATALOG_ACCS);
        else
            return listRuntimeMap.get(CommonConstants.CXP_CATALOG);
    }

    private HashMap<String, String> retrieveGenericKeyMap(String jsonPath,String systemName,String jsonFile) {
        HashMap<String, String> genericKeyMap = new HashMap<>();
        try {
            // Load JSON file from the resources folder
            InputStream inputStream = RunTimeMapInitializer.class.getClassLoader().getResourceAsStream(jsonFile);
            if (inputStream == null) {
                throw new RuntimeException("File config.json not found in resources folder");
            }

            // Parse JSON file using ObjectMapper
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode root = objectMapper.readTree(inputStream);


            // Map to hold genericKeyMap


            // Extract devices
            JsonNode devices;
            if(CommonConstants.ACCESSORIES_JSON.equalsIgnoreCase(jsonFile))
                devices = root.at(CommonConstants.ACCESSORIES_DEVICE);
            else
                devices = root.at(CommonConstants.ITEMS_DEVICE);
            if (devices.isArray()) {
                for (JsonNode device : devices) {
                    String genericKey = device.get(CommonConstants.GENERIC_KEY).asText();
                    JsonNode layer = device.at(jsonPath);
                    if (layer.isArray()) {
                        for (JsonNode auth : layer) {
                            String key = auth.get(CommonConstants.KEY).asText();
                            if (!key.isEmpty()&& auth.get(CommonConstants.SYSTEM).asText().equalsIgnoreCase(systemName)) {
                                genericKeyMap.put(genericKey, key);
                            }
                        }
                    }
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return genericKeyMap;
    }

    public static HashMap<String, HashMap<String, String>> getRuntImeMap() {
        return listRuntimeMap;
    }
}
