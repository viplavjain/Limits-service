//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.vzw.tools.helpers.logging;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.tools.helpers.logging.utils.MaskUtil;
import com.vzw.tools.helpers.logging.vo.AppInfo;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.Marker;
import org.slf4j.MarkerFactory;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Objects;

@Component
public class FCEventLogger implements EventLogger {
    public static final String PAYLOAD = "Payload";
    private Logger LOGGER;
    private static final Marker DOMAIN_SERVICES_EVENT_MARKER = MarkerFactory.getMarker("DOMAIN_SERVICES_EVENT");
    private static final String API_REQUEST = "api_request";
    private static final String API_RESPONSE = "api_response";
    private final ObjectMapper objectMapper;
    private final AppInfo appInfo;
    private boolean logPayloadEnabled;
    private boolean logDataMaskingEnabled;
    private String sensitiveDataFields;

    public FCEventLogger(ObjectMapper objectMapper) {
        this(objectMapper, (AppInfo)null);
    }

    public FCEventLogger() {
        this(getObjectMapper());
        this.logPayloadEnabled = true;
        this.logDataMaskingEnabled = true;
    }

    public FCEventLogger(ObjectMapper objectMapper, AppInfo appInfo) {
        this.LOGGER = LoggerFactory.getLogger(FCEventLogger.class);
        this.objectMapper = objectMapper;
        this.appInfo = appInfo;
    }

    public FCEventLogger(ObjectMapper objectMapper, AppInfo appInfo, boolean logPayloadEnabled) {
        this.LOGGER = LoggerFactory.getLogger(FCEventLogger.class);
        this.objectMapper = objectMapper;
        this.appInfo = appInfo;
        this.logPayloadEnabled = logPayloadEnabled;
        this.logDataMaskingEnabled = true;
    }

    public FCEventLogger(ObjectMapper objectMapper, AppInfo appInfo, boolean logPayloadEnabled, boolean logDataMaskingEnabled, String sensitiveDataFields) {
        this.LOGGER = LoggerFactory.getLogger(FCEventLogger.class);
        this.objectMapper = objectMapper;
        this.appInfo = appInfo;
        this.logPayloadEnabled = logPayloadEnabled;
        this.logDataMaskingEnabled = logDataMaskingEnabled;
        this.sensitiveDataFields = sensitiveDataFields;
    }

    public void logEvent(Event event) {
        if (this.appInfo != null) {
            event.setVsadId(this.appInfo.getProjectApplicationVSAD());
            event.setVastId(this.appInfo.getVastId());
            event.setApplication(this.appInfo.getName());
            event.setAppName(this.appInfo.getName());
        }

        if (StringUtils.equalsIgnoreCase(event.getEventType(), "request")) {
            if (this.logPayloadEnabled || event.isLogPayload()) {
                event.setMsg("Inbound Payload");
                event.setLogType("Payload");
                this.LOGGER.info(DOMAIN_SERVICES_EVENT_MARKER, "{}", this.getLoggedEventString(event));
            }

            event.setApiRequest((String)null);
            event.setApiResponse((String)null);
            event.setMsg("Inbound Summary");
            event.setLogType("InboundCall");
            this.LOGGER.info(DOMAIN_SERVICES_EVENT_MARKER, "{}", this.getLoggedEventString(event));
        } else {
            if (this.logPayloadEnabled || event.isLogPayload()) {
                event.setMsg("Outbound Payload");
                event.setLogType("Payload");
                this.LOGGER.info(DOMAIN_SERVICES_EVENT_MARKER, "{}", this.getLoggedEventString(event));
            }

            event.setApiRequest((String)null);
            event.setApiResponse((String)null);
            event.setMsg("Outbound Summary");
            event.setLogType("OutboundCall");
            this.LOGGER.info(DOMAIN_SERVICES_EVENT_MARKER, "{}", this.getLoggedEventString(event));
        }

    }

    public String getLoggedEventString(Event event) {
        String message = "";

        try {
            Map<String, Object> extraInfo = event.getExtraInfo();
            Map<String, Object> map = (Map)this.objectMapper.convertValue(event, Map.class);
            if (this.logDataMaskingEnabled) {
                if (null != map.get("api_request")) {
                    map.put("api_request", MaskUtil.scrubJson((String)map.get("api_request"), this.sensitiveDataFields));
                }

                if (null != map.get("api_response")) {
                    map.put("api_response", MaskUtil.scrubJson((String)map.get("api_response"), this.sensitiveDataFields));
                }

                if (null != map.get("request_headers")) {
                    map.put("request_headers", MaskUtil.scrubJson((String)map.get("request_headers"), this.sensitiveDataFields));
                }

                if (null != map.get("response_headers")) {
                    map.put("response_headers", MaskUtil.scrubJson((String)map.get("response_headers"), this.sensitiveDataFields));
                }
            }

            map.remove("extraInfo");
            this.LOGGER.trace("Extra Info {} ", extraInfo);
            if (extraInfo != null) {
                extraInfo.forEach((k, v) -> {
                    if (!map.containsKey(k) && Objects.nonNull(v)) {
                        map.put(k, v.toString());
                    }

                });
            }

            message = this.objectMapper.writer().writeValueAsString(map);
        } catch (Exception var5) {
            Exception e = var5;
            message = "{}";
            this.LOGGER.error("Unable to build Event - {}", e.getMessage());
        }

        return message;
    }

    private static ObjectMapper getObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setSerializationInclusion(Include.NON_NULL);
        return objectMapper;
    }

}
