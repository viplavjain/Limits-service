package com.vzw.tools.authoring.entity;

import lombok.Data;

import java.util.List;

@Data
public class ProductOfferSearchRequest {

    private Context context;
    private Item item;
    private ResponseFilter responseFilter;
    private Object cacheResultID;

    @Data
    public static class Context {
        private String workstreamName;
        private String user;
        private String level;

    }

    @Data
    public static class Item {
        private String type;
        private List<Object> and;
        private List<Object> not;
        private List<OrCondition> or;
        private Filter filter;

        @Data
        public static class OrCondition {
            private String type;
            private String text;
            private String locale;
            private List<String> types;
            private Criteria criteria;

            @Data
            public static class Criteria {
                private FilterCondition filterCondition;

                @Data
                public static class FilterCondition {
                    private String type;
                    private String path;
                    private Condition condition;

                    @Data
                    public static class Condition {
                        private String type;
                        private String field;
                        private List<String> values;
                    }

                }
            }
        }

        @Data
        public static class Filter {
            private String type;
            private List<Object> or;
            private List<AndCondition> and;
            private List<Object> not;

            @Data
            public static class AndCondition {
                private String type;
                private List<InCondition> and;

                @Data
                public static class InCondition {
                    private String type;
                    private String field;
                    private List<String> values;
                }
            }
        }
    }

    @Data
    public static class ResponseFilter {
        private List<String> includeFields;
    }
}