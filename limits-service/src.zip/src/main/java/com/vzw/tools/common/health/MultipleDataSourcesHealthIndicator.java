package com.vzw.tools.common.health;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

public class MultipleDataSourcesHealthIndicator implements HealthIndicator {

    private final DataSource dmdDataSource;
    private final DataSource dpiDataSource;
    private final DataSource federatedDataSource;
    private static final Logger log = LogManager.getLogger(MultipleDataSourcesHealthIndicator.class);

    public MultipleDataSourcesHealthIndicator(DataSource dmdDataSource, DataSource dpiDataSource, DataSource federatedDataSource) {
        this.dmdDataSource = dmdDataSource;
        this.dpiDataSource = dpiDataSource;
        this.federatedDataSource = federatedDataSource;
    }

    @Override
    public Health health() {
        Health.Builder builder = new Health.Builder();
        checkDataSource(builder, dmdDataSource, "dmdDataSource");
        checkDataSource(builder, dpiDataSource, "dpiDataSource");
        checkDataSource(builder, federatedDataSource, "federatedDataSource");
        return builder.build();
    }

    private void checkDataSource(Health.Builder builder, DataSource dataSource, String name) {

        try (Connection connection = dataSource.getConnection()) {
            if (connection.isValid(1)) {
                log.info("FC Database Health check is up");
                builder.withDetail(name, "The database connection is up").up();
            } else {
                log.info(" FC Database Health check is down");
                builder.withDetail(name, "The database connection is down").down();
            }
        } catch (SQLException exception) {
            builder.withDetail(name, "The database connection is down").withException(exception).down();
        }
    }
}
