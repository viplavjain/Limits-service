package com.vzw.tools.common.exception;
import com.vzw.tools.common.constant.CommonConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeoutException;

@Component
@Slf4j
public class ErrorBuilder {

	public FCToolsMSException buildApplicationException(Throwable err) {
		if(err instanceof FCToolsMSException fcToolsMSException){
			return fcToolsMSException;
		}
		ErrorResponse errResponse = new ErrorResponse();
		errResponse.setMessage(err.getMessage());
		errResponse.setNamespace("FC tools Namespace");
		errResponse.setName("fc-tools-ms");
		errResponse.setCode("500");
		errResponse.setId("500");
		log.error("Error while executing the request {}", ExceptionUtils.getStackTrace(err));
		if(err instanceof TimeoutException){
			errResponse.setMessage(CommonConstants.API_TIME_OUT);
		}
		if(err instanceof CustomException customException){
			errResponse.setMessage(customException.getErrorMessage());
			errResponse.setCode(customException.getErrorCode());
		}
		if(err instanceof CustomThrowableException customThrowableException){
			String message = customThrowableException.getErrorMessage();
			StringBuilder messageBuilder = new StringBuilder(message);
			Throwable cause = customThrowableException.getCause();
			while(cause!=null){
				if(cause instanceof TimeoutException){
					messageBuilder.setLength(0);
					messageBuilder.append(CommonConstants.API_TIME_OUT);
					break;
				}
				messageBuilder.append("-->").append(cause.getMessage());
				cause = cause.getCause();
			}
			errResponse.setMessage(messageBuilder.toString());
		}
		FCToolsMSException fcToolsMSException = new FCToolsMSException(errResponse);
		fcToolsMSException.setCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR));
		fcToolsMSException.setStackTrace(err.getStackTrace());
		return fcToolsMSException;

	}

	public FCToolsMSException buildBadRequest( String message) {
		ErrorResponse errResponse = new ErrorResponse();
		errResponse.setMessage(message);
		errResponse.setNamespace("FC tools Namespace");
		errResponse.setName("fc-tools-ms");
		errResponse.setCode("400");
		errResponse.setId("400");
		FCToolsMSException fcToolsMSException = new FCToolsMSException(errResponse);
		fcToolsMSException.setCode(String.valueOf(HttpStatus.BAD_REQUEST));
		return fcToolsMSException;

	}

}
