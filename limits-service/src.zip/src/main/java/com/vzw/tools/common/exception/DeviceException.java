package com.vzw.tools.common.exception;

public class DeviceException extends RuntimeException {
    private final String details;

    public DeviceException(String message, String details) {
        super(message);
        this.details = details;
    }

    public String getDetails() {
        return details;
    }
}
