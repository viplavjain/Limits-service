package com.vzw.tools.common.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.util.List;

@JsonInclude(Include.NON_NULL)
public class ErrorResponse {
    private String namespace;
    private String name;
    private String id;
    @JsonProperty("debug_id")
    private String debugId;
    private String message;
    private String code;
    private List<Details> details;

    public ErrorResponse() {
    }

    public ErrorResponse(String namespace, ErrorType errorType, String id, String debugId, String message, List<Details> details) {
        this.namespace = namespace;
        this.name = errorType.name();
        this.id = id;
        this.debugId = debugId;
        this.message = message;
        this.details = details;
    }

    public ErrorResponse(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public ErrorResponse(String namespace, String name, String id, String debugId, String message, String code) {
        this.namespace = namespace;
        this.name = name;
        this.id = id;
        this.debugId = debugId;
        this.message = message;
        this.code = code;
    }

    public String getNamespace() {
        return this.namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDebugId() {
        return this.debugId;
    }

    public void setDebugId(String debugId) {
        this.debugId = debugId;
    }

    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getCode() {
        return this.code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public List<Details> getDetails() {
        return this.details;
    }

    public void setDetails(List<Details> details) {
        this.details = details;
    }

    public String toString() {
        return "ErrorResponse{namespace='" + this.namespace + "', name='" + this.name + "', id='" + this.id + "', debugId='" + this.debugId + "', message='" + this.message + "', code='" + this.code + "', details=" + this.details + "}";
    }
}
