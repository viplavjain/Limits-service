package com.vzw.tools.common.entity;

import com.vzw.tools.common.util.IConstants;
import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.LinkedList;
import java.util.List;

@Data
@Component
public class DataFlow {
    public List<String> sourceSystems = List.of(IConstants.DPI_SYSTEM, IConstants.DMD_SYSTEM, IConstants.SAP_SYSTEM);
    public List<String> authoring = List.of(IConstants.EPC_SYSTEM);
    public List<String> dataPersistence = List.of(IConstants.CASSANDRA_SYSTEM, IConstants.FEDERATE_DB_SYSTEM);
    public List<String> cache = List.of(IConstants.REDIS_SYSTEM, IConstants.ELASTIC_SYSTEM);
    public List<String> consumers = List.of(IConstants.FUSION_SYSTEM, IConstants.CXPCATALOGDOMAIN_SYSTEM);

    public List<String> getSystemsInOrder() {
        List<String> allSystems = new LinkedList<>();
        allSystems.addAll(this.sourceSystems);
        allSystems.addAll(this.authoring);
        allSystems.addAll(this.dataPersistence);
        allSystems.addAll(this.cache);
        allSystems.addAll(this.consumers);
        return allSystems;
    }

    public List<String> getIgnorableSystemsAsSource() {
        return List.of(IConstants.FEDERATE_DB_SYSTEM, IConstants.ELASTIC_SYSTEM);
    }

}
