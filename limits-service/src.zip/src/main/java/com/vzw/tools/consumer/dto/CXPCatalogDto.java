package com.vzw.tools.consumer.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;


@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CXPCatalogDto {

    private Data data;

    @lombok.Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Data {
        private List<DeviceCatalogItems> deviceCatalogItems;
        private List<DeviceCatalogItems> accessoryCatalogItems;

        @lombok.Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class DeviceCatalogItems {
            private String productId;
            private String productDisplayName;
            private String brandName;
            private String operatingSystem;
            private String daccId;
            private List<Skus> skus;
            private List<String> equipCode;
            private String sorDeviceFamilyType;
            private StartDate startDate;
            private String sorDeviceCategory;
            private String sorDeviceType;
            private Boolean sorHdVoiceInd;
            private Boolean hasDeviceUnlockPolicy;
            private List<String> compatibleSimSorIds;
            private String additionalDisclosures;
            private String clnr;
            private String description;
            private String deviceCapabInd;
            private String deviceTypeName;
            private int deviceType;
            private Boolean displayInSiteSearch;
            private String h1Tag;
            private List<Videos> videos;
            private List<String> compatibleAccessories;
            private List<String> associatedBundles;
            private List<String> appleCareProducts;
            //private ProductSpecification productSpecification;
            private Specifications specifications;
            //private TechSpecs techSpecs;
            private float averageRating;
            private String numberOfReviews;
            private String includedAccessories;
            private String manufacturerId;
            private int metaRobotsIndex;
            private String sorImDeviceCategory;
            private String styleid;
            private List<String> categoryDisplayNames;
            private List<String> clnrSorId;
            private List<String> compatibleSimSkuIds;
            private List<String> keywords;
            private List<String> parentCategories;
            private List<String> phoneCapabilities;
            private List<String> siteIds;
            private List<String> sorIds;
            private List<String> ocpoSorIds;
            private List<PhoneCapabilityDetails> phoneCapabilityDetails;
            private String canonicalUrl;
            private String metaDescription;
            private int metaRobotsFollow;
            private String metaTitle;
            private String seoUrlName;
            private Boolean isAppleSmartPhone;
            private Boolean isEuiccCapable;
            private Boolean isEsimOnly;
            private Boolean isSMSCapable;
            private Boolean isPrePaid;
            private Boolean isDsdsCapable;
            private Boolean isAppleCareEligible;
            private String defaultSKU;
            private String isGlobalReady;
            private String simClass4G;
            private String imageName;
            private Boolean isPhone;
            private Boolean isSmartPhone;
            private Boolean isActive;
            private Boolean isShowcase;
            private Boolean isGsmCapable;
            private Boolean isV4b;
            private Boolean isWifiCalling;
            private Boolean reviewsEnabled;
            private Boolean isBuddyUpgradeEligible;
            private Boolean isIconicPhone;
            private String pairedImeiSku;
            private String prop65Warning;
            private String isE911Address;
            private String manufacturerName;
            private String sorAccessoryType;
            private String sorAccessoryTypeId;
            private Boolean isCdmaCapable;
            private String preferredSimSku;

            @lombok.Data
            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class Skus {
                private String sorId;
                private String skuDisplayName;
                private String capacity;
                private ImageUrlMap imageUrlMap;
                private Color color;
                private String sorDisplayName;
                private String sorProductFamily;
                private SimSku simSku;
                private InventoryDetails inventoryDetails;
                private Price price;
                private String carrier;
                private ProductIdMap productIdMap;
                private String imageName;
                private String prodCode1;
                private String prodCode2;
                private String prodCode3;
                private String prodCode4;
                private Boolean sellable;
                private String edgeDeviceCap;
                private String prodCode5;
                private String skuId;
                private String skuDescription;
                private String canonicalUrl;
                private String sorSkuType;
                private int capacitySize;
                private String capacityUnit;
                private String prodName;
                private String seoUrlName;
                private List<String> cpoSkus;
                private String metaRobotsFollow;
                private String creationDate;
                private Boolean displayInSiteSearch;
                private Boolean itemSaleFlag;
                private String lastModifiedTime;
                private String h1Tag;
                private String metaTitle;
                private String earlyTerminationText;
                private String deviceImageset;
                private String memory;
                private String nameColorCode;
                private List<DeviceFilters> deviceFilters;
                private Boolean restrictionEnabled;
                private Boolean is5G;
                private String upcCode;
                private String upcCodeFull;
                private Boolean isPostpay;
                private Boolean isPrepay;
                private Boolean isInStorePickup;
                private Boolean isSameDayDelivery;
                private Boolean isManualDiscountAllowed;
                private Boolean isActive;
                private Boolean isShowcase;
                private Boolean isBillToAccount;
                private String edgeDpc;
                private String edgeDpcGroup;
                private Boolean isDevicePaymentEligible;
                private String virtualSimSku;
                private String itemCost;
                private String prop65Warning;

                @lombok.Data
                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class ImageUrlMap {
                    private String defaultImage;
                    private String large;
                    private String largeImage;
                    private String medium;
                    private String mediumImage;
                    private String miniImage;
                    private String thumbImage;
                    private String imageSetUrl;
                }

                @lombok.Data
                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class Color {
                    private String colorDisplayName;
                    private String colorCssStyle;
                    private String description;
                    private String colorId;
                }

                @lombok.Data
                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class SimSku {
                    private String sorId;
                    private String skuDisplayName;
                    private String sacc;
                    private InventoryDetails inventoryDetails;
                    private Boolean isActive;
                }

                @lombok.Data
                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class InventoryDetails {
                    private DfillInventory dfillInventory;

                    @lombok.Data
                    @JsonIgnoreProperties(ignoreUnknown = true)
                    public static class DfillInventory {
                        private String locationCode;
                        private int qtyAvailable;
                        private String shipDate;
                        private Boolean isInStock;
                        private Boolean isBackorder;
                        private Boolean isShipBy;
                    }
                }

                @lombok.Data
                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class Price {
                    private FullRetailPrice fullRetailPrice;
                    private OneYearPrice oneYearPrice;
                    private OneYearPrice twoYearPrice;
                    private PrepayPrice prepayPrice;
                    private int preferredTerm;
                    private int downPayment;
                    private List<DevicePaymentPrice> devicePaymentPrice;
                    private EdgeFullRetailPrice edgeFullRetailPrice;

                    @lombok.Data
                    @JsonIgnoreProperties(ignoreUnknown = true)
                    public static class FullRetailPrice {
                        private float originalPrice;
                        private String contractText;
                    }

                    @lombok.Data
                    @JsonIgnoreProperties(ignoreUnknown = true)
                    public static class OneYearPrice {
                        private float originalPrice;
                        private String contractText;
                    }

                    @lombok.Data
                    @JsonIgnoreProperties(ignoreUnknown = true)
                    public static class PrepayPrice {
                        private float originalPrice;
                        private String contractText;
                    }

                    @lombok.Data
                    @JsonIgnoreProperties(ignoreUnknown = true)
                    public static class DevicePaymentPrice {
                        private float originalPrice;
                        private int contractDuration;
                        private String contractText;
                        private DpTermPrices dpTermPrices;

                        @lombok.Data
                        @JsonIgnoreProperties(ignoreUnknown = true)
                        public static class DpTermPrices {
                            private float firstMonthPrice;
                            private float remainingMonthPrice;
                            private int dpTerm;
                            private int downPayment;
                            private int upgradeOptionPercentage;
                            private String upgradeOptionCode;
                        }
                    }

                    @lombok.Data
                    @JsonIgnoreProperties(ignoreUnknown = true)
                    public static class EdgeFullRetailPrice {
                        private float originalPrice;
                    }
                }
                @lombok.Data
                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class ProductIdMap {
                    private String prepayProduct;
                    private String postPayProduct;
                }

                @lombok.Data
                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class DeviceFilters {
                    private String deviceFilterType;
                }
            }


            @lombok.Data
            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class StartDate {
                private String date;
                private String dateTime;
                private long dateLong;
            }

            @lombok.Data
            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class Videos {
                private String name;
                private String thumbnailImage;
                private String type;
                private String url;
                private String videoId;
            }


            @lombok.Data
            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class PhoneCapabilityDetails {
                private String keyCapabilityText;
                private Boolean keyFeaturesFlag;
                private int sequenceNum;
            }


            @lombok.Data
            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class Specifications {
                private String screenSize;
                private float weight;
                private float height;
                private float width;
                private float depth;
                private String size;
            }
        }
    }
}
