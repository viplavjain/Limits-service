package com.vzw.tools.common.service;

import com.vzw.tools.common.entity.*;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class EntityService {

    private final DataFlow dataFlow;

    EntityService(DataFlow dataFlow) {
        this.dataFlow = dataFlow;
    }

    public EntityResponse getDataFlow() {
        EntityResponse res = new EntityResponse();
        res.setFlow(dataFlow);
        return res;
    }


    private EntityDetails getEntityDetails(List<EntityRecord> data) {
        List<EntityRowDetails> rows = new ArrayList<>();
        Map<String, List<EntityRecord>> groupByFieldData = data.stream().collect(Collectors.groupingBy(EntityRecord::getField));
        groupByFieldData.forEach((field, records) -> {
            EntityRowDetails row = new EntityRowDetails();
            row.setField(field);
            Map<String, String> rowData = records.stream().collect(Collectors.toMap(EntityRecord::getSystem, EntityRecord::getValue));
            Map<String, String> sortedRowData = new LinkedHashMap<>();
            rowData.keySet().stream().sorted(Comparator.comparingInt(dataFlow.getSystemsInOrder()::indexOf))
                    .forEach(key -> sortedRowData.put(key, rowData.get(key)));
            boolean isMatch = rowData.values().stream().distinct().count() == 1;
            row.setDetails(sortedRowData);
            row.setIsMatch(isMatch);
            rows.add(row);
        });
        EntityDetails entityDetails = new EntityDetails();
        entityDetails.setEntityRowDetails(rows);
        return entityDetails;
    }

    private CompareSummary getCompareSummary(List<EntityRecord> data) {

        CompareSummary compareSummary = new CompareSummary();
        List<CompareDetails> compareDetailsList = new ArrayList<>();
        Map<String, List<EntityRecord>> groupBySystemData = data.stream().collect(Collectors.groupingBy(EntityRecord::getSystem));
        compareDetailsList.addAll(getSourceToTargetCompareDetails(groupBySystemData, dataFlow.getSourceSystems(), dataFlow.getAuthoring()));
        compareDetailsList.addAll(getSourceToTargetCompareDetails(groupBySystemData, dataFlow.getAuthoring(), dataFlow.getDataPersistence()));
        compareDetailsList.addAll(getSourceToTargetCompareDetails(groupBySystemData, dataFlow.getDataPersistence(), dataFlow.getCache()));
        compareDetailsList.addAll(getSourceToTargetCompareDetails(groupBySystemData, dataFlow.getCache(), dataFlow.getConsumers()));
        compareSummary.setCompares(compareDetailsList);
        return compareSummary;
    }

    private List<CompareDetails> getSourceToTargetCompareDetails(Map<String, List<EntityRecord>> data, List<String> sourceSystems, List<String> targetSystems) {
        List<CompareDetails> compareDetails = new ArrayList<>();
        sourceSystems.forEach(source -> {
            targetSystems.forEach(target -> {
                if (!dataFlow.getIgnorableSystemsAsSource().contains(source))
                    compareDetails.add(getCompareDataBetweenSystems(data, source, target));
            });
        });
        return compareDetails;
    }

    private CompareDetails getCompareDataBetweenSystems(Map<String, List<EntityRecord>> data, String source, String target) {

        CompareDetails compareDetails = new CompareDetails();
        compareDetails.setTarget(target);
        compareDetails.setSource(source);
        Set<EntityRecord> sourceSet = new HashSet<>(data.get(source));
        Set<EntityRecord> targetSet = new HashSet<>(data.get(target));
        compareDetails.setIsMatch(sourceSet.equals(targetSet));
        return compareDetails;
    }
}
