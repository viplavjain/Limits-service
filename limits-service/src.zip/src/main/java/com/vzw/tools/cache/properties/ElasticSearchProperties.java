package com.vzw.tools.cache.properties;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import java.util.List;

@Data
@Configuration
@Component
public class ElasticSearchProperties {

    @Value("${spring.elasticsearch.envnames}")
    public List<String> environmentNames;

    @Value("${spring.elasticsearch.promoApiUrl}")
    public String apiUrl;

    @Value("${spring.elasticsearch.bufferSize}")
    public int bufferSize;
}
