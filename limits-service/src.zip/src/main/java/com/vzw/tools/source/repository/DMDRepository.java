package com.vzw.tools.source.repository;

import com.vzw.tools.common.exception.DataBaseException;
import com.vzw.tools.source.dao.AccessoryDMDDAO;
import com.vzw.tools.source.dao.DeviceDMDDAO;
import com.vzw.tools.source.dao.DeviceDMDFamilyDAO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import java.util.Map;

import static com.vzw.tools.common.constant.CommonConstants.*;

@Repository
@Slf4j
public class DMDRepository {

    private final JdbcTemplate dmdJdbcTemplate;

    public DMDRepository(JdbcTemplate dmdJdbcTemplate) {
        this.dmdJdbcTemplate = dmdJdbcTemplate;
    }

    public Map<String, Object> fetchDeviceDMD(String sorId) throws DataBaseException {
        Map<String, Object> result;
        try {
            log.info("fetchDeviceDMD() call begins for sorId: {}", sorId);
            SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(dmdJdbcTemplate)
                    .withCatalogName(DMD_PKG)
                    .withProcedureName(SP_DEVICE)
                    .returningResultSet(DEVICE_INFO, BeanPropertyRowMapper.newInstance(DeviceDMDDAO.class));

            SqlParameterSource inParams = new MapSqlParameterSource()
                    .addValue(DEV_SKU_LIST, sorId)
                    .addValue(DATE, null);
            result = simpleJdbcCall.execute(inParams);
        } catch (Exception e) {
            log.error("Error while fetching Device DMD details for sorID:{}. Detailed message: {}", sorId, e.getMessage());
            throw new DataBaseException("Error while fetching Device DMD details");
        }
        log.info("fetchDeviceDMD() call ends for sorId: {}, result:{}", sorId, result);
        return result;
    }

    public Map<String, Object> fetchAccessoryDMD(String sorId) throws DataBaseException {
        Map<String, Object> result = null;
        try {
            log.info("fetchAccessoryDMD() call begins for sorId: {}", sorId);
            SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(dmdJdbcTemplate)
                    .withCatalogName(DMD_PKG)
                    .withProcedureName(SP_ACCESSORY)
                    .returningResultSet(ACCESSORY_INFO, new BeanPropertyRowMapper<>(AccessoryDMDDAO.class));

            SqlParameterSource inParams = new MapSqlParameterSource()
                    .addValue(ACC_SKU_LIST, sorId)
                    .addValue(DATE, null);
            result = simpleJdbcCall.execute(inParams);
        } catch (Exception e) {
            log.error("Error while fetching Accessory DMD details for sorID:{}. Detailed message: {}", sorId, e.getMessage());
            throw new DataBaseException("Error while fetching Accesory DMD details");
        }
        log.info("fetchAccessoryDMD() call ends for sorId: {}, result:{}", sorId, result);
        return result;
    }

    public Map<String, Object> fetchDeviceFamilyDMD(String sorId) throws DataBaseException {
        Map<String, Object> result;
        try {
            log.info("fetchDeviceFamilyDMD() call begins for sorId: {}", sorId);
            SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(dmdJdbcTemplate)
                    .withCatalogName(DMD_PKG)
                    .withProcedureName(SP_DEVICE_FAMILY)
                    .returningResultSet(DEVICE_INFO, BeanPropertyRowMapper.newInstance(DeviceDMDFamilyDAO.class));
            SqlParameterSource inParams = new MapSqlParameterSource()
                    .addValue(DEV_SKU_LIST, sorId)
                    .addValue(DATE, null);
            result = simpleJdbcCall.execute(inParams);
        } catch (Exception e) {
            log.error("Error while fetching DMD Device Family details for sorID:{}. Detailed message: {}", sorId, e.getMessage());
            throw new DataBaseException("Error while fetching DMD Device Family details");
        }
        log.info("fetchDeviceFamilyDMD() call ends for sorId: {}, result:{}", sorId, result);
        return result;
    }

}
