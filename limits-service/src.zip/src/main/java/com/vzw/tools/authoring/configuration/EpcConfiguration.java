package com.vzw.tools.authoring.configuration;

import com.vzw.tools.authoring.properties.EpcProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EpcConfiguration {

    private final EpcProperties epcProperties;

    public EpcConfiguration(EpcProperties epcProperties) {
        this.epcProperties = epcProperties;
    }

    public String getAmdocsSearchApi(String env) {
        if (env.equalsIgnoreCase("QA1")) {
            return epcProperties.getAmdocsSearchApiHost().getQa1();
        } else if (env.equalsIgnoreCase("QA2")) {
            return epcProperties.getAmdocsSearchApiHost().getQa2();
        } else if (env.equalsIgnoreCase("QA3")) {
            return epcProperties.getAmdocsSearchApiHost().getQa3();
        } else {
            return "";
        }
    }

    public String getAmdocsProductApi(String env) {
        if (env.equalsIgnoreCase("QA1")) {
            return epcProperties.getAmdocsProductApiHost().getQa1();
        } else if (env.equalsIgnoreCase("QA2")) {
            return epcProperties.getAmdocsProductApiHost().getQa2();
        } else if (env.equalsIgnoreCase("QA3")) {
            return epcProperties.getAmdocsProductApiHost().getQa3();
        } else {
            return "";
        }
    }

    public String getToken(String env) {
        if (env.equalsIgnoreCase("QA1")) {
            return epcProperties.getToken().getQa1();
        } else if (env.equalsIgnoreCase("QA2")) {
            return epcProperties.getToken().getQa2();
        } else if (env.equalsIgnoreCase("QA3")) {
            return epcProperties.getToken().getQa3();
        } else {
            return "";
        }
    }

    public String getProductOfferingPrice(String env) {
        if (env.equalsIgnoreCase("QA1")) {
            return epcProperties.getPopurl().getQa1();
        } else if (env.equalsIgnoreCase("QA2")) {
            return epcProperties.getPopurl().getQa2();
        } else if (env.equalsIgnoreCase("QA3")) {
            return epcProperties.getPopurl().getQa3();
        } else {
            return "";
        }
    }



}
