package com.vzw.tools.cache.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.vzw.tools.cache.constant.ElasticServiceConstants;
import com.vzw.tools.cache.service.ElasticSearchService;
import com.vzw.tools.cache.service.RedisService;
import com.vzw.tools.common.exception.ErrorBuilder;
import com.vzw.tools.common.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.io.IOException;

@RestController
@Slf4j
public class CacheController {

    private final RedisService redisService;
    private final ElasticSearchService elasticSearchService;
    private final ErrorBuilder errorBuilder;

    @Autowired
    public CacheController(RedisService redisService,
                           ElasticSearchService elasticSearchService, ErrorBuilder errorBuilder) {
        this.redisService = redisService;
        this.elasticSearchService = elasticSearchService;
        this.errorBuilder = errorBuilder;
    }

    @GetMapping("/redis/{productType}/{env}")
    public Mono<Object> getRedisData(@PathVariable String productType,
                                     @PathVariable String env, @RequestParam(value = "id", required = true) String id) throws IllegalAccessException {
        log.info(" Begin redis API call for product Type:{},on environment:{}", productType, env);
       return redisService.redisData(id, productType, env)
               .onErrorMap(err -> errorBuilder.buildApplicationException(err));
    }

    @GetMapping("/elasticSearch/{productType}/{env}")
    public Mono<Object> getElasticSearchData(@PathVariable String productType,
                                             @PathVariable String env, @RequestParam(value = "id", required = true) String id) throws IOException {
        if (productType.equalsIgnoreCase(ElasticServiceConstants.DEVICE) || ElasticServiceConstants.ACCESSORY.equalsIgnoreCase(productType)) {
            return elasticSearchService.elasticSearchData1(id, productType, env)
                    .onErrorMap(errorBuilder::buildApplicationException);
        } else if (ElasticServiceConstants.PROMOTION.equalsIgnoreCase(productType)) {
            Mono<JsonNode> response = elasticSearchService.elasticSearchPromotionData(id)
                    .onErrorMap(errorBuilder::buildApplicationException);
            return CommonUtil.getPromotionDetails(response);
        }
        return Mono.empty();
    }

}
