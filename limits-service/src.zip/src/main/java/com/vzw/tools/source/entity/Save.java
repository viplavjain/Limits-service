package com.vzw.tools.source.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class Save {

    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonProperty("accSku")
    private List<String> accSku;
}
