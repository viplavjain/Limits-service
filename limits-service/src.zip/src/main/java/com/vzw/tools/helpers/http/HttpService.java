

package com.vzw.tools.helpers.http;


import java.nio.charset.Charset;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

import com.fasterxml.jackson.databind.JsonNode;
import com.vzw.tools.common.exception.ExceptionTranslator;
import com.vzw.tools.common.exception.NoActionExceptionTranslator;
import com.vzw.tools.common.exception.StackTraceUtils;
import com.vzw.tools.helpers.logging.Event;
import com.vzw.tools.helpers.logging.EventLogger;
import com.vzw.tools.helpers.logging.LogConstants;
import com.vzw.tools.helpers.logging.vo.TraceInfo;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;
import reactor.core.publisher.Mono;

public class HttpService {
    private static Logger logger = LoggerFactory.getLogger(HttpService.class);
    private WebClient webClient;
    private String baseUrl;
    private String systemName;
    private String externalCorrelationIdHeaderName;
    private EventLogger eventLogger;
    private ExceptionTranslator exceptionTranslator;

    /** @deprecated */
    @Deprecated
    public HttpService(WebClient webClient, String baseUrl, String systemName, EventLogger eventLogger) {
        this(webClient, baseUrl, systemName, LogConstants.CORRELATION_ID, eventLogger, new NoActionExceptionTranslator());
    }

    /** @deprecated */
    @Deprecated
    public HttpService(WebClient webClient, String baseUrl, String systemName, String externalCorrelationIdHeaderName, EventLogger eventLogger, ExceptionTranslator exceptionTranslator) {
        this.baseUrl = baseUrl;
        logger.info("Using URL  {}", baseUrl);
        this.webClient = webClient;
        this.systemName = systemName;
        this.externalCorrelationIdHeaderName = externalCorrelationIdHeaderName;
        this.eventLogger = eventLogger;
        this.exceptionTranslator = exceptionTranslator;
    }

    public Mono<String> postRequest(String request, Map<String, String> headers, String functionName) {
        return this.postRequest(request, headers, (String)null, functionName);
    }

    public Mono<String> postRequest(final String request, Map<String, String> headers, String uri, String functionName) {
        return this.postRequest(new OutboundRequest() {
            public String rawHttpBody() {
                return request;
            }

            public String functionName() {
                return "NA";
            }
        }, headers, uri, (s) -> {
            return Mono.just(s);
        }, functionName);
    }

    public <T> Mono<T> postRequest(OutboundRequest request, Map<String, String> headers, String uri, Function<String, Mono<T>> converter, String functionName) {
        return Mono.deferContextual((c) -> {
            long start = System.currentTimeMillis();
            String var10000 = this.baseUrl;
            String url = var10000 + (StringUtils.isAllBlank(new CharSequence[]{uri}) ? "" : uri);
            logger.trace("Calling {}", url);
            TraceInfo traceInfo = c.hasKey("cxpds_trace_info") ? (TraceInfo)c.get("cxpds_trace_info") : null;
            WebClient.RequestHeadersSpec<?> requestSpec2 = ((WebClient.RequestBodySpec)this.webClient.post().uri(url, new Object[0])).contentType(MediaType.APPLICATION_JSON).body(BodyInserters.fromPublisher(Mono.just(request.rawHttpBody()), String.class));
            headers.forEach((k, v) -> {
                requestSpec2.header(k, new String[]{v});
            });
            Mono<T> response = requestSpec2.acceptCharset(new Charset[]{Charset.forName("UTF-8")}).exchangeToMono((cr) -> {
                HttpStatus status = (HttpStatus)cr.statusCode();
                logger.trace("Response Headers {} , status code {}  ", StringUtils.join(new HttpHeaders[]{cr.headers().asHttpHeaders()}), cr.statusCode());
                String externalId = cr.headers().asHttpHeaders().getFirst(this.externalCorrelationIdHeaderName);
                Mono<String> res = cr.bodyToMono(String.class).doOnSuccess((r) -> {
                    this.logEvent(r, (OutboundRequest)request, start, System.currentTimeMillis(), traceInfo, status.value(), (String)null, (String)null, externalId, headers.toString(), cr.headers().asHttpHeaders().toString(), HttpMethod.POST.toString(), functionName);
                });
                return !status.is2xxSuccessful() && this.exceptionTranslator.canTranslate(status.value()) ? Mono.error(this.exceptionTranslator.translate(status.value(), status.getReasonPhrase())) : res.flatMap((r) -> {
                    return (Mono)converter.apply(r);
                });
            }).doOnError((t1) -> {
                this.logEvent((String)null, (OutboundRequest)request, start, System.currentTimeMillis(), traceInfo, 500, ((Throwable)t1).getMessage(), StackTraceUtils.stackTraceAsString(((Throwable)t1)), (String)null, headers.toString(), (String)null, HttpMethod.POST.toString(), functionName);
            }).onErrorMap((t) -> {
                logger.warn("Caught error {} , exception handler {} ", t.getClass().getName(), this.exceptionTranslator);
                return this.exceptionTranslator.canTranslate(((Throwable)t));
            }, (t) -> {
                return this.exceptionTranslator.translate(((Throwable)t));
            });
            return response;
        });
    }
    public Mono<String> get(MultiValueMap<String, String> queryParams, Map<String, String> headers, String functionName) {
        return this.get(Collections.emptyMap(), queryParams, headers, functionName);
    }

    public Mono<String> get(Map<String, String> pathParams, Map<String, String> headers, String functionName) {
        return this.get(pathParams, (MultiValueMap)null, headers, functionName);
    }
    public Mono<String> get(Map<String, String> pathParams, MultiValueMap<String, String> queryParams, Map<String, String> headers, String functionName) {
        return Mono.deferContextual((c) -> {
            long start = System.currentTimeMillis();
            logger.trace("Calling {}", this.baseUrl);
            TraceInfo traceInfo = c.hasKey("cxpds_trace_info") ? (TraceInfo)c.get("cxpds_trace_info") : null;
            UriComponents uri = UriComponentsBuilder.fromHttpUrl(this.baseUrl).build();
            Mono<String> response = this.webClient.get().uri((uriBuilder) -> {
                return uriBuilder.host(uri.getHost()).path(uri.getPath()).scheme(uri.getScheme()).port(uri.getPort()).queryParams(queryParams).build(pathParams);
            }).headers((httpHeaders) -> {
                headers.forEach((k, v) -> {
                    httpHeaders.add(k, v);
                });
            }).exchangeToMono((cr) -> {
                HttpStatus status = (HttpStatus)cr.statusCode();
                logger.trace("Response Headers");
                cr.headers().asHttpHeaders().forEach((k, v) -> {
                    logger.trace(k + "\t" + (String)v.get(0));
                });
                String externalId = cr.headers().asHttpHeaders().getFirst(this.externalCorrelationIdHeaderName);
                Mono<String> res = cr.bodyToMono(String.class).doOnSuccess((r) -> {
                    this.logEvent(r, (String)StringUtils.join(new MultiValueMap[]{queryParams}), start, System.currentTimeMillis(), traceInfo, status.value(), (String)null, (String)null, externalId, headers.toString(), cr.headers().asHttpHeaders().toString(), HttpMethod.GET.toString(), functionName);
                });
                return !status.is2xxSuccessful() ? Mono.error(this.exceptionTranslator.translate(status.value(), status.getReasonPhrase())) : res;
            }).doOnError((t1) -> {
                this.logEvent((String)null, (String)StringUtils.join(new MultiValueMap[]{queryParams}), start, System.currentTimeMillis(), traceInfo, 500, t1.getMessage(), StackTraceUtils.stackTraceAsString(t1), (String)null, headers.toString(), (String)null, HttpMethod.GET.toString(), functionName);
            }).onErrorMap((t) -> {
                logger.warn("Caught error {} ", t.getClass().getName());
                return this.exceptionTranslator.canTranslate(t);
            }, (t) -> {
                return this.exceptionTranslator.translate(t);
            });
            return response;
        });
    }

    public <T> Mono<T> get(Map<String, String> pathParams, MultiValueMap<String, String> queryParams, Map<String, String> headers, Function<ClientResponse, Mono<T>> converter) {
        return Mono.deferContextual((c) -> {
            long start = System.currentTimeMillis();
            logger.trace("Calling {}", this.baseUrl);
            Optional<TraceInfo> traceInfo = c.getOrEmpty("cxpds_trace_info");
            UriComponents uri = UriComponentsBuilder.fromHttpUrl(this.baseUrl).build();
            Mono<T> response = this.webClient.get().uri((uriBuilder) -> {
                return uriBuilder.host(uri.getHost()).path(uri.getPath()).scheme(uri.getScheme()).port(uri.getPort()).queryParams(queryParams).build(pathParams);
            }).headers((httpHeaders) -> {
                headers.forEach((k, v) -> {
                    httpHeaders.add(k, v);
                });
            }).exchangeToMono((cr) -> {
                HttpStatus status = (HttpStatus)cr.statusCode();
                logger.trace("Response Headers");
                cr.headers().asHttpHeaders().forEach((k, v) -> {
                    logger.trace(k + "\t" + (String)v.get(0));
                });
                String externalId = cr.headers().asHttpHeaders().getFirst(this.externalCorrelationIdHeaderName);
                Mono<T> res = ((Mono)converter.apply(cr)).doOnSuccess((r) -> {
                    this.logEvent(r.toString(), (String)StringUtils.join(new MultiValueMap[]{queryParams}), start, System.currentTimeMillis(), (TraceInfo)traceInfo.get(), status.value(), (String)null, (String)null, externalId, headers.toString(), cr.headers().asHttpHeaders().toString(), HttpMethod.GET.toString(), (String)null);
                });
                return !status.is2xxSuccessful() ? Mono.error(this.exceptionTranslator.translate(status.value(), status.getReasonPhrase())) : res;
            }).doOnError((t1) -> {
                this.logEvent((String)null, (String)StringUtils.join(new MultiValueMap[]{queryParams}), start, System.currentTimeMillis(), (TraceInfo)traceInfo.get(), 500, t1.getMessage(), StackTraceUtils.stackTraceAsString(t1), (String)null, headers.toString(), (String)null, HttpMethod.GET.toString(), (String)null);
            }).onErrorMap((t) -> {
                logger.warn("Caught error {} ", t.getClass().getName());
                return this.exceptionTranslator.canTranslate(t);
            }, (t) -> {
                return this.exceptionTranslator.translate(t);
            });
            return response;
        });
    }
    private void logEvent(String response, String request, long start, long end, TraceInfo t, int statusCode, String errorMessage, String detailedMessage, String externalId, String requestHeaders, String responseHeaders, String httpMethod, String functionName) {
        Event event = new Event();
        event.setEventType("external_request");
        event.setExternalSystem(this.systemName);
        event.setEndTime(end);
        event.setStartTime(start);
        event.setDuration(end - start);
        event.setApiRequest(request);
        event.setApiResponse(response);
        if (t != null) {
            event.setCorrelationId(t.getCorrelationId());
            event.setE2eRequestId(t.getE2eRequestId());
            event.setSessionId(t.getSessionId());
            event.setAppSessionId(t.getSessionId());
            event.setDomainCorrelationId(t.getDomainCorrelationId());
            event.setRouteType(t.getRouteType());
            event.setLogPayload(t.isLogPayload());
            event.setClientId(t.getClientId());
        }

        event.setResponseStatusCode("" + statusCode);
        event.setStatusCode(statusCode);
        event.setHttpStatusCode(statusCode);
        event.setErrorMessage(errorMessage);
        event.setResponseStatusDetailedMessage(detailedMessage);
        event.setExternalCorrelationId(externalId);
        event.setApiUrl(this.baseUrl);
        if (!HttpStatus.valueOf(statusCode).is2xxSuccessful()) {
            event.setStatusMessage("ERROR");
        } else {
            event.setStatusMessage("SUCCESS");
            event.setApiStatusMsg("Transaction processed successfully.");
        }

        event.setRequestHeaders(requestHeaders);
        event.setResponseHeaders(responseHeaders);
        event.setRequestSize(StringUtils.length(request));
        event.setResponseSize(StringUtils.length(response));
        event.setHttpVerb(httpMethod);
        event.setHttpMethod(httpMethod);
        event.setFunctionName(functionName);
        event.setLogType("OutboundCall");
        this.eventLogger.logEvent(event);
    }

    private void logEvent(String response, OutboundRequest request, long start, long end, TraceInfo t, int statusCode, String errorMessage, String detailedMessage, String externalId, String requestHeaders, String responseHeaders, String httpMethod, String functionName) {
        this.logEvent(response, request.rawHttpBody(), start, end, t, statusCode, errorMessage, detailedMessage, externalId, requestHeaders, responseHeaders, httpMethod, null != functionName ? functionName : request.functionName());
    }

    public static Builder builder() {
        return new Builder();
    }

    public interface OutboundRequest {
        String rawHttpBody();

        String functionName();
    }

    public static class Builder {
        private WebClient webClient;
        private String baseUrl;
        private String systemName;
        private String externalCorrelationIdHeaderName;
        private EventLogger eventLogger;
        private ExceptionTranslator exceptionTranslator;

        public Builder() {
            this.externalCorrelationIdHeaderName = LogConstants.CORRELATION_ID;
        }

        public Builder webClient(WebClient webClient) {
            this.webClient = webClient;
            return this;
        }

        public Builder eventLogger(EventLogger eventLogger) {
            this.eventLogger = eventLogger;
            return this;
        }

        public Builder exceptionTranslator(ExceptionTranslator exceptionTranslator) {
            this.exceptionTranslator = exceptionTranslator;
            return this;
        }

        public Builder baseUrl(String baseUrl) {
            this.baseUrl = baseUrl;
            return this;
        }

        public Builder systemName(String systemName) {
            this.systemName = systemName;
            return this;
        }

        public Builder externalCorrelationIdHeaderName(String externalCorrelationIdHeaderName) {
            this.externalCorrelationIdHeaderName = externalCorrelationIdHeaderName;
            return this;
        }

        public HttpService build() {
            if (this.exceptionTranslator == null) {
                this.exceptionTranslator = new NoActionExceptionTranslator();
            }

            return new HttpService(this.webClient, this.baseUrl, this.systemName, this.externalCorrelationIdHeaderName, this.eventLogger, this.exceptionTranslator);
        }
    }


    public Mono<String> postRequestWithParams(Map<String, String> pathParams, MultiValueMap<String, String> queryParams,final String request, Map<String, String> headers, String uri, String functionName) {
        return this.postRequestWithParams(pathParams, queryParams,new OutboundRequest() {
            public String rawHttpBody() {
                return request;
            }

            public String functionName() {
                return "NA";
            }
        }, headers, uri, (s) -> {
            return Mono.just(s);
        }, functionName);
    }
    public <T> Mono<T> postRequestWithParams(Map<String, String> pathParams, MultiValueMap<String, String> queryParams, OutboundRequest request, Map<String, String> headers, String uri, Function<String, Mono<T>> converter, String functionName) {
        return Mono.deferContextual((c) -> {
            long start = System.currentTimeMillis();
            String var10000 = this.baseUrl;
            String url = var10000 + (StringUtils.isAllBlank(new CharSequence[]{uri}) ? "" : uri);
            UriComponents uriNew = UriComponentsBuilder.fromHttpUrl(url).build();
            logger.trace("Calling {}", url);
            TraceInfo traceInfo = c.hasKey("cxpds_trace_info") ? (TraceInfo)c.get("cxpds_trace_info") : null;
            WebClient.RequestHeadersSpec<?> requestSpec2 = ((WebClient.RequestBodySpec)this.webClient.post()
                    .uri((uriBuilder) -> {
                        return uriBuilder.host(uriNew.getHost()).path(uriNew.getPath()).scheme(uriNew.getScheme()).port(uriNew.getPort()).queryParams(queryParams).build(pathParams);
                    }).contentType(MediaType.APPLICATION_JSON).body(BodyInserters.fromPublisher(Mono.just(request.rawHttpBody()), String.class)));
            headers.forEach((k, v) -> {
                requestSpec2.header(k, new String[]{v});
            });
            Mono<T> response = requestSpec2.acceptCharset(new Charset[]{Charset.forName("UTF-8")}).exchangeToMono((cr) -> {
                HttpStatus status = (HttpStatus)cr.statusCode();
                logger.trace("Response Headers {} , status code {}  ", StringUtils.join(new HttpHeaders[]{cr.headers().asHttpHeaders()}), cr.statusCode());
                String externalId = cr.headers().asHttpHeaders().getFirst(this.externalCorrelationIdHeaderName);
                Mono<String> res = cr.bodyToMono(String.class).doOnSuccess((r) -> {
                    this.logEvent(r, (OutboundRequest)request, start, System.currentTimeMillis(), traceInfo, status.value(), (String)null, (String)null, externalId, headers.toString(), cr.headers().asHttpHeaders().toString(), HttpMethod.POST.toString(), functionName);
                });
                return !status.is2xxSuccessful() && this.exceptionTranslator.canTranslate(status.value()) ? Mono.error(this.exceptionTranslator.translate(status.value(), status.getReasonPhrase())) : res.flatMap((r) -> {
                    return (Mono)converter.apply(r);
                });
            }).doOnError((t1) -> {
                this.logEvent((String)null, (OutboundRequest)request, start, System.currentTimeMillis(), traceInfo, 500, ((Throwable)t1).getMessage(), StackTraceUtils.stackTraceAsString(((Throwable)t1)), (String)null, headers.toString(), (String)null, HttpMethod.POST.toString(), functionName);
            }).onErrorMap((t) -> {
                logger.warn("Caught error {} , exception handler {} ", t.getClass().getName(), this.exceptionTranslator);
                return this.exceptionTranslator.canTranslate(((Throwable)t));
            }, (t) -> {
                return this.exceptionTranslator.translate(((Throwable)t));
            });
            return response;
        });
    }
}
