package com.vzw.tools.consumer.controller;

import static com.vzw.tools.common.constant.CommonConstants.APPLICATION_JSON;
import static com.vzw.tools.common.constant.CommonConstants.CONTENT_TYPE;

import com.vzw.tools.common.exception.ErrorBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.vzw.tools.consumer.service.CXPService;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@RestController
@Slf4j
public class ConsumerController {

    private final CXPService cxpService;
    private final ErrorBuilder errorBuilder;

    public ConsumerController(CXPService cxpService,ErrorBuilder errorBuilder){
        this.cxpService= cxpService;
        this.errorBuilder=errorBuilder;
    }

    @GetMapping("/cxp/{productType}/{env}")
    public Mono<ResponseEntity<JsonNode>> getCXPCatalogDomain(@PathVariable String productType, @PathVariable String env, @RequestParam(value = "id", required = true) String id) throws JsonProcessingException {
        log.info(" Begin getCXPCatalogDomain API call for id: {}, product Type:{},on environment:{}", id, productType, env);
        Mono<JsonNode> cxpData = cxpService.getCXPCatalogDetails(id, productType, env);
        log.info(" End getCXPCatalogDomain API call for id: {}, product Type:{},on environment:{}", id, productType, env);
        return cxpData
                .map(jsonData -> ResponseEntity
                        .ok()
                        .header(CONTENT_TYPE, APPLICATION_JSON)
                        .body(jsonData))
                .onErrorMap(err -> errorBuilder.buildApplicationException(err));
    }
}
