package com.vzw.tools.source.controller;


import com.fasterxml.jackson.databind.JsonNode;
import com.vzw.tools.common.exception.DataBaseException;
import com.vzw.tools.common.exception.ErrorBuilder;
import com.vzw.tools.common.exception.FCToolsMSException;
import com.vzw.tools.common.exception.XmlConversionException;
import com.vzw.tools.source.dao.DeviceDPIDAO;
import com.vzw.tools.source.service.DMDService;
import com.vzw.tools.source.service.DPIService;
import com.vzw.tools.source.service.OMPService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.util.Map;


@RestController
@Slf4j
public class SourceController {

    private final DMDService dmdService;
    private final DPIService dpiService;
    private final OMPService ompService;

    private ErrorBuilder errorBuilder;

    @Autowired
    public SourceController(DMDService dmdService, DPIService dpiService, ErrorBuilder errorBuilder, OMPService ompService) {
        this.dmdService = dmdService;
        this.dpiService = dpiService;
        this.errorBuilder = errorBuilder;
        this.ompService = ompService;
    }

    @GetMapping("/dmd/{productType}/{env}")
    public Mono<ResponseEntity<JsonNode>> getDMD(@PathVariable String productType,
                                                 @PathVariable String env,
                                                 @RequestParam(value = "id", required = true) String id) throws XmlConversionException, DataBaseException {
        log.info(" Begin getDMD API call for product Type:{},on environment:{}", productType, env);
        Mono<JsonNode> dmdData = dmdService.getDMDDetails(id, productType);
        return dmdData.flatMap(res ->
             Mono.just(ResponseEntity
                            .ok()
                            .contentType(MediaType.APPLICATION_JSON)
                            .body(res))
        ).onErrorMap(err -> {
            if(err instanceof FCToolsMSException) return err;
            else return errorBuilder.buildApplicationException(err);
        });

    }

    @GetMapping("/dpi/{productType}/{env}")
    public Mono<ResponseEntity<DeviceDPIDAO>> getDPI(@PathVariable String productType,
                                               @PathVariable String env,
                                               @RequestParam(value = "id", required = true) String id) throws XmlConversionException, DataBaseException {
        log.info(" Begin getDPI API call for product Type:{},on environment:{}", productType, env);
        Mono<DeviceDPIDAO> dpiData = dpiService.getDPIDeviceDetails(id, productType, env);
        log.info(" End getDPI API call for product Type:{},on environment:{}", productType, env);
        return dpiData.flatMap(res ->
                Mono.just(ResponseEntity
                        .ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(res))
        ).onErrorMap(err -> {
            if (err instanceof FCToolsMSException) return err;
            else return errorBuilder.buildApplicationException(err);
        });


    }

    @GetMapping("/omp/{productType}/{env}")
    public Mono<ResponseEntity<Map<String, String>>> getOMP(@PathVariable String productType,
                                                            @PathVariable String env,
                                                            @RequestParam(value = "id", required = true) String offerId) throws XmlConversionException, DataBaseException {
        log.info(" Begin getOMP API call for product Type:{},on environment:{}", productType, env);
        Mono<Map<String, String>> ompData = ompService.getOMPPromotionDetails(offerId, productType, env);
        log.info(" End getOMP API call for product Type:{},on environment:{}", productType, env);
        return ompData.flatMap(res ->
                Mono.just(ResponseEntity
                        .ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(res))
        ).onErrorMap(err -> {
            if (err instanceof FCToolsMSException) return err;
            else return errorBuilder.buildApplicationException(err);
        });
    }
}