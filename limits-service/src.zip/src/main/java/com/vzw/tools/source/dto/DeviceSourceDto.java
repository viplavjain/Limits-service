package com.vzw.tools.source.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

@Component
@Getter
@Setter
@ToString
public class DeviceSourceDto {

    private String prodName;
    private String familyName;
    private String mfgCode;
    private String mfgName;
    private String prodType;
    private String dacc;
    private String imProdName;
    private String imImageUrl;
    private String imDeviceCategory;
    private String deviceType;
    private String globalPhone;
    private String deviceCategory;
    private String deviceCapabilityInd;
    private String backupAssistCapable;
    private String preferredSim;
    private String preferredSoftSim;
    private String alternateSim;
    private String simClass4G;
    private String nfcCapable;
    private String nfcCompatible;
    private String smsCapable;
    private String deviceFamilyType;
    private String buddyUpgrdEligInd;
    private String restrictToFamilyInd;
    private String hdVoice;
    private String coverageCheck4G;
    private String v4b;
    private String numberShareCapable;
    private String euiccCapable;
    private String esimOnlyInd;
    private String vendorKey;
    private String dsds;
    private String operatingSystem;
    private String eligibleNumShareOS;
    private String universalDevice;
    private String wifiCalling;
    private String e911AddrInd;
    private String cdmaCapableInd;
    private String gsmCapableInd;
    private String deviceCarrier;
    private String postpaidRestrictStartDate;
    private String prepayRestrictStartDate;
    private List<String> universalPropCdList;
    private String deviceSku;
    private String virtualSimSku;
    private String skuType;
    private String prodCode1;
    private String prodCode2;
    private String prodCode3;
    private String prodCode4;
    private String prodCode5;
    private String btaEligiblity;
    private String upcCode;
    private String prepaySkuInd;
    private String edgeEligibleInd;
    private String edgeDpcGroup;
    private String edgeDpcItem;
    private String itemCost;
    private String imEquipId;
    private String upcCodeFull;
    private String edgeDeviceCap;
    private String instantCredit;
    private String ispuEligible;
    private String prop65;
    private String pairedImeiSKu;
    private List<String> marketingCompatibleSimSkuList;

    private String sku;
    private BigDecimal oneYearPrice;
    private BigDecimal twoYearPrice;
    private BigDecimal prepayPrice;
    private BigDecimal fullRetailPrice;
    private String locationCode;
    private String edgeSku;
    private BigDecimal edgeFullRetailPrice;

    private List<String> imAccessoryList;
}
