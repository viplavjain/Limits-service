package com.vzw.tools.helpers.logging;

public class Event extends com.vzw.tools.helpers.logging.vo.Event {
    public String toString() {
        return "Event(super=" + super.toString() + ")";
    }

    public Event() {
    }

    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        } else if (!(o instanceof Event)) {
            return false;
        } else {
            Event other = (Event)o;
            return other.canEqual(this);
        }
    }

    protected boolean canEqual(final Object other) {
        return other instanceof Event;
    }

    public int hashCode() {
        //int result = true;
        return 1;
    }
}
