package com.vzw.tools;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.tools.helpers.http.HttpService;
import com.vzw.tools.helpers.logging.EventLogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.reactive.function.client.WebClient;


@SpringBootApplication
@ComponentScan("com.vzw.tools")
public class FederatedCatalogToolsMsApplication  {

    @Value("${spring.epc.token.url:#{null}}")
    private String tokenUrl;

    @Value("${spring.epc.amdocsHost.baseUrl:#{null}}")
    private String amdocsBaseUrl;

    @Value("${spring.epc.amdocsHost.promotions:#{null}}")
    private String promotionUri;

    @Value("${spring.epc.amdocsHost.price:#{null}}")
    private String priceUri;

    @Value("${spring.epc.amdocs_productapi_host.qa1:#{null}}")
    private String epcProductApiUrl;






    public static void main(String[] args) {
        SpringApplication.run(FederatedCatalogToolsMsApplication.class, args);
    }

    @Bean
    @Qualifier("tokenGenerator")
    public HttpService epcTokenGenerator(WebClient webclient, EventLogger eventLogger) {
        return HttpService.builder().webClient(webclient)
                .baseUrl(tokenUrl).systemName("fc-tools-ms")
                .eventLogger(eventLogger).build();

    }

    @Bean
    @Qualifier("amdocsHost")
    public HttpService epcAmdocsHost(WebClient webclient, EventLogger eventLogger) {
        return HttpService.builder().webClient(webclient)
                .baseUrl(amdocsBaseUrl).systemName("fc-tools-ms")
                .eventLogger(eventLogger).build();

    }

    @Bean
    @Qualifier("amdocsPromotions")
    public HttpService epcAmdocsPromotions(WebClient webclient, EventLogger eventLogger) {
        return HttpService.builder().webClient(webclient)
                .baseUrl(amdocsBaseUrl+promotionUri).systemName("fc-tools-ms")
                .eventLogger(eventLogger).build();
    }

    @Bean
    @Qualifier("amdocsPriceRecords")
    public HttpService epcAmdocsPriceRecords(WebClient webclient, EventLogger eventLogger) {
        return HttpService.builder().webClient(webclient)
                .baseUrl(amdocsBaseUrl+priceUri).systemName("fc-tools-ms")
                .eventLogger(eventLogger).build();

    }

    @Bean
    public ObjectMapper getObjectMapper(){
        return new ObjectMapper();
    }
}
