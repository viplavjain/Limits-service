package com.vzw.tools.cache.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class RedisAccessoryDto {

    private String skuDisplayName;
    private String skuDescription;
    private String manufacturerName;
    private String sorAccessoryType;
    private String sorAccessoryTypeId;
    private String upcCode;
    private String upcCodeFull;
    private String isBillToAccount;
    private String edgedpc;
    private String edgedpcgroup;
    private String imageUrlMap;
    private String inStorePickupFlag;
    private String prodCode1;
    private String prodCode2;
    private String prodCode3;
    private String prodCode4;
    private String prodCode5;
    private String prop65Warning;
    private String seoUrlName;
    private String sorId;
    private String h1Tag;
    private String fullRetailPrice;
}
