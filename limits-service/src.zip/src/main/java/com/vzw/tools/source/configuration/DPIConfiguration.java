package com.vzw.tools.source.configuration;

import com.vzw.tools.source.properties.DPIProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;

@Component
public class DPIConfiguration {

    private final DPIProperties dpiProperties;

    public DPIConfiguration(DPIProperties dpiProperties) {
        this.dpiProperties = dpiProperties;
    }

    @Bean(name = "dpiDataSource")
    public DataSource dpiDataSource() {
        DriverManagerDataSource dpiDataSource = new DriverManagerDataSource();
        dpiDataSource.setUrl(dpiProperties.getUrl());
        dpiDataSource.setUsername(dpiProperties.getUsername());
        dpiDataSource.setPassword(dpiProperties.getPassword());
        return dpiDataSource;
    }

    @Bean(name = "dpiJdbcTemplate")
    public JdbcTemplate dpiJdbcTemplate() {
        return new JdbcTemplate(dpiDataSource());

    }

}

