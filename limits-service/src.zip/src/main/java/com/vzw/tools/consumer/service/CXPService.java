package com.vzw.tools.consumer.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.vzw.tools.common.exception.CustomThrowableException;
import com.vzw.tools.common.util.CommonUtil;
import com.vzw.tools.consumer.configuration.CXPConfiguration;
import com.vzw.tools.consumer.constant.CXPConstant;
import com.vzw.tools.consumer.dto.CXPCatalogDto;
import com.vzw.tools.source.configuration.RunTimeMapInitializer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;


@Service
@Slf4j
public class CXPService {

    private WebClient webClient = WebClient.builder().build();
    private final CXPConfiguration cxpConfiguration;
    @Value("${spring.webclient.timeout:30}")
    public int timeoutInSeconds;

    public CXPService(CXPConfiguration cxpConfiguration){
        this.cxpConfiguration = cxpConfiguration;
    }

    @Autowired
    RunTimeMapInitializer runTimeMapInitializer;

    public Mono<JsonNode> getCXPCatalogDetails(String id, String productType, String env) {
        String apiUrl = cxpConfiguration.getAPIUrl(env);
        String requestBody = null;
        switch (productType){
            case CXPConstant.PRODUCT_TYPE_DEVICE:
                requestBody = CXPConstant.GET_DEVICE_DETAILS_REQUEST_BODY;
                break;
            case CXPConstant.PRODUCT_TYPE_ACCESSORY:
                requestBody = CXPConstant.GET_ACCESSORY_DETAILS_REQUEST_BODY;
                break;
            default:
                log.info("Request-body is not configured for productType: {}",productType);
        }
        Mono<JsonNode>  cxpResponse = null;
        if (requestBody != null){
            try{
                cxpResponse = webClient.post()
                        .uri(apiUrl)
                        .headers(h->h.addAll(cxpConfiguration.getHeader()))
                        .bodyValue(requestBody.replace(CXPConstant.SORID_PLACE_HOLDER,id))
                        .retrieve()
                        .bodyToMono(JsonNode.class)
                        .doOnSubscribe(subscription -> log.debug("Request initiated for URL in device flow: {}", apiUrl))
                        .doOnNext(response -> log.debug("Received response in device flow: {}", response))
                        .doOnError(error -> log.error("Error occurred while fetching device details: {}", error.getMessage(), error))
                        .timeout(Duration.ofSeconds(timeoutInSeconds));
            }catch (Exception e){
                log.error("Error wile fetching CXP Catalog domain for id: {}, productType: {}, env: {}, RequestBody: {}, Error: {}",
                        id,productType,env,requestBody,e.getStackTrace());
            }
        }
        return cxpResponse;
    }

    public Map<String, String> getCxpCatalogMappedJson(CXPCatalogDto cxpCatalogDto, String sorId,String productType) {

        Map<String, String> cxpMapJson = new HashMap<>();
        try {
            CXPCatalogDto.Data.DeviceCatalogItems deviceCatalogItem = cxpCatalogDto.getData().getDeviceCatalogItems().get(0);
            Map<String, String> dtoCatalogPropertyMap = CommonUtil.getPropertiesMapNew(deviceCatalogItem);
            Map<String, String> skuDataMap = null;
            Optional<CXPCatalogDto.Data.DeviceCatalogItems.Skus> skuData = deviceCatalogItem.getSkus().stream().filter(sku -> sorId.equalsIgnoreCase(sku.getSorId())).findFirst();
            if(skuData.isPresent()){
                skuDataMap = CommonUtil.getPropertiesMapNew(skuData.get());
                CXPCatalogDto.Data.DeviceCatalogItems.Skus.Price price = skuData.get().getPrice();
                //Map price for DPI response comparison
                CXPCatalogDto.Data.DeviceCatalogItems.Skus.Price.FullRetailPrice fullRetailPrice = price.getFullRetailPrice();
                skuDataMap.put("fullRetailPrice", null != fullRetailPrice ? String.valueOf(fullRetailPrice.getOriginalPrice()) : null);

                CXPCatalogDto.Data.DeviceCatalogItems.Skus.Price.OneYearPrice oneYearPrice = price.getOneYearPrice();
                skuDataMap.put("oneYearPrice", null != oneYearPrice ? String.valueOf(oneYearPrice.getOriginalPrice()) : null);

                CXPCatalogDto.Data.DeviceCatalogItems.Skus.Price.OneYearPrice twoYearPrice = price.getTwoYearPrice();
                skuDataMap.put("twoYearPrice", null != twoYearPrice ? String.valueOf(twoYearPrice.getOriginalPrice()) : null);

                CXPCatalogDto.Data.DeviceCatalogItems.Skus.Price.PrepayPrice prepayPrice = price.getPrepayPrice();
                skuDataMap.put("prepayPrice", null != prepayPrice ? String.valueOf(prepayPrice.getOriginalPrice()) : null);

                CXPCatalogDto.Data.DeviceCatalogItems.Skus.Price.EdgeFullRetailPrice edgeFullRetailPrice = price.getEdgeFullRetailPrice();
                skuDataMap.put("edgeFullRetailPrice", null != edgeFullRetailPrice ? String.valueOf(edgeFullRetailPrice.getOriginalPrice()) : null);

                CXPCatalogDto.Data.DeviceCatalogItems.Skus.SimSku simSku = skuData.get().getSimSku();
                skuDataMap.put("preferredSoftSim", null != simSku ? String.valueOf(simSku.getSorId()) : null);

            }
            dtoCatalogPropertyMap.putAll(skuDataMap);

            HashMap<String, String> catalogMap = runTimeMapInitializer.getCxpCatalogMap(productType);
            for (Map.Entry<String, String> e : catalogMap.entrySet()) {
                String value = dtoCatalogPropertyMap.get(e.getValue());
                cxpMapJson.put(e.getKey(), value);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return cxpMapJson;
    }


    public Map<String, String> getCxpCatalogMappedJsonAccessories(CXPCatalogDto cxpCatalogDto, String sorId, String productType) {

        Map<String, String> cxpMapJson = new HashMap<>();

            if (cxpCatalogDto != null && cxpCatalogDto.getData() != null && cxpCatalogDto.getData().getAccessoryCatalogItems() != null && cxpCatalogDto.getData().getAccessoryCatalogItems().size() > 0) {
                try {
                CXPCatalogDto.Data.DeviceCatalogItems accessoryCatalogItem = cxpCatalogDto.getData().getAccessoryCatalogItems().get(0);
                Map<String, String> dtoCatalogPropertyMap = CommonUtil.getPropertiesMapNew(accessoryCatalogItem);
                Map<String, String> skuDataMap = null;
                Optional<CXPCatalogDto.Data.DeviceCatalogItems.Skus> skuData = accessoryCatalogItem.getSkus().stream().filter(sku -> sorId.equalsIgnoreCase(sku.getSorId())).findFirst();
                if (skuData.isPresent()) {
                    skuDataMap = CommonUtil.getPropertiesMapNew(skuData.get());
                    CXPCatalogDto.Data.DeviceCatalogItems.Skus.Price price = skuData.get().getPrice();
                    //Map price for DPI response comparison
                    CXPCatalogDto.Data.DeviceCatalogItems.Skus.Price.FullRetailPrice fullRetailPrice = price.getFullRetailPrice();
                    skuDataMap.put("fullRetailPrice", null != fullRetailPrice ? String.valueOf(fullRetailPrice.getOriginalPrice()) : null);

                }
                dtoCatalogPropertyMap.putAll(skuDataMap);
                HashMap<String, String> catalogMap = runTimeMapInitializer.getCxpCatalogMap(productType);
                for (Map.Entry<String, String> e : catalogMap.entrySet()) {
                    String value = dtoCatalogPropertyMap.get(e.getValue());
                    cxpMapJson.put(e.getKey(), value);
                }
            } catch(Exception e){
                String message = "Failed to map CXP response" + e.getMessage();
                throw new CustomThrowableException(message, e);
            }
        }
        return cxpMapJson;
    }

}
