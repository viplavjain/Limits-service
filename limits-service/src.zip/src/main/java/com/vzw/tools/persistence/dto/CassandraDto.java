package com.vzw.tools.persistence.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.vzw.tools.authoring.entity.ProductOfferingPriceResponse;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CassandraDto {

    private List<Data> data;

    @lombok.Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Data {
        private String description;
        private ProductSpecification productSpecification;
        private List<ExternalId> externalId;
        private List<ProductOfferingGroup> productOfferingGroup;
        private List<ProductOfferingPrice> productOfferingPrice;
    }

    @lombok.Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ProductOfferingGroup {
        private String id;
        private ProductSpecCharacteristic productUniversalAccessories;
    }

    @lombok.Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class RootCategory {
        private String id;
        private String name;
        private List<SubCategory> subCategory;
        @JsonProperty("@type")
        private String type;
        @JsonProperty("@baseType")
        private String baseType;
        private boolean isRoot;
        private boolean isMetaRobotsFollow;
    }

    @lombok.Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ProductOfferingCharacteristic {
        private String name;
        private String valueType;
        private List<ProductOfferingCharacteristicValue> productOfferingCharacteristicValue;
    }

    @lombok.Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ProductOfferingCharacteristicValue {
        private String id;
        private List<Field> field;
        private String lastModifiedTimestamp;
        private String baseType;
        private String type;

        @JsonIgnoreProperties(ignoreUnknown = true)
        @lombok.Data
        public static class Field {
            private String name;
            private List<Entry> entry;
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        @lombok.Data
        public static class Entry {
            private Parameter parameter;
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        @lombok.Data
        public static class Parameter {
            private String key;
            private String valueType;
            private List<Value> value;
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        @lombok.Data
        public static class Value {
            private String id;
            private List<Field> field;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @lombok.Data
    public static class SubCategory {
        private String id;
        private String name;
        @JsonProperty("@type")
        private String type;
        @JsonProperty("@baseType")
        private String baseType;
        private boolean isRoot;
        private boolean isMetaRobotsFollow;
        private List<SubCategory> subCategory;
    }

    @lombok.Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ProductSpecification {
        private String id;
        private String expiredForSales;
        private List<ExternalId> externalId;
        private String isBundle;
        private List<LocalizedName> localizedName;
        private ValidFor validFor;
        private List<ProductSpecCharacteristic> productSpecCharacteristic;
        private BundledProductSpecification bundledProductSpecification;
    }

    @lombok.Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class BundledProductSpecification {
        private List<ProductSpecCharacteristic> productSpecCharacteristic;
    }

    @lombok.Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ExternalId {
        private String id;
        private String owner;
        private String type;
        private String uid;
    }

    @lombok.Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class LocalizedName {
        private String locale;
        private String value;
    }

    @lombok.Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ValidFor {
        private String startDateTime;
    }

    @lombok.Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ProductSpecCharacteristic {
        private String name;
        private String valueType;
        private List<ProductSpecCharacteristicValue> productSpecCharacteristicValue;
        private List<ProductSpecCharacteristicValue> characteristicValue;
    }

    @lombok.Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ProductSpecCharacteristicValue {
        private String id;
        private List<Field> field;
        private String lastModifiedTmStamp;
        private String expiredForSales;
        @JsonProperty("@baseType")
        private String baseType;
        @JsonProperty("@type")
        private String type;
        @JsonProperty("default")
        private String defaultValue;
        private String value;
        private String valueType;
    }

    @lombok.Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Field {
        private String name;
        private List<Entry> entry;
    }

    @lombok.Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Entry {
        private List<Parameter> parameter;
    }

    @lombok.Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Parameter {
        private String key;
        private String valueType;
        private List<Object> value;
    }

    @lombok.Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ProductOfferingPrice {
        private String id;
        private String name;
        private String role;
        private List<PriceRecord> priceRecord;
    }

    @lombok.Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class PriceRecord {
        private String priceRecordId;
        private int priority;
        private List<ProductOfferingPriceResponse.Price> price;
        private List<com.vzw.tools.persistence.dto.Parameter> parameter;
        private List<Object> externalIds;
        private boolean hasDefaultInstallment;
    }

}