package com.vzw.tools.common.entity;

import lombok.Data;

import java.util.List;

@Data
public class EntityResponse {
    private DataFlow flow;
    private CompareSummary compareSummary;
    private EntityDetails entityDetails;
    private List<ErrorDetails> errorDetails;
}
