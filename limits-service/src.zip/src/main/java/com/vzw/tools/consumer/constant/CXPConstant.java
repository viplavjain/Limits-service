package com.vzw.tools.consumer.constant;

public class CXPConstant {

    public static final String API_KEY = "x-apikey";
    public static final String GET_ACCESSORY_DETAILS_REQUEST_BODY = "{\n" +
            "\"genericInputAttributes\":{\"inventoryStatusRequired\":true},\n" +
            "\"accessoryCatalogRequest\": {\n" +
            "                \"sorIds\": [\n" +
            "                        \"$$sorId$$\"\n" +
            "                ],\n" +
            "        \"includerecommendedAccessoryDetails\" : false,\n" +
            "                \"channelFlow\": \"ALL\"\n" +
            "        }\n" +
            "}";

    public static final String GET_DEVICE_DETAILS_REQUEST_BODY = "{\n" +
            "\"genericInputAttributes\":{\"inventoryStatusRequired\":true},\n" +
            "\"deviceCatalogRequest\": {\n" +
            "                \"sorIds\": [\n" +
            "                        \"$$sorId$$\"\n" +
            "                ],\n" +
            "        \"includerecommendedDeviceDetails\" : false,\n" +
            "                \"channelFlow\": \"ALL\"\n" +
            "        }\n" +
            "}";
    public static final String SORID_PLACE_HOLDER="$$sorId$$";
    public static final String PRODUCT_TYPE_DEVICE="Device";
    public static final String PRODUCT_TYPE_ACCESSORY="Accessory";
}