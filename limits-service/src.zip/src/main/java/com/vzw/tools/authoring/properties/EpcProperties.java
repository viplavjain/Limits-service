package com.vzw.tools.authoring.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "spring.epc")
public class EpcProperties {

    private AmdocsSearchApi amdocsSearchApiHost;
    private AmdocsProductsApi amdocsProductApiHost;
    private Token token;
    private ProductOfferingPrice popurl;
    private AmdocsHost amdocsHost;

    @Data
    public static class AmdocsSearchApi {
        private String qa1;
        private String qa2;
        private String qa3;
    }

    @Data
    public static class AmdocsProductsApi {
        private String qa1;
        private String qa2;
        private String qa3;
    }

    @Data
    public static class Token {
        private String qa1;
        private String qa2;
        private String qa3;
    }

    @Data
    public static class ProductOfferingPrice {
        private String qa1;
        private String qa2;
        private String qa3;
    }


    @Data
    public static class AmdocsHost {
        private String baseUrl;
        private String promotionsUri;
        private String priceUri;

    }
}