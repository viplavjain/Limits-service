package com.vzw.tools.common.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.tools.common.constant.CommonConstants;
import com.vzw.tools.common.exception.ErrorBuilder;
import com.vzw.tools.common.exception.CustomThrowableException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import reactor.core.publisher.Mono;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Function;

@Slf4j
public class CommonUtil {

    private static String mapKey = null;
    private static String externalId_Owner = null;
    private static String externalId_Type = null;
    private static String externalId_Id = null;
    public static String mapValue = null;
    private static boolean vzPriceType = false;
    private static boolean isDeviceSku = false;
    private static final Map<String, String> epcFinalMap = new HashMap<>();
    private static final Map<String, String> dmdFinalMap = new HashMap<>();
    private static final StringBuilder universalPropCd = new StringBuilder();
    private static ErrorBuilder errorBuilder;


    private static final Function<String, String> convertYesToY = input -> "Yes".equalsIgnoreCase(input) ? "Y" :
            "No".equalsIgnoreCase(input) ? "N" : "o".equalsIgnoreCase(input) ? "Y" :input;

    public CommonUtil() {
    }

    public static HashMap<String, String> getPropertiesMap(Object o) {
        HashMap<String, String> propertiesASMap = new HashMap<>();
        try {
            Class<?> clazz = o.getClass();
            Field[] fields = clazz.getDeclaredFields();
            for (Field field : fields) {
                field.setAccessible(true);
                try {
                    Object valueType = field.get(o);
                    String value = null;
                    if (valueType instanceof List<?> list && !list.isEmpty()) {
                        value = String.join(",", (List<String>) list);
                    } else if (valueType instanceof BigDecimal) {
                        value = valueType.toString();
                    } else if (valueType instanceof String v) {
                        value = v;
                    }
                    if (value != null)
                        propertiesASMap.put(field.getName(), value);
                } catch (IllegalAccessException e) {
                    log.error("Error while processing the json {}", ExceptionUtils.getStackTrace(e));
                }
            }
            return propertiesASMap;
        } catch (Exception e) {
            log.error("Error while processing the json {}", ExceptionUtils.getStackTrace(e));
            return propertiesASMap;
        }
    }

    public static Map<String, String> getFormattedMap(Map<String, String> authorizationBaseMap) {
        Map<String, String> authorizationMap = new HashMap<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(CommonConstants.DATE_FORMAT).withZone(ZoneId.of(CommonConstants.UTC));
        authorizationBaseMap.forEach((key, value) -> {
            if (value != null && value.equalsIgnoreCase(CommonConstants.TRUE)) {
                authorizationMap.put(key, CommonConstants.Y);
            } else if (value != null && value.equalsIgnoreCase(CommonConstants.FALSE)) {
                authorizationMap.put(key, CommonConstants.N);
            } else if (value != null && formatDateOrKeepOriginal(value, formatter) != null) {
                authorizationMap.put(key, formatDateOrKeepOriginal(value, formatter));
            } else {
                authorizationMap.put(key, value);
            }
        });
        return authorizationMap;
    }

    private static String formatDateOrKeepOriginal(String str, DateTimeFormatter formatter) {
        try {
            Instant instant = Instant.parse(str);
            return formatter.format(instant);
        } catch (Exception e) {
            return null;
        }
    }

    public static boolean isMatchedObjects(Object... args) {
        if (args == null || args.length == 0) {
            return true;
        }
        List<Object> valuesList = Arrays.stream(args).map(x -> {
            Object object = new Object();
            if (x != null && (((String) x).trim().equalsIgnoreCase(CommonConstants.TRUE) || ((String) x).trim().equalsIgnoreCase("1"))) {
                object = CommonConstants.Y;
            } else if (x == null || ((String) x).trim().equalsIgnoreCase(CommonConstants.FALSE) || ((String) x).trim().isEmpty() || ((String) x).trim().equalsIgnoreCase("N") || ((String) x).trim().equalsIgnoreCase("0")) {
                object = null;
            } else {
                object = x;
            }
            return object;
        }).toList();
        return valuesList.stream().distinct().count() == 1;
    }

    public static boolean isValueMatched(Object o1, Object o2) {
        if (o1 == null && o2 == null) {
            return true;
        } else if (o1 == null) {
            String s = (String) o2;
            return s.trim().isEmpty();
        } else if (o2 == null) {
            String s = (String) o1;
            return s.trim().isEmpty();
        } else {
            if (o1 instanceof String s1 && o2 instanceof String s2) {
                if (s1.trim().equalsIgnoreCase(s2.trim())) {
                    return true;
                } else if (s1.trim().isEmpty() && s2.trim().equalsIgnoreCase(CommonConstants.N)) {
                    return true;
                } else return s2.trim().isEmpty() && s1.trim().equalsIgnoreCase(CommonConstants.N);
            } else {
                return false;
            }
        }
    }

    public static boolean isMapMatched(Map<String, String> source, Map<String, String> authorization, Class<?>... classes) {
        if (classes.length == 0) {
            return isMapMatched(source, authorization);
        }
        List<String> propsList = new ArrayList<>();
        for (Class<?> clazz : classes) {
            for (Field f : clazz.getDeclaredFields()) {
                propsList.add(f.getName().toLowerCase());
            }
        }
        Map<String, String> filterMap = new HashMap<>();
        source.keySet().forEach(x -> {
            if (propsList.contains(x.toLowerCase())) {
                filterMap.put(x, source.get(x));
            }
        });
        return isMapMatched(filterMap, authorization);
    }
    private static boolean isMapMatched(Map<String, String> map1, Map<String, String> map2) {
        return null != map1 && map1.entrySet().stream().allMatch(e -> null != map2 && map2.containsKey(e.getKey()) && CommonUtil.isValueMatched(map2.get(e.getKey()), e.getValue()));
    }

    public static Map<String, String> getPropertiesMapNew(Object o) {
        HashMap<String, String> propertiesASMap = new HashMap<>();
        try {
            Class<?> clazz = o.getClass();
            Field[] fields = clazz.getDeclaredFields();
            for (Field field : fields) {
                field.setAccessible(true);
                try {
                    Object valueType = field.get(o);
                    String value = null;
                    if (valueType instanceof List<?> list && !list.isEmpty() && list.stream().allMatch(e -> e instanceof  String)) {
                        value = String.join(",", (List<String>) list);
                    } else if (valueType instanceof BigDecimal) {
                        value = valueType.toString();
                    } else if (valueType instanceof String v) {
                        value = v;
                    }
                    else if (valueType instanceof Boolean v) {
                        value = valueType.toString();
                    }
                    if (value != null)
                        propertiesASMap.put(field.getName(), value);
                } catch (IllegalAccessException e) {
                    log.error("Error while processing the json {}", ExceptionUtils.getStackTrace(e));
                }
            }
            return propertiesASMap;
        } catch (Exception e) {
            log.error("Error while processing the json {}", ExceptionUtils.getStackTrace(e));
            return propertiesASMap;
        }
    }

    public static String removeLeadingAndTrailingBrackets(String str) {
        if (str != null && str.startsWith("[") && str.endsWith("]")) {
            return str.substring(1, str.length() - 1);
        }
        return str;
    }
    public static String removeTrailingComma(String str) {
        if (str != null &&  str.endsWith(",")) {
            return str.substring(0, str.length() - 1);
        }
        return str;
    }

    public static Map<String, String> convertEPCJsonMapToMap(Map<?, ?> epcJsonMap, Map<String, String> epcTempMap, String parentKey) {
        if (epcTempMap == null) {
            throw new IllegalArgumentException("The EPC map cannot be null");
        }
        for (var entry : epcJsonMap.entrySet()) {
            String currentKey = parentKey.isEmpty() ? String.valueOf(entry.getKey()) : parentKey + "." + entry.getKey();
            var value = entry.getValue();

            if (value instanceof Map<?, ?> nestedMap) {
                convertEPCJsonMapToMap(nestedMap, epcTempMap, currentKey);
            } else if (value instanceof Iterable<?> iterable) {
                int index = 0;
                for (var item : iterable) {
                    if (item instanceof Map<?, ?> itemMap) {
                        convertEPCJsonMapToMap(itemMap, epcTempMap, currentKey + index);
                    } else {
                        epcTempMap.put(currentKey + index, String.valueOf(item));
                    }
                    index++;
                }
            } else {
                if (currentKey.startsWith(CommonConstants.PRODUCT_OFFER + CommonConstants.STRING_DOT)) {
                    getProductOfferValue(currentKey, value);
                } else if (currentKey.startsWith(CommonConstants.PRODUCT_SPECIFICATION_SKU + CommonConstants.STRING_DOT) && currentKey.contains(CommonConstants.PRODUCT_SPEC_CHARACTERISTIC)) {
                    if (currentKey.endsWith(CommonConstants.NAME)) {
                        mapKey = String.valueOf(value);
                        epcFinalMap.put(mapKey, mapValue);
                    } else if (currentKey.endsWith(CommonConstants.PRODUCT_SPEC_CHAR_LOCAL_VALUE)) {
                        mapValue = convertYesToY.apply(String.valueOf(value));
                        epcFinalMap.put(mapKey, mapValue);
                        mapKey = null;
                        mapValue = null;
                    }
                } else if (currentKey.startsWith(CommonConstants.PRODUCT_OFFER_GROUP_POLICY) && currentKey.contains(CommonConstants.CHARACTERISTICS)) {
                    if (currentKey.endsWith(CommonConstants.NAME)) {
                        mapKey = String.valueOf(value);
                        epcFinalMap.put(mapKey, mapValue);
                    } else if (currentKey.contains(CommonConstants.CHARACTERISTIC_LOCAL_VALUE)) {
                        mapValue = convertYesToY.apply(String.valueOf(value));
                        epcFinalMap.put(mapKey, mapValue);
                        mapKey = null;
                        mapValue = null;
                    }
                } else if (currentKey.startsWith(CommonConstants.PRODUCT_OFFER_GROUP_NAME)) {
                    String prodDisplayName = String.valueOf(value);
                    if (null != prodDisplayName && !prodDisplayName.trim().isEmpty()) {
                        prodDisplayName = prodDisplayName.replace("_", " ");
                    }
                    epcFinalMap.put(CommonConstants.PRODUCT_DISPLAY_NAME, prodDisplayName);
                } else if (currentKey.startsWith(CommonConstants.PRODUCT_OFFER_PRICE + CommonConstants.STRING_DOT)) {
                    if (currentKey.endsWith(CommonConstants.DUTY_FREE_AMOUNT + CommonConstants.STRING_DOT + CommonConstants.VALUE)) {
                        mapValue = convertYesToY.apply(String.valueOf(value));
                    } else if (currentKey.contains(CommonConstants.PARAMETER) && currentKey.endsWith(CommonConstants.NAME) && String.valueOf(value).equalsIgnoreCase(CommonConstants.VZ_PRICE_TYPE)) {
                        vzPriceType = true;
                    } else if (vzPriceType && currentKey.endsWith(CommonConstants.VALUE + CommonConstants.STRING_DOT + CommonConstants.NAME)) {
                        mapKey = String.valueOf(value);
                        epcFinalMap.put(mapKey, mapValue);
                        mapKey = null;
                        mapValue = null;
                        vzPriceType = false;
                    }
                }
            }
        }
        return epcFinalMap;
    }

    private static void getProductOfferValue(String currentKey, Object value) {
        if (currentKey.contains(CommonConstants.DOCUMENT_NAME) && currentKey.endsWith(CommonConstants.VALUE))
            epcFinalMap.put(CommonConstants.SKU_DISPLAY_NAME, String.valueOf(value));
        else if (currentKey.contains(CommonConstants.DOCUMENT + CommonConstants.STRING_DOT + CommonConstants.DESCRIPTION)) {
            epcFinalMap.put(CommonConstants.DESCRIPTION, String.valueOf(value));
        } else if (currentKey.contains(CommonConstants.EXTERNAL_ID)) {
            if (currentKey.endsWith(CommonConstants.ID))
                externalId_Id = String.valueOf(value);
            else if (currentKey.endsWith(CommonConstants.OWNER))
                externalId_Owner = String.valueOf(value);
            else if (currentKey.endsWith(CommonConstants.TYPE))
                externalId_Type = String.valueOf(value);
            if (null != externalId_Id && null != externalId_Owner && null != externalId_Type) {
                if (CommonConstants.SORID.equalsIgnoreCase(externalId_Owner + externalId_Type)) {
                    epcFinalMap.put(CommonConstants.SORID, externalId_Id);
                    epcFinalMap.put(CommonConstants.EXTERNAL_ID, externalId_Id);
                    externalId_Owner = null;
                    externalId_Type = null;
                    externalId_Id = null;
                }
            }
        }
    }

    public static Mono<Map<String, String>> convertDMDJsonMapToMap(Map<?, ?> map, Map<String, String> dataMap, String parentKey, String sorId) {
        for (var entry : map.entrySet()) {
            String currentKey = parentKey.isEmpty() ? String.valueOf(entry.getKey()) : parentKey + "." + entry.getKey();
            var value = entry.getValue();
            if (value instanceof Map<?, ?> nestedMap) {
                convertDMDJsonMapToMap(nestedMap, dataMap, currentKey, sorId);
            } else if (value instanceof Iterable<?> iterable) {
                int index = 0;
                for (var item : iterable) {
                    if (item instanceof Map<?, ?> itemMap) {
                        convertDMDJsonMapToMap(itemMap, dataMap, currentKey + index, sorId);
                    } else {
                        dataMap.put(currentKey + index, String.valueOf(item));
                        if (currentKey.contains(CommonConstants.UNIVERSAL_PROP_CD_LIST + CommonConstants.STRING_DOT + CommonConstants.UNIVERSAL_PROP_CD)) {
                            if (!universalPropCd.isEmpty())
                                universalPropCd.append(",");
                            universalPropCd.append(item);
                        }
                    }
                    index++;
                }
            } else {
                if (currentKey.endsWith(CommonConstants.DEVICE_SKU)) {
                    if (String.valueOf(value).equalsIgnoreCase(sorId))
                        isDeviceSku = true;
                    else if (!String.valueOf(value).equalsIgnoreCase(sorId))
                        isDeviceSku = false;
                }

                if (currentKey.startsWith(CommonConstants.DEVICE_SKU_LIST + CommonConstants.STRING_DOT + CommonConstants.DEVICE_SKU_INFO) && isDeviceSku) {
                    dmdFinalMap.put(String.valueOf(entry.getKey()), convertYesToY.apply(String.valueOf(value)));
                } else if (!currentKey.contains(CommonConstants.DEVICE_SKU_LIST + CommonConstants.STRING_DOT + CommonConstants.DEVICE_SKU_INFO) && !currentKey.contains(CommonConstants.MARKETING_COMPATIBLES_IM_SKU_LIST)) {
                    dmdFinalMap.put(String.valueOf(entry.getKey()), convertYesToY.apply(String.valueOf(value)));
                }
            }
        }
        if (!universalPropCd.isEmpty())
        {
            dmdFinalMap.put(CommonConstants.UNIVERSAL_PROP_CD, String.valueOf(universalPropCd));
            universalPropCd.setLength(0);
        }
        return Mono.just(dmdFinalMap);
    }
	public static Mono<Object> getPromotionDetails(Mono<JsonNode> promotionCombinedResponse){
        return promotionCombinedResponse.flatMap(
                res -> {
                    Object promotionResponse = null;
                    try {
                        promotionResponse = new ObjectMapper().treeToValue(res,Object.class);
                        return Mono.just(promotionResponse);
                    } catch (JsonProcessingException e) {
                        return Mono.error(errorBuilder.buildApplicationException(e));
                    }

                }
        );
    }

public static <T> Mono<T> getMonoObjFromStr(String str, ObjectMapper mapper, Class<T> clazz) {
        try {
            return Mono.just(getObjFromStr(str, mapper, clazz));
        } catch (CustomThrowableException e) {
            return Mono.error(e);
        }
    }

    public static <T> T getObjFromStr(String str, ObjectMapper mapper, Class<T> clazz) throws CustomThrowableException{
        try {
            return mapper.readValue(str, clazz);
        } catch (JsonProcessingException e) {
            throw new CustomThrowableException("Unexpected error while parsing the json string", e);

        }
    }

    public static String convertObjToString(Object obj, ObjectMapper mapper) throws JsonProcessingException {
        String str = mapper.writeValueAsString(obj);
        return str;
    }

    public static Map<String, String> populateHeadersWithToken(String bearerToken) {
        Map<String,String> headers = new HashMap<>();
        headers.put("Authorization", bearerToken);
        headers.put("Content-Type", "application/json");
        return headers;
    }


}