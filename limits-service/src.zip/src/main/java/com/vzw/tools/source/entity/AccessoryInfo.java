package com.vzw.tools.source.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AccessoryInfo {

    private String accessorySku;
    private String imManufacturer;
    private String imAccessoryMktgName;
    private String imAccessoryDesc;
    private String accessoryType;
    private String accessoryTypeId;
    private String imImageUrl;
    private String prodCode1;
    private String prodCode2;
    private String prodCode3;
    private String prodCode4;
    private String prodCode5;
    private String btaEligiblity;
    private String upcCode;
    private String universalAcc;
    private String upcCodeFull;
    private String ispuEligible;
    private String prop65;
    private String edgeDpcGroup;
    private String edgeDpc;
    @JsonProperty("universalPropCdList")
    private UniversalPropCdListAcc universalPropCdList;
}

