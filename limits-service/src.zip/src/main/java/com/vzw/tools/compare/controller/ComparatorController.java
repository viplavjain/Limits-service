package com.vzw.tools.compare.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.vzw.tools.common.entity.EntityResponse;
import com.vzw.tools.common.exception.*;
import com.vzw.tools.compare.service.ComparatorService;
import com.vzw.tools.compare.service.RedisComparatorService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.util.ArrayList;

import static com.vzw.tools.common.constant.CommonConstants.PROD_TYPE_ACCESSORY;
import static com.vzw.tools.common.constant.CommonConstants.PROD_TYPE_DEVICE;

@RestController
@Slf4j
public class ComparatorController {

    private final ComparatorService comparatorService;

    private final RedisComparatorService redisComparatorService;

    private final ErrorBuilder errorBuilder;

    @Autowired
    public ComparatorController(ComparatorService comparatorService, RedisComparatorService redisComparatorService, ErrorBuilder errorBuilder) {
        this.comparatorService = comparatorService;
        this.redisComparatorService = redisComparatorService;
        this.errorBuilder = errorBuilder;
    }


    @GetMapping("/compareJson/{productType}/{env}")
    public Mono<ResponseEntity<?>> compare(@PathVariable String productType,
                                                          @PathVariable String env,
                                                          @RequestParam(value = "id", required = true) String id) throws XmlConversionException, JsonProcessingException, ConverterException {

        log.info("Comparing Source and target for productType: {}, env: {}, sorId: {}", productType, env, id);
        if(PROD_TYPE_ACCESSORY.equalsIgnoreCase(productType)){
            return comparatorService.compareAcccessoriesData(id, productType, env)
                    .flatMap(entityResponse ->{
                        if (entityResponse == null) {
                            log.warn("ComparatorAccessoriesService returned null, returning empty response");
                            return Mono.just(ResponseEntity.notFound().build());
                        }
                        else  {
                            return Mono.just(ResponseEntity.ok(entityResponse));
                        }
                    }).onErrorMap(errorBuilder::buildApplicationException);
        }
        else {
            return comparatorService.compare(id, productType, env)
                    .flatMap(entityResponse ->{
                        if (entityResponse == null) {
                            log.warn("Service returned null, returning empty response");
                            return Mono.just(ResponseEntity.notFound().build());
                        }
                        else  {
                            return Mono.just(ResponseEntity.ok(entityResponse));
                        }
                    }).onErrorMap(errorBuilder::buildApplicationException);

        }


    }

    @GetMapping("/compareRedis/{productType}/{env}")
    public Mono<ResponseEntity<?>> compareRedis(@PathVariable String productType, @PathVariable String env,
                                                @RequestParam(value = "id", required = true) String id){

        log.info("Comparing Source and target for productType: {}, sorId: {}", productType, id);
        Mono<EntityResponse> redisData = redisComparatorService.compare(id, productType, env);
        return redisData
                .flatMap(entityResponse ->{
                    if (entityResponse == null) {
                        log.warn("ComparatorService returned null, returning empty response");
                        return Mono.just(ResponseEntity.notFound().build());
                    }
                    else  {
                        return Mono.just(ResponseEntity.ok(entityResponse));
                    }
                }).onErrorMap(errorBuilder::buildApplicationException);

    }
}
