package com.vzw.tools.common.entity;

import lombok.Data;

import java.util.Map;

@Data
public class EntityRowDetails {

    private String field;
    private Boolean isMatch;
    private Map<String, String> details;
}
