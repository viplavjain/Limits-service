package com.vzw.tools.persistence.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "spring.cassandra")
public class CassandraProperties {

    private Host host;
    private Header header;
    private HeaderForPromotion headerForPromotion;

    @Data
    public static class Host {
        private String url;

    }

    @Data
    public static class Header {
        private String clientId;
        private String channelId;
    }

    @Data
    public static class HeaderForPromotion {
        private String clientId;
        private String xApiKey;
    }

}
