package com.vzw.tools.source.entity;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@JacksonXmlRootElement(localName = "pairedSkuInfo")
public class PairedSkuInfo {
    @JacksonXmlElementWrapper(useWrapping = false)
    private String pairedImeiSku;
}
