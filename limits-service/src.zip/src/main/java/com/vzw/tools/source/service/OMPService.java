package com.vzw.tools.source.service;

import com.vzw.tools.helpers.jdbc.OMPJdbcReactiveHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Map;

@Component
@Slf4j
public class OMPService {

    @Autowired
    public OMPJdbcReactiveHelper ompJdbcReactiveHelper;

    public Mono<Map<String, String>> getOMPPromotionDetails(String offerId, String productType, String env) {
        log.info("getDPIDeviceDetails() calls begins for sorId: {}", offerId);
        return ompJdbcReactiveHelper.retrieveOMPResponse(offerId);
    }
}
