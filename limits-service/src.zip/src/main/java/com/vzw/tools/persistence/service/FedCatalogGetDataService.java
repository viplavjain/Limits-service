package com.vzw.tools.persistence.service;

import com.vzw.tools.common.constant.CommonConstants;
import com.vzw.tools.common.exception.ErrorBuilder;
import com.vzw.tools.helpers.jdbc.FederatedCatalogueAccessoriesJdbcReactiveHelper;
import com.vzw.tools.helpers.jdbc.FederatedCatalogueDeviceJdbcReactiveHelper;
import com.vzw.tools.helpers.jdbc.FederatedCataloguePromotionJdbcReactiveHelper;
import com.vzw.tools.persistence.configuration.FederatedDBConfiguration;
import com.vzw.tools.source.configuration.RunTimeMapInitializer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedCaseInsensitiveMap;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.vzw.tools.common.constant.CommonConstants.*;

@Component
@Slf4j
public class FedCatalogGetDataService {

    private final FederatedDBConfiguration fedCatalogConfiguration;
    private final RunTimeMapInitializer runTimeMapInitializer;
    private final ErrorBuilder errorBuilder;

    @Autowired
    FederatedCatalogueDeviceJdbcReactiveHelper federatedCatalogueDeviceJdbcReactiveHelper;

    @Autowired
    FederatedCatalogueAccessoriesJdbcReactiveHelper federatedCatalogueAccessoriesJdbcReactiveHelper;

    @Autowired
    FederatedCataloguePromotionJdbcReactiveHelper federatedCataloguePromotionJdbcReactiveHelper;


    @Autowired
    public FedCatalogGetDataService(FederatedDBConfiguration fedCatalogConfiguration,RunTimeMapInitializer runTimeMapInitializer, ErrorBuilder errorBuilder) {
        this.fedCatalogConfiguration = fedCatalogConfiguration;
        this.runTimeMapInitializer = runTimeMapInitializer;
        this.errorBuilder = errorBuilder;
    }

    public Mono<Map<String,String>> fedCatalogDeviceDetails(String sorId, String productType, String env)  {
        log.info("FedCatalog device call details invoked");
        SimpleJdbcCall simpleJdbcCall = getSimpleJdbcCall(sorId,productType,env);
        SqlParameterSource inParams = new MapSqlParameterSource()
                .addValue(P_SOR_ID, sorId);

        Map<String,Object> result = simpleJdbcCall.execute(inParams);

        ArrayList<LinkedCaseInsensitiveMap<Object>> al=  (ArrayList<LinkedCaseInsensitiveMap<Object>>)result.get(CommonConstants.P_RESULT_SET);
        HashMap<String,String> fedCatalogMap = new HashMap<>();
        if(al != null && !al.isEmpty()){
            LinkedCaseInsensitiveMap<Object> caseInsensitiveMap = al.get(0);
            for(Map.Entry<String,Object> entry : caseInsensitiveMap.entrySet() ){
                fedCatalogMap.put(entry.getKey().toLowerCase(),entry.getValue()!=null ? entry.getValue().toString().toLowerCase():null);
            }
            return Mono.just(fedCatalogMap);
        }
        else {
            return Mono.just(fedCatalogMap);
        }
    }

    public SimpleJdbcCall getSimpleJdbcCall(String sorId, String productType, String env){
        return new SimpleJdbcCall(fedCatalogConfiguration.jdbcTemplateForEnv(env))
                .withSchemaName(EPCREP_SCHEMA)
                .withProcedureName(retreiveStoredProcedure(productType))
                .returningResultSet(DEVICE_INFO, new BeanPropertyRowMapper<>(HashMap.class));
    }

    public String retreiveStoredProcedure(String productType) {
        if (productType.equalsIgnoreCase(PROD_TYPE_DEVICE))
            return FEDCATALOG_SP_DEVICE;
        else if (productType.equalsIgnoreCase(PROD_TYPE_ACCESSORY))
            return FEDCATALOG_SP_ACCESSORY;
        else if (productType.equalsIgnoreCase(PROD_TYPE_PROMOTION)) {
            return FEDCATALOG_SP_PROMOTION;
        } else {
            return " ";
        }
    }

    public Mono<Map<String, String>> getFedCatalogMappedJson(String sorId, String productType, String env){
        return getFederatedDBResponse(sorId, productType)
                .flatMap(response -> Mono.just(getFederatedCatalogMappedJson(response,productType)))
                .onErrorMap(err -> errorBuilder.buildApplicationException(err));
    }

    public Mono<Map<String, String>> getFederatedDBResponse(String id, String productType) {
        if(productType.equalsIgnoreCase(PROD_TYPE_DEVICE))
            return federatedCatalogueDeviceJdbcReactiveHelper.retrieveFedCatalogueDeviceResponse(id, productType).onErrorMap(err -> errorBuilder.buildApplicationException(err));
        else if(productType.equalsIgnoreCase(PROD_TYPE_ACCESSORY))
            return federatedCatalogueAccessoriesJdbcReactiveHelper.retrieveFedCatalogueAccessoriesResponse(id, productType).onErrorMap(err -> errorBuilder.buildApplicationException(err));
        else if(productType.equalsIgnoreCase(PROD_TYPE_PROMOTION))
            return federatedCataloguePromotionJdbcReactiveHelper.retrieveFedCataloguePromotionResponse(id, productType).onErrorMap(err -> errorBuilder.buildApplicationException(err));
        return Mono.just(new HashMap<>());
    }

    private Map<String, String> getFederatedCatalogMappedJson(Map<String, String> federatedCatalogMapWithApiValues,String productType) {
        HashMap<String, String> federatedCatalogMap = new HashMap<>();
        try {
            HashMap<String, String> federatedCatalogMapofGenericKeys = runTimeMapInitializer.getFedCatalogMap(productType);
            if(null != federatedCatalogMapWithApiValues) {
                for (Map.Entry<String, String> e : federatedCatalogMapofGenericKeys.entrySet()) {
                    String value = federatedCatalogMapWithApiValues.get(e.getValue());
                    federatedCatalogMap.put(e.getKey(), value);
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return federatedCatalogMap;
    }

}