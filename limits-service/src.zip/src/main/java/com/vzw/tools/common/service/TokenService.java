package com.vzw.tools.common.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.tools.authoring.configuration.EpcConfiguration;
import com.vzw.tools.authoring.entity.Token;
import com.vzw.tools.authoring.entity.TokenModel;
import com.vzw.tools.common.exception.ConverterException;
import com.vzw.tools.common.util.JsonToObjectConverter;
import com.vzw.tools.helpers.http.HttpService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import static com.vzw.tools.common.constant.AmdocsConstants.TOKEN_SERVICE;

@Component
@Slf4j
public class TokenService {


    private final ObjectMapper objectMapper = new ObjectMapper();

    private final WebClient webClient;
    private final EpcConfiguration epcConfiguration;
    @Value("${spring.webclient.timeout:30}")
    public int timeoutInSeconds;


    @Autowired
    @Qualifier("tokenGenerator")
    private HttpService tokenGenerator;

    @Autowired
    public TokenService(WebClient webClient, EpcConfiguration epcConfiguration) {
        this.webClient = webClient;
        this.epcConfiguration = epcConfiguration;
    }

    public Mono<Token> getToken(String env) throws ConverterException {
        log.info("Going to retrieve token for {} environment",env);
        TokenModel tokenBody = JsonToObjectConverter.jsonToObject("token.json", TokenModel.class);
        Mono<Token> monoToken = webClient.post()
                .uri(epcConfiguration.getToken(env))
                .bodyValue(tokenBody)
                .header("Authorization", "Basic ZXBjX3VzZXJfbnBfdG9rZW46RWcqOCRVTWdLXVcuWkA0TA==")
                .retrieve()
                .bodyToMono(Token.class)
                .timeout(Duration.ofSeconds(timeoutInSeconds));
        return monoToken;

    }

    public Mono<Token> getTokenHttpService() throws ConverterException{
        log.info("Going to retrieve token for {} environment");
        TokenModel tokenBody = JsonToObjectConverter.jsonToObject("token.json", TokenModel.class);
        Map<String,String> headers = new HashMap<>();
        headers.put("Authorization","Basic ZXBjX3VzZXJfbnBfdG9rZW46RWcqOCRVTWdLXVcuWkA0TA==");
        ObjectMapper mapper = new ObjectMapper();
        String req;
        try {
            req = mapper.writeValueAsString(tokenBody);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        return tokenGenerator.postRequest(req, headers, TOKEN_SERVICE).flatMap(tokenRes -> {
            try {
                return Mono.just(mapper.readValue(tokenRes, Token.class));
            } catch (JsonProcessingException e) {
                throw new RuntimeException(e);
            }
        });


    }
}
