package com.vzw.tools.source.repository;

import com.vzw.tools.common.exception.DataBaseException;
import com.vzw.tools.source.dao.DeviceDPIDAO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import java.util.Map;

import static com.vzw.tools.common.constant.CommonConstants.*;

@Repository
@Slf4j
public class DPIRepository {

    private final JdbcTemplate dpiJdbcTemplate;

    public DPIRepository(JdbcTemplate dpiJdbcTemplate) {
        this.dpiJdbcTemplate = dpiJdbcTemplate;
    }

    public Map<String, Object> fetchDeviceDPI(String sorId) throws DataBaseException {
        Map<String, Object> result;
        try {
            log.info("fetchDeviceDPI() call begins for sorId: {}", sorId);
            SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(dpiJdbcTemplate)
                    .withCatalogName(DPI_PKG)
                    .withProcedureName(DPI_SP_DEVICE)
                    .returningResultSet(DEVICE_INFO, new BeanPropertyRowMapper<>(DeviceDPIDAO.class));
            SqlParameterSource inParams = new MapSqlParameterSource()
                    .addValue(DEV_SKU_LIST, sorId)
                    .addValue(DATE, null);
            result = simpleJdbcCall.execute(inParams);
        } catch (Exception e) {
            log.error("Error while fetching Device DPI details for sorID:{}. Detailed message: {}", sorId, e.getMessage());
            throw new DataBaseException("Error while fetching Device DPI details");
        }
        log.info("fetchDeviceDPI() call ends for sorId: {}, result:{}", sorId, result);
        return result;
    }
}
