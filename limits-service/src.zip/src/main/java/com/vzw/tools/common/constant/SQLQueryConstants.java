package com.vzw.tools.common.constant;

public class SQLQueryConstants {

    public static final String EPC_DEVICE_QUERY = "Select po.id as id,po.atg_product_id as atg_product_id , po.atg_sku_id as atg_sku_id ,po.sor_id as sor_id ,po.display_name as display_name ,psdevice.image_name as image_name , " +
            " podevice.preferred_term as preferred_term ,podevice.early_termination_text as early_termination_text , " +
            " psdevice.sor_product_family as sor_product_family,psdevice.prod_code_1 as prod_code_1,psdevice.prod_code_2 as PROD_CODE_2,psdevice.prod_code_3 as PROD_CODE_3,psdevice.prod_code_4 as PROD_CODE_4,psdevice.prod_code_5 as PROD_CODE_5,psprd.dacc_id as dacc_id from " +
            " VZW_EPC_PO po left outer join VZW_EPC_PS_DEVICE psdevice on po.id=psdevice.id left outer join VZW_EPC_PO_DEVICE podevice on po.id=podevice.ID " +
            " left outer join vzw_epc_device_psprd psprd on psprd.id=po.id  where po.SOR_ID =:sorid";

    public static final String DMD_DEVICE_QUERY = "Select XMLElement( \"deviceInfo\"\n" +
            "                       , XMLForest( l.prod_name as \"prodName\"\n" +
            "                                , l.device_family_name                        as \"familyName\"\n" +
            "                                , l.mfg_code                                  as \"mfgCode\"\n" +
            "\t\t\t\t\t\t\t\t,XMLCDATA(COALESCE(od.manufacture_name,l.real_manufacturer,m.mfg_name)) as \"mfgName\"\n" +
            "                                , Nvl(e.prod_type, ' ')                       as \"prodType\"\n" +
            "                                , Nvl(ie.equip_name, ' ')                     as \"imProdName\"\n" +
            "                                , Nvl(ie.main_image, ' ')                     as \"imImageUrl\"\n" +
            "                                , Nvl(ie.Device_Category, ' ')                as \"imDeviceCategory\"\n" +
            "                                , Nvl(d.device_mask, ' ')                     as \"deviceType\"\n" +
            "                                , Nvl(f.global_phone, ' ')                    as \"globalPhone\"\n" +
            "                                , Nvl(l.device_category, ' ')                 as \"deviceCategory\"\n" +
            "                                , Nvl(t.dcat, ' ')                            as \"deviceCapabilityInd\"\n" +
            "                                , Nvl(f.ba, ' ')                              as \"backupAssistCapable\"\n" +
            "                                , ( Select nvl(max(sc.sim_sku), ' ')\n" +
            "                                      from sim_4g_compatible_marketing sc\n" +
            "                                     Where sc.preferred_sim  = 'Y'\n" +
            "                                       And sc.prod_name      = l.prod_name\n" +
            "                                       And sc.mfg_code       = l.mfg_code\n" +
            "                                       And sc.effective_date = l.effective_date) as \"preferredSim\"\n" +
            "                                ,( Select nvl(max(sc.sim_sku), ' ')\n" +
            "                                      from sim_4g_compatible_marketing sc\n" +
            "                                     Where sc.preferred_soft_sim  = 'Y'\n" +
            "                                       And sc.prod_name      = l.prod_name\n" +
            "                                       And sc.mfg_code       = l.mfg_code\n" +
            "                                       And sc.effective_date = l.effective_date) as \"preferredSoftSim\",\n" +
            "                                       ( Select nvl(max(sc.sim_sku), ' ')\n" +
            "                                      from sim_4g_compatible_marketing sc\n" +
            "                                     Where sc.alternate_sim  = 'Y'\n" +
            "                                       And sc.prod_name      = l.prod_name\n" +
            "                                       And sc.mfg_code       = l.mfg_code\n" +
            "                                       And sc.effective_date = l.effective_date) as \"alternateSim\"\n" +
            "                                , Nvl(ph.sim_class_4g, ' ')     as \"simClass4G\"\n" +
            "                                , Nvl(f.nfc_capable, ' ')       as \"nfcCapable\"\n" +
            "                                , Nvl(f.nfc_compatible, ' ')    as \"nfcCompatible\"\n" +
            "                                , DECODE(f.mobile_messaging, '2WSMS/MO','Y', 'N') as \"smsCapable\"\n" +
            "                                , (Select Nvl(Max(s.dacc_code), '00000') From sku_dacc s\n" +
            "                                    Where s.prod_name  = l.prod_name\n" +
            "                                      And s.mfg_code   = l.mfg_code\n" +
            "                                      And s.effective_date = l.effective_date) as \"dacc\"\n" +
            "                                , Nvl(l.device_family_type, ' ')       as \"deviceFamilyType\"\n" +
            "                                , Nvl(l.buddy_upgrd_elig_ind, ' ')     as \"buddyUpgrdEligInd\"\n" +
            "                                , Nvl(l.restrict_to_family_ind, ' ')   as \"restrictToFamilyInd\"\n" +
            "                                , Nvl(f.hd_voice, ' ')                 as \"hdVoice\"\n" +
            "                                , Nvl(t.coverage_check_4g, ' ')        as \"coverageCheck4G\"\n" +
            "                                , Nvl(t.volte_4_business, ' ')         as \"v4b\"\n" +
            "                                , Nvl(t.number_share_capability, ' ')  as \"numberShareCapable\"\n" +
            "                                , Nvl(f.euicc_capable, ' ')  as \"euiccCapable\"\n" +
            "                                , Nvl(f.esim_only_ind, ' ')  as \"esimOnlyInd\"\n" +
            "                                , Nvl(f.vendor_key, ' ')  as \"vendorKey\"\n" +
            "                                , Nvl(f.dsds, ' ') as \"dsds\"\n" +
            "                                , Nvl((Select os_type From software s\n" +
            "                                    Where s.prod_name  = l.prod_name\n" +
            "                                      And s.mfg_code   = l.mfg_code\n" +
            "                                      And s.effective_date = l.effective_date), ' ') as \"operatingSystem\"\n" +
            "                                , Nvl((Select max(eligible_num_share_os) From DMD_UNIVERSAL_API_DATA api\n" +
            "                                    Where api.prod_name  = l.prod_name\n" +
            "                                      And api.mfg_code   = l.mfg_code\n" +
            "                                      And api.effective_date = l.effective_date), ' ') as \"eligibleNumShareOS\"\n" +
            "                                , ( Select decode(count(*), 0, 'N', 'Y')\n" +
            "                                      From im_eg_accessory ai, launch_package li, im_eg_acc_xref xi\n" +
            "                                     Where ai.mnfr_id = 0\n" +
            "                                       And ai.universal_type in (select distinct universal_type from im_eg_accessory)\n" +
            "                                       And ai.universal_type    <> 'None'\n" +
            "                                       And li.device_family_name = l.device_family_name\n" +
            "                                       And xi.equip_id           = li.equip_id\n" +
            "                                       And xi.acc_id             = ai.acc_id) as \"universalDevice\"\n" +
            "                                , Nvl(f.wifi_calling, ' ')        as \"wifiCalling\"\n" +
            "                                , Nvl(f.E911_ADDR_IND, ' ')        as \"e911AddrInd\"\n" +
            "                                , Case When ie.equip_id Is Null Then\n" +
            "                                        ' '\n" +
            "                                  Else Nvl((Select distinct 'N' From im_eg_feat_attr_xref x\n" +
            "                                        Where x.equip_id = ie.equip_id and x.feature_id  = '1744'), 'Y') End as \"cdmaCapableInd\"\n" +
            "                                , Case When d.device_mask like '4G%' Then\n" +
            "                                       'Y'\n" +
            "                                       When ie.equip_id Is Null Then\n" +
            "                                       ' '\n" +
            "                                  Else Nvl((Select distinct 'Y' From im_eg_feat_attr_xref x\n" +
            "                                        Where x.equip_id = ie.equip_id and x.feature_id  In ('1773', '915')), 'N') end as \"gsmCapableInd\"\n" +
            "\t\t\t\t\t\t\t\t\t\t--BQVT-957\n" +
            "                                , Nvl(l.device_carrier, ' ')        as \"deviceCarrier\"\n" +
            "                                , Nvl((select to_char(POSTPAID_RESTRICT_START_DATE,'MM/DD/YYYY') from restrict_devices where device_sku = l.dymax_bam),' ') as \"postpaidRestrictStartDate\"\n" +
            "                                , Nvl((select to_char(PREPAY_RESTRICT_START_DATE,'MM/DD/YYYY') from restrict_devices where device_sku = l.dymax_bam),' ') as \"prepayRestrictStartDate\"\n" +
            "                                )\n" +
            "                                , XMLElement(\"universalPropCdList\"\n" +
            "                                                , (Select XMLAgg(XMLElement(\"universalPropCd\", iv.vzw_model))\n" +
            "                                                     From ( Select distinct li.device_family_name, ai.vzw_model\n" +
            "                                                              From im_eg_accessory ai, launch_package li, im_eg_acc_xref xi\n" +
            "                                                             Where ai.mnfr_id = 0\n" +
            "                                                               And ai.universal_type    In (select distinct universal_type from im_eg_accessory)\n" +
            "                                                               And ai.universal_type    <> 'None'\n" +
            "                                                               And xi.equip_id           = li.equip_id\n" +
            "                                                               And xi.acc_id             = ai.acc_id) iv\n" +
            "                                                     Where iv.device_family_name = l.device_family_name))\n" +
            "                                , XMLElement(\"deviceSkuList\"\n" +
            "                                                , (Select XMLAgg(\n" +
            "                                                            XMLElement(\"deviceSkuInfo\"\n" +
            "                                                                , XMLForest( s.sku_code                    as \"deviceSku\"\n" +
            "                                                                           , Nvl(sim_model_id, ' ')        as \"virtualSimSku\"\n" +
            "                                                                           , DMD_PKG_GEN_OMNI_FEED.f_get_sku_type(s.sku_code)    as \"skuType\"\n" +
            "                                                                           , i.itm_class1                  as \"prodCode1\"\n" +
            "                                                                           , i.itm_class2                  as \"prodCode2\"\n" +
            "                                                                           , i.itm_class3                  as \"prodCode3\"\n" +
            "                                                                           , i.itm_class4                  as \"prodCode4\"\n" +
            "                                                                           , i.itm_class5                  as \"prodCode5\"\n" +
            "                                                                           , Nvl(i.itm_bta_eligible, ' ')  as \"btaEligiblity\"\n" +
            "                                                                           , Nvl(i.itm_upc, ' ')           as \"upcCode\"\n" +
            "                                                                           , Nvl(i.itm_prepay_sku, 'N')    as \"prepaySkuInd\"\n" +
            "                                                                           , Nvl(i.itm_wave_eligible, ' ') as \"edgeEligibleInd\"\n" +
            "                                                                           , Nvl(i.itm_dpc_group, ' ')     as \"edgeDpcGroup\"\n" +
            "                                                                           , Nvl(i.itm_dpc_item, ' ')      as \"edgeDpcItem\"\n" +
            "                                                                           , i.itm_last_cost               as \"itemCost\"\n" +
            "                                                                           , (Select Nvl(to_char(max(i.equip_id)), ' ')\n" +
            "                                                                                From im_eg_equipment i\n" +
            "                                                                               Where i.inventory_id  = s.sku_code\n" +
            "                                                                                 And i.delete_flag   <> 'Y')     as \"imEquipID\"\n" +
            "                                                                           , Nvl(i.itm_upc_full, ' ')            as \"upcCodeFull\"\n" +
            "                                                                           , i.itm_device_cap                    as \"edgeDeviceCap\"\n" +
            "                                                                           , Nvl(i.instant_credit_eligible, ' ') as \"instantCredit\"\n" +
            "                                                                           , Nvl(Decode(i.ispu_eligible, 'X', 'Y', i.ispu_eligible), ' ') as \"ispuEligible\"\n" +
            "                                                                           , (Select Nvl(REPLACE(REPLACE(max(i.prop65_warning),CHR(10),' '),CHR(13),' '),' ')\n" +
            "                                                                                  From im_eg_equipment i\n" +
            "                                                                                  Where i.inventory_id  = s.sku_code\n" +
            "                                                                                  And i.delete_flag   <> 'Y')  as \"prop65\"\n" +
            "                                                                           )\n" +
            "                                                                           ,  XMLElement(\"pairedSkuInfo\"\n" +
            "                                                                               , (Select XMLAgg( XMLElement(\"pairedImeiSku\", imei2_sku))\n" +
            "                                                                                 from sku_pair where imei1_sku=s.sku_code\n" +
            "                                                                             ))))\n" +
            "                                                     From sku_dacc s, item i, model_product mp\n" +
            "                                                    Where s.sku_code       = i.itm_part\n" +
            "                                                      And mp.model_id(+)   = s.sku_code\n" +
            "                                                      And s.prod_name      = l.prod_name\n" +
            "                                                      And s.mfg_code       = l.mfg_code\n" +
            "                                                      And s.effective_date = l.effective_date\n" +
            "                                                      ))\n" +
            "                                , XMLElement(\"imFeatureNameList\"\n" +
            "                                                 , (Select XMLAgg( XMLElement(\"imFeatureName\", feature_name))\n" +
            "                                                      From ( Select distinct b.feature_name, a.inventory_id, a.equip_id\n" +
            "                                                               From im_eg_equipment a, im_eg_feature_attr b, im_eg_feat_attr_xref c\n" +
            "                                                              Where a.retired       = 'N'\n" +
            "                                                                And a.active_flag   = 'Y'\n" +
            "                                                                And a.delete_flag   = 'N'\n" +
            "                                                                And a.equip_id      = c.equip_id\n" +
            "                                                                And b.compare_flag  = 'Y'\n" +
            "                                                                And b.feature_id    = c.feature_id) iv\n" +
            "                                                     Where iv.equip_id = ie.equip_id ))\n" +
            "                                , XMLElement(\"marketingCompatibleSimSkuList\"\n" +
            "                                                 , (Select XMLAgg( XMLElement(\"simSku\", sku_code))\n" +
            "                                                      From sku_dacc s, device_sim_compatibility dc\n" +
            "                                                         , (Select prod_name, mfg_code, effective_date, max(dacc_code) dacc_code\n" +
            "                                                              From sku_dacc\n" +
            "                                                             Group By prod_name, mfg_code, effective_date) s2\n" +
            "                                                     Where dc.dacc           = s2.dacc_code\n" +
            "                                                       And s2.prod_name      = l.prod_name\n" +
            "                                                       And s2.mfg_code       = l.mfg_code\n" +
            "                                                       And s2.effective_date = l.effective_date\n" +
            "                                                       And s.dacc_code       = dc.sacc))\n" +
            "                              ).getClobVal() deviceInfoList\n" +
            "              From launch_package l, manufacturer m, equipment_model e, im_eg_equipment ie, features f, (select distinct PROD_MODEL_NAME,MANUFACTURE_NAME from OD_DATA_LOAD) od\n" +
            "                 , device_mask d, technology t, physical_attributes ph, \n" +
            "               (Select distinct prod_name\n" +
            "                From sku_dacc o\n" +
            "                where o.sku_code = :sorid \n" +
            "                And Not Exists (Select 1 From dmd_universal_api_data d\n" +
            "                                Where d.device_sku   = o.sku_code\n" +
            "                                  And d.device_mask In ('4GS', '4GK','5GM','5GS'))) inp\n" +
            "             Where (l.display_ind is null Or trim(upper(l.display_ind)) <> 'N' Or l.bcc_ind = 'Y')\n" +
            "               And l.prod_name          = inp.prod_name\n" +
            "               And m.mfg_code(+)        = l.mfg_code\n" +
            "               And od.prod_model_name(+)= l.prod_name\n" +
            "               And e.prod_name          = l.prod_name\n" +
            "               And e.mfg_code           = l.mfg_code\n" +
            "               And e.effective_date     = l.effective_date\n" +
            "               And f.prod_name          = l.prod_name\n" +
            "               And f.mfg_code           = l.mfg_code\n" +
            "               And f.effective_date     = l.effective_date\n" +
            "               And f.device_mask_id     = d.device_mask_id(+)\n" +
            "               And t.prod_name(+)       = l.prod_name\n" +
            "               And t.mfg_code(+)        = l.mfg_code\n" +
            "               And t.effective_date(+)  = l.effective_date\n" +
            "               And ph.prod_name(+)      = l.prod_name\n" +
            "               And ph.mfg_code(+)       = l.mfg_code\n" +
            "               And ph.effective_date(+) = l.effective_date\n" +
            "               And ie.equip_id(+)       = l.equip_id";

    public static final String DPI_DEVICE_QUERY = "Select itm_part                 as SKU\n" +
            " , Case When i.itm_class1 In ( 'PHO', 'NIC', 'LTE', 'VRA', 'MPC', 'DAT','5GD') Then\n" +
            "\t\t'DEVICE'\n" +
            "\tElse 'SOFT_SKU' End     as SKU_TYPE\n" +
            " , Case When IL.AREA_LOC  In ( 'HQ') Then\n" +
            "\t\t'1000001'\n" +
            "   Else IL.AREA_LOC End     as LOCATION_CODE\n" +
            " , il.price_4     as FULL_RETAIL_PRICE\n" +
            " , il.price_1     as ONE_YEAR_PRICE\n" +
            " , il.price_2     as TWO_YEAR_PRICE\n" +
            " , il.price_3     as PREPAY_PRICE\n" +
            " , i.itm_wave_eligible      as EDGE_SKU\n" +
            " --, f_get_edge_full_price(i.itm_wave_eligible, il.price_5, il.price_4) as EDGE_FULL_RETAIL_PRICE\n" +
            " , null as EDGE_FULL_RETAIL_PRICE\n" +
            "From atgrep.SAP_SKU_PRICING il, atgrep.SAP_SKU_PRICING nal, atgcore.item i\n" +
            "Where ',' || trim(:sorid/*p_device_sku_list*/) || ',' like '%,' || i.itm_part || ',%'\n" +
            "And i.itm_class1    In ( 'PHO', 'NIC', 'LTE', 'VRA', 'MPC', 'DAT','5GD'\n" +
            "\t\t\t\t\t , 'ACT', 'ADJ', 'LAB', 'LCS', 'WRP', 'WPP', 'TAX', 'WAR', 'CRD', 'SEC', 'FUL', 'CRF', 'NIN' ,'QAC', 'PPP', 'SVC')\n" +
            "And il.sku      = i.itm_part\n" +
            "And nal.sku     = i.itm_part\n" +
            "And NAL.area_loc = 'HQ' and NAL.PRICE_TYPE ='NATIONAL'\n" +
            "And ((il.PRICE_TYPE ='LOC' and il.area_loc in ('P175401','P386501','X473701','X474201','X473201','X473801','X474301','X473301','W233601',\n" +
            "\t\t\t\t\t\t'1529101','W104101','0825301','X473901','X474401','X473401','P560201','1456901','1434901',\n" +
            "\t\t\t\t\t\t'0862001','1456801','0536701','N832401','N832801','N832001','M681101','N112201','M722801',\n" +
            "\t\t\t\t\t\t'N832501','N832901','N832101','N833201','N833001','N832201','X474001','X474501','X473501',\n" +
            "\t\t\t\t\t\t'D463801','D107701','D239301','N833301','N833101','N832301','E248101','E248301','E246901',\n" +
            "\t\t\t\t\t\t'X474101','X474601','X473601','E247401','E248401','E247001','1526901','E247501','E247901',\n" +
            "\t\t\t\t\t\t'E247101','E248201','E248001','E247201','1000001')  )\n" +
            "\t\t\t\t\t\t OR (IL.AREA_LOC = 'HQ' AND IL.PRICE_TYPE ='NATIONAL')\n" +
            "\t\t\t\t\t\t)\n" +
            "And ( ( NAL.area_loc = IL.area_loc and NAL.PRICE_TYPE = il.PRICE_TYPE)\n" +
            "\t Or ( nal.price_1 <> il.price_1 And il.price_1 <> 99999.99 )\n" +
            "\t Or ( nal.price_2 <> il.price_2 And il.price_2 <> 99999.99 )\n" +
            "\t Or ( nal.price_3 <> il.price_3 And il.price_3 <> 99999.99 )\n" +
            "\t Or ( nal.price_4 <> il.price_4 And il.price_4 <> 99999.99 )\n" +
            "  )\n" +
            "Union All\n" +
            "Select itm_part                 as SKU\n" +
            " , Decode( i.itm_class1\n" +
            "\t\t , 'ICC', 'SIM'\n" +
            "\t\t , 'DAT', 'ACC'\n" +
            "\t\t , i.itm_class1)    as SKU_TYPE\n" +
            " , Case When IL.AREA_LOC  In ( 'HQ') Then\n" +
            "\t'1000001'\n" +
            "   Else IL.AREA_LOC End          as LOCATION_CODE\n" +
            " , il.price_1     as FULL_RETAIL_PRICE\n" +
            " , Null                     as ONE_YEAR_PRICE\n" +
            " , Null                     as TWO_YEAR_PRICE\n" +
            " , Null                     as PREPAY_PRICE\n" +
            " , Null                     as EDGE_SKU\n" +
            " , Null                     as EDGE_FULL_RETAIL_PRICE\n" +
            "From atgrep.SAP_SKU_PRICING il, atgrep.SAP_SKU_PRICING nal, atgcore.item i\n" +
            "Where ',' || trim(:sorid/*p_device_sku_list*/) || ',' like '%,' || i.itm_part || ',%'\n" +
            "And i.itm_class1    In ('ACC', 'ICC', 'DAT')\n" +
            "And il.sku      = i.itm_part\n" +
            "And nal.sku     = i.itm_part\n" +
            "And NAL.area_loc = 'HQ' and NAL.PRICE_TYPE ='NATIONAL'\n" +
            "And ((il.PRICE_TYPE ='LOC' and il.area_loc in ('P175401','P386501','X473701','X474201','X473201','X473801','X474301','X473301','W233601',\n" +
            "\t\t\t\t\t\t'1529101','W104101','0825301','X473901','X474401','X473401','P560201','1456901','1434901',\n" +
            "\t\t\t\t\t\t'0862001','1456801','0536701','N832401','N832801','N832001','M681101','N112201','M722801',\n" +
            "\t\t\t\t\t\t'N832501','N832901','N832101','N833201','N833001','N832201','X474001','X474501','X473501',\n" +
            "\t\t\t\t\t\t'D463801','D107701','D239301','N833301','N833101','N832301','E248101','E248301','E246901',\n" +
            "\t\t\t\t\t\t'X474101','X474601','X473601','E247401','E248401','E247001','1526901','E247501','E247901',\n" +
            "\t\t\t\t\t\t'E247101','E248201','E248001','E247201','1000001') )\n" +
            "\t\t\t\t\t\t OR (IL.AREA_LOC = 'HQ' AND IL.PRICE_TYPE ='NATIONAL')\n" +
            "\t\t\t\t\t\t)\n" +
            "And ( ( NAL.area_loc = IL.area_loc and NAL.PRICE_TYPE = il.PRICE_TYPE)\n" +
            " Or ( nal.price_1 <> il.price_1 And il.price_1 <> 99999.99 )\n" +
            "  )";


    public static final String EPC_ACCESSORY_QUERY = " Select po.id as id, po.SOR_ID as SOR_ID ,po.ATG_PRODUCT_ID as ATG_PRODUCT_ID , po.ATG_SKU_ID as ATG_SKU_ID ,po.DISPLAY_NAME as DISPLAY_NAME,acc.IMAGE_NAME as IMAGE_NAME,acc.PROD_CODE_1 as PROD_CODE_1, acc.PROD_CODE_2 as PROD_CODE_2, acc.PROD_CODE_3 as PROD_CODE_3 ,acc.PROD_CODE_4 as PROD_CODE_4 ,acc.PROD_CODE_5 as PROD_CODE_5 ,acc.UPC_CODE as UPC_CODE,acc.UPC_CODE_FULL as UPC_CODE_FULL,manu.MANUFACTURER_NAME as MANUFACTURER_NAME  from VZW_EPC_PO po left outer join vzw_epc_ps_accessory acc on po.ID=acc.ID left outer join vzw_epc_manufacturer manu on po.ID=manu.ID where po.SOR_ID=:sorid ";

    public static final String JSON_PARSE_ERROR = "JSON parse error: ";
    public static final String DEVICE = "device";
    public static final String ACCESSORY = "accessory";

    public static final String COLON = ":";


}
