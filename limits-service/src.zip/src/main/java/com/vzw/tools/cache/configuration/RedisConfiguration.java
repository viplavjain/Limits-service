package com.vzw.tools.cache.configuration;

import com.vzw.tools.cache.properties.RedisProperties;
import com.vzw.tools.common.AESDecrypter;
import com.vzw.tools.common.GzipStringRedisSerializer;
import io.lettuce.core.cluster.ClusterClientOptions;
import io.lettuce.core.cluster.ClusterTopologyRefreshOptions;
import io.lettuce.core.resource.ClientResources;
import io.lettuce.core.resource.DefaultClientResources;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.RedisPassword;
import org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.connection.lettuce.LettucePoolingClientConfiguration;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import java.time.Duration;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import static com.vzw.tools.cache.constant.RedisConstants.*;

@Slf4j
@Configuration
public class RedisConfiguration {

    private final Environment environment;

    private final RedisProperties redisProperties;

    public RedisConfiguration(Environment environment, RedisProperties redisProperties) {
        this.environment = environment;
        this.redisProperties = redisProperties;
    }

    private final Map<Object, RedisTemplate<Object, Object>> redisTemplatesForEnvs = new HashMap<>();
    private final Map<String, String> redisEnvNameForDisplayName = new HashMap<>();

    private void loadTemplate(String envName, String url, String password, boolean useSSL) {
        populateRedisTemplates(envName, url, password, useSSL);
    }

    private LettuceConnectionFactory createConnectionFactory(String envName, String url, String password, boolean useSSL) {
        RedisClusterConfiguration redisClusterConfiguration = new RedisClusterConfiguration(Collections.singletonList(url));
        redisClusterConfiguration.setPassword(RedisPassword.of(password));
        LettuceClientConfiguration lettuceClientConfiguration;
        ClusterClientOptions.Builder clusterOptions = ClusterClientOptions.builder().maxRedirects(ONE);
        ClusterTopologyRefreshOptions.Builder clusterTopologyBuilder = ClusterTopologyRefreshOptions.builder();
        clusterTopologyBuilder.enablePeriodicRefresh(Duration.ofMillis(DURATION));
        clusterTopologyBuilder.enableAllAdaptiveRefreshTriggers();
        clusterOptions.topologyRefreshOptions(clusterTopologyBuilder.build());
        ClientResources clientResource = DefaultClientResources.builder().
                ioThreadPoolSize(DefaultClientResources.DEFAULT_IO_THREADS).
                computationThreadPoolSize(DefaultClientResources.DEFAULT_COMPUTATION_THREADS).build();
        LettucePoolingClientConfiguration.LettucePoolingClientConfigurationBuilder lettucePoolingClientConfigurationBuilder = LettucePoolingClientConfiguration.builder().clientResources(clientResource)
                .poolConfig(poolConfig(envName)).commandTimeout(Duration.ofMillis(TIMEOUT)).shutdownTimeout(Duration.ofMillis(HUNDRED));
        if (useSSL) {
            LettuceClientConfiguration.LettuceSslClientConfigurationBuilder lettuceSslClientConfigurationBuilder = lettucePoolingClientConfigurationBuilder.useSsl();
            lettuceSslClientConfigurationBuilder.and().clientOptions(clusterOptions.validateClusterNodeMembership(FALSE).build());
            lettuceSslClientConfigurationBuilder.disablePeerVerification();
            lettuceClientConfiguration = lettuceSslClientConfigurationBuilder.build();
        } else {
            lettuceClientConfiguration = lettucePoolingClientConfigurationBuilder.build();
        }
        LettuceConnectionFactory lettuceConnectionFactory = new LettuceConnectionFactory(redisClusterConfiguration, lettuceClientConfiguration);
        lettuceConnectionFactory.afterPropertiesSet();
        return lettuceConnectionFactory;
    }

    private void populateRedisTemplates(String envName, String url, String password, boolean useSSL) {
        RedisTemplate<Object, Object> redisTemplate = new RedisTemplate<>();
        StringRedisSerializer stringSerializer = new StringRedisSerializer();
        GzipStringRedisSerializer gzipStringRedisSerializer = new GzipStringRedisSerializer(TRUE);
        redisTemplate.setKeySerializer(stringSerializer);
        redisTemplate.setHashKeySerializer(stringSerializer);
        redisTemplate.setValueSerializer(gzipStringRedisSerializer);
        redisTemplate.setHashValueSerializer(gzipStringRedisSerializer);
        redisTemplate.setConnectionFactory(createConnectionFactory(envName, url, password, useSSL));
        redisTemplate.afterPropertiesSet();
        redisTemplatesForEnvs.put(envName, redisTemplate);
    }

    private GenericObjectPoolConfig<Object> poolConfig(String envName) {
        GenericObjectPoolConfig<Object> genericObjectPoolConfig = new GenericObjectPoolConfig<>();
        genericObjectPoolConfig.setJmxEnabled(TRUE);
        genericObjectPoolConfig.setJmxNamePrefix(REDIS + envName + MINUS);
        genericObjectPoolConfig.setMaxTotal(FIFTY);
        genericObjectPoolConfig.setMaxIdle(TWENTY);
        genericObjectPoolConfig.setMinIdle(FIVE);
        return genericObjectPoolConfig;
    }

    @PostConstruct
    public void loadAllEnvironmentTemplates() {
        AtomicInteger counter = new AtomicInteger(ZERO);
        redisProperties.getRedisEnvDisplayNames().forEach(a -> redisEnvNameForDisplayName.put(a, redisProperties.getRedisEnvDisplayNames().get(counter.getAndIncrement())));
        for (String envname : redisProperties.getRedisEnvDisplayNames()) {
            String cluster = environment.getProperty(EPC_REDIS_PREFIX + envname + CLUSTER);
            String password = environment.getProperty(EPC_REDIS_PREFIX + envname + PASSWORD);
            boolean useSSL = TRUE;
            if (StringUtils.isNotEmpty(environment.getProperty(EPC_REDIS_PREFIX + envname + SSL))
                    && !StringUtils.equalsIgnoreCase(environment.getProperty(EPC_REDIS_PREFIX + envname + SSL), TRUE_VALUE)) {
                useSSL = FALSE;
            }
            boolean usePlainPassword = FALSE;
            String plainPassword = environment.getProperty(EPC_REDIS_PREFIX + envname + PLAIN_PASSWORD);
            if (StringUtils.isNotEmpty(environment.getProperty(EPC_REDIS_PREFIX + envname + USE_PLAIN_PASSWORD))
                    && StringUtils.equalsIgnoreCase(environment.getProperty(EPC_REDIS_PREFIX + envname + USE_PLAIN_PASSWORD), TRUE_VALUE)
                    && StringUtils.isNotEmpty(plainPassword)) {
                usePlainPassword = TRUE;
            }

            String passwordToUse = usePlainPassword ? plainPassword : AESDecrypter.getDecryptedText(password);
            loadTemplate(envname, cluster, passwordToUse, useSSL);
        }
    }

    public RedisTemplate<Object, Object> getRedisTemplatesForEnvs(String envName) {
        String sourceEnv = envName;
        if (!envName.startsWith(ENV)) {
            sourceEnv = redisEnvNameForDisplayName.get(envName);
        }
        return redisTemplatesForEnvs.get(sourceEnv);
    }
}
