package com.vzw.tools.common.entity;

import lombok.Data;

@Data
public class CompareDetails {

    private Boolean isMatch;
    private String source;
    private String target;
}
