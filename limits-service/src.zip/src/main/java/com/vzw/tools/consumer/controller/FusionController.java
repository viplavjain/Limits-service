package com.vzw.tools.consumer.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.vzw.tools.common.exception.ErrorBuilder;
import com.vzw.tools.consumer.entity.FusionResponse;
import com.vzw.tools.consumer.service.FusionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;


@RestController
@Slf4j
public class FusionController {

    private final FusionService fusionService;
    private final ErrorBuilder errorBuilder;

    @Autowired
    public FusionController(FusionService fusionService,ErrorBuilder errorBuilder) {
        this.fusionService = fusionService;
        this.errorBuilder=errorBuilder;
    }

    @GetMapping("/fusion/{productType}/{env}")
    public  Mono<JsonNode> getEPC(@PathVariable String productType,
                                  @PathVariable String env,
                                  @RequestParam(value = "id", required = true) String id) throws JsonProcessingException {
        return fusionService.getFusionServiceDetails(id,productType, env)
                .onErrorMap(err -> errorBuilder.buildApplicationException(err));
    }
}
