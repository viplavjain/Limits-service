package com.vzw.tools.source.entity;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class DPIModel {

    public String sku;  //sorID or itm_part

    public String skuType; //itm_class1

    public String oneYearPrice; //price_1

    public String twoYearPrice; //price_2

    public String prepayPrice; //price_3

    public String fullRetailPrice; //price_4

    public String locationCode; //area_loc

    public String edgeSku; //itm_wave_eligible

    public String edgeFullRetailPrice; //(itm_wave_eligible+price_4+price_5)
}

