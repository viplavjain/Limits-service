package com.vzw.tools.consumer.constant;

public class FusionConstants {

    public static String HOST_PROPERTY = "spring.fusion.host.";
    public static String HOST_USERNAME = "spring.fusion.username.";
    public static String HOST_PASSWORD = "spring.fusion.password.";

}
