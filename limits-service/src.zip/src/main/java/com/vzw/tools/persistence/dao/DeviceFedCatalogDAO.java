package com.vzw.tools.persistence.dao;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;


@Getter
@Setter
public class DeviceFedCatalogDAO {

    public String SKU_ID;

    public BigDecimal ACTIVE_FLAG;

    public BigDecimal SHOWCASE_IND;

    public String SUPPORT_ONLY_FLAG;

    public BigDecimal DISPLAY_IN_SITE_SEARCH;

    public String DISPLAY_NAME;

    public String SOR_PRELAUNCH_IND;

    public BigDecimal edgeFullRetailPrice;
}

