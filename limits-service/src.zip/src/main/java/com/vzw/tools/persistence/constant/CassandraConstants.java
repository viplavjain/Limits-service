package com.vzw.tools.persistence.constant;

public class CassandraConstants {
    public static String HEADER_CLIENT_ID = "CLIENT_ID";
    public static String HEADER_CHANNEL_ID = "CHANNEL_ID";
    public static final String headerXApiKey = "x-apikey";
    public static String PRODUCT_OFFERING_URL = "productCatalog-internal/productOffering?";
    public static String PRODUCT_OFFERING_GROUP_URL = "productCatalog-internal/productOfferingGroup/";
    public static final String productPromotionUrl = "productCatalog-internal/promotion?";
    public static final String productPromotionPriceOfferingUrl = "productCatalog-internal/productOfferingPrice/";
    public static final String promotionProductCatalog = "productCatalog-internal";
    public static final String promotionProductOfferingPrice = "productOfferingPrice";
}
