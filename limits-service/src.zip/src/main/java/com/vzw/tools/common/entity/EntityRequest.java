package com.vzw.tools.common.entity;

public class EntityRequest {

    private String environment;
    private String entityType;
    private String sorId;

}
