package com.vzw.tools.persistence.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@lombok.Data
@JsonIgnoreProperties(ignoreUnknown = true)
public  class Parameter {
    private String name;
    private String value;

}