package com.vzw.tools.common.entity;

import lombok.Getter;
import lombok.Setter;

import java.util.Objects;

@Getter
@Setter
public class EntityRecord {

    private String field;
    private String value;
    private String system;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EntityRecord that = (EntityRecord) o;
        return Objects.equals(getField(), that.getField()) && Objects.equals(getValue(), that.getValue());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getField(), getValue());
    }

    public EntityRecord(String system) {
        this.system = system;
    }


}
