//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.vzw.tools.helpers.logging.vo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(Include.NON_NULL)
public class Event {
    @JsonProperty("start_time")
    private long startTime;
    @JsonProperty("end_time")
    private long endTime;
    @JsonProperty("duration")
    private long duration;
    @JsonProperty("e2erequestid")
    private String e2eRequestId;
    @JsonProperty("correlation_id")
    private String correlationId;
    @JsonProperty("ms_name")
    private String msName;
    @JsonProperty("app_name")
    private String appName;
    @JsonProperty("event_type")
    private String eventType;
    @JsonProperty("log_type")
    private String logType;
    @JsonProperty("status_message")
    private String statusMessage;
    @JsonProperty("api_status_msg")
    private String apiStatusMsg;
    @JsonProperty("status_code")
    private Integer statusCode;
    @JsonProperty("api_status_code")
    private Integer apiStatusCode;
    private String request;
    private String response;
    @JsonProperty("api_request")
    private String apiRequest;
    @JsonProperty("api_response")
    private String apiResponse;
    @JsonProperty("request_headers")
    private String requestHeaders;
    @JsonProperty("response_headers")
    private String responseHeaders;
    @JsonProperty("http_status_code")
    private Integer httpStatusCode;
    @JsonProperty("api_url")
    private String apiUrl;
    @JsonProperty("request_uri")
    private String requestUri;
    @JsonProperty("VSAD_ID")
    private String vsadId;
    @JsonProperty("project_application_vsad")
    private String projectApplicationVSAD;
    @JsonProperty("type")
    private String type;
    @JsonProperty("app_group")
    private String appGroup;
    @JsonProperty("vast_id")
    private Integer vastId;
    @JsonProperty("api_name")
    private String apiName;
    @JsonProperty("log_time_stamp")
    private String logTimeStamp;
    @JsonProperty("function_path")
    private String functionPath;
    @JsonProperty("error_message")
    private String errorMessage;
    @JsonProperty("error_code")
    private Integer errorCode;
    @JsonProperty("result_status")
    private String resultStatus;
    @JsonProperty("response_size")
    private Integer responseSize;
    @JsonProperty("request_size")
    private Integer requestSize;
    @JsonProperty("http_verb")
    private String httpVerb;
    @JsonProperty("http_method")
    private String httpMethod;
    @JsonProperty("cxp_correlation_id")
    private String cxpCorrelationId;
    @JsonProperty("cust_id_no")
    private String custIdNo;
    @JsonProperty("cust_id")
    private String custId;
    @JsonProperty("acct_no")
    private String acctNo;
    @JsonProperty("mtn")
    private String mtn;
    @JsonProperty("external_system")
    private String externalSystem;
    @JsonProperty("external_request_id")
    private String externalRequestId;
    @JsonProperty("function_name")
    private String functionName;
    @JsonProperty("client_id")
    private String clientId;
    @JsonProperty("status")
    private String status;
    @JsonProperty("dvs_correlation_Id")
    private String dvsCorrelationId;
    @JsonProperty("cart_id")
    private String cartId;
    @JsonProperty("logged_in_user_id")
    private String loggedInUserId;
    @JsonProperty("user_id")
    private String userId;
    @JsonProperty("log_level")
    private String logLevel;
    @JsonProperty("level")
    private String level;
    @JsonIgnore
    Map<String, Object> extraInfo = new HashMap();
    @JsonProperty("error_key")
    private String errorKey;
    private String msg;
    private boolean logPayload;
    private String application;
    @JsonProperty("ds_correlation_id")
    private String domainCorrelationId;
    @JsonProperty("response_status_code")
    private String responseStatusCode;
    @JsonProperty("response_status_message")
    private String responseStatusMessage;
    @JsonProperty("response_status_detailed_message")
    private String responseStatusDetailedMessage;
    @JsonProperty("external_api_url")
    private String externalApiUrl;
    @JsonProperty("request_path")
    private String requestPath;
    @JsonProperty("query_params")
    private String queryParams;
    @JsonProperty("route-type")
    private String routeType;
    @JsonProperty("external_correlation_id")
    private String externalCorrelationId;
    @JsonProperty("session_id")
    private String sessionId;
    @JsonProperty("sso_session_id")
    private String ssoSessionId;
    @JsonProperty("app_session_id")
    private String appSessionId;
    @JsonProperty("input_fields")
    private String inputFields;
    @JsonProperty("input_values")
    private String inputValues;
    @JsonProperty("system")
    private String system;
    @JsonProperty("host_name")
    private String hostName;
    @JsonProperty("version")
    private float version;
    @JsonProperty("app_version")
    private Integer appVersion;
    @JsonProperty("true_ip")
    private String trueIp;
    @JsonProperty("user_agent")
    private String userAgent;
    @JsonProperty("user_device")
    private String userDevice;
    @JsonProperty("logger_class")
    private String loggerClass;
    @JsonProperty("page_name")
    private String pageName;
    @JsonProperty("browser_thumbprint")
    private String browserThumbprint;
    @JsonProperty("view_port_x")
    private String viewPortX;
    @JsonProperty("view_port_y")
    private String viewPortY;
    @JsonProperty("clicked_element")
    private String clickedElement;
    @JsonProperty("click_x")
    private String clickX;
    @JsonProperty("click_y")
    private String clickY;
    @JsonProperty("customer_type")
    private String customerType;
    @JsonProperty("page_referrer")
    private String pageReferrer;
    @JsonProperty("server_host")
    private String serverHost;
    @JsonProperty("server_port")
    private Integer serverPort;
    @JsonProperty("app_flow")
    private String appFlow;
    @JsonProperty("app_type")
    private String appType;
    @JsonProperty("app_environment")
    private String appEnvironment;
    @JsonProperty("journey_entry_point")
    private String journeyEntryPoint;
    @JsonProperty("type_alias")
    private String typeAlias;
    @JsonProperty("is_valued_transaction")
    private String isValuedTransaction;
    @JsonProperty("transaction_value")
    private Integer transactionValue;
    @JsonProperty("is_account_info_view")
    private String isAccountInfoView;
    @JsonProperty("account_info_view_type")
    private String accountInfoViewType;
    @JsonProperty("is_account_info_change")
    private String isAccountInfoChange;
    @JsonProperty("account_info_change_type")
    private String accountInfoChangeType;
    @JsonProperty("app_level_info")
    private String appLevelInfo;

    protected Event(EventBuilder<?, ?> b) {
        this.startTime = b.startTime;
        this.endTime = b.endTime;
        this.duration = b.duration;
        this.e2eRequestId = b.e2eRequestId;
        this.correlationId = b.correlationId;
        this.msName = b.msName;
        this.appName = b.appName;
        this.eventType = b.eventType;
        this.logType = b.logType;
        this.statusMessage = b.statusMessage;
        this.apiStatusMsg = b.apiStatusMsg;
        this.statusCode = b.statusCode;
        this.apiStatusCode = b.apiStatusCode;
        this.request = b.request;
        this.response = b.response;
        this.apiRequest = b.apiRequest;
        this.apiResponse = b.apiResponse;
        this.requestHeaders = b.requestHeaders;
        this.responseHeaders = b.responseHeaders;
        this.httpStatusCode = b.httpStatusCode;
        this.apiUrl = b.apiUrl;
        this.requestUri = b.requestUri;
        this.vsadId = b.vsadId;
        this.projectApplicationVSAD = b.projectApplicationVSAD;
        this.type = b.type;
        this.appGroup = b.appGroup;
        this.vastId = b.vastId;
        this.apiName = b.apiName;
        this.logTimeStamp = b.logTimeStamp;
        this.functionPath = b.functionPath;
        this.errorMessage = b.errorMessage;
        this.errorCode = b.errorCode;
        this.resultStatus = b.resultStatus;
        this.responseSize = b.responseSize;
        this.requestSize = b.requestSize;
        this.httpVerb = b.httpVerb;
        this.httpMethod = b.httpMethod;
        this.cxpCorrelationId = b.cxpCorrelationId;
        this.custIdNo = b.custIdNo;
        this.custId = b.custId;
        this.acctNo = b.acctNo;
        this.mtn = b.mtn;
        this.externalSystem = b.externalSystem;
        this.externalRequestId = b.externalRequestId;
        this.functionName = b.functionName;
        this.clientId = b.clientId;
        this.status = b.status;
        this.dvsCorrelationId = b.dvsCorrelationId;
        this.cartId = b.cartId;
        this.loggedInUserId = b.loggedInUserId;
        this.userId = b.userId;
        this.logLevel = b.logLevel;
        this.level = b.level;
        this.extraInfo = b.extraInfo;
        this.errorKey = b.errorKey;
        this.msg = b.msg;
        this.logPayload = b.logPayload;
        this.application = b.application;
        this.domainCorrelationId = b.domainCorrelationId;
        this.responseStatusCode = b.responseStatusCode;
        this.responseStatusMessage = b.responseStatusMessage;
        this.responseStatusDetailedMessage = b.responseStatusDetailedMessage;
        this.externalApiUrl = b.externalApiUrl;
        this.requestPath = b.requestPath;
        this.queryParams = b.queryParams;
        this.routeType = b.routeType;
        this.externalCorrelationId = b.externalCorrelationId;
        this.sessionId = b.sessionId;
        this.ssoSessionId = b.ssoSessionId;
        this.appSessionId = b.appSessionId;
        this.inputFields = b.inputFields;
        this.inputValues = b.inputValues;
        this.system = b.system;
        this.hostName = b.hostName;
        this.version = b.version;
        this.appVersion = b.appVersion;
        this.trueIp = b.trueIp;
        this.userAgent = b.userAgent;
        this.userDevice = b.userDevice;
        this.loggerClass = b.loggerClass;
        this.pageName = b.pageName;
        this.browserThumbprint = b.browserThumbprint;
        this.viewPortX = b.viewPortX;
        this.viewPortY = b.viewPortY;
        this.clickedElement = b.clickedElement;
        this.clickX = b.clickX;
        this.clickY = b.clickY;
        this.customerType = b.customerType;
        this.pageReferrer = b.pageReferrer;
        this.serverHost = b.serverHost;
        this.serverPort = b.serverPort;
        this.appFlow = b.appFlow;
        this.appType = b.appType;
        this.appEnvironment = b.appEnvironment;
        this.journeyEntryPoint = b.journeyEntryPoint;
        this.typeAlias = b.typeAlias;
        this.isValuedTransaction = b.isValuedTransaction;
        this.transactionValue = b.transactionValue;
        this.isAccountInfoView = b.isAccountInfoView;
        this.accountInfoViewType = b.accountInfoViewType;
        this.isAccountInfoChange = b.isAccountInfoChange;
        this.accountInfoChangeType = b.accountInfoChangeType;
        this.appLevelInfo = b.appLevelInfo;
    }

    public static EventBuilder<?, ?> builder() {
        return new EventBuilderImpl();
    }

    public long getStartTime() {
        return this.startTime;
    }

    public long getEndTime() {
        return this.endTime;
    }

    public long getDuration() {
        return this.duration;
    }

    public String getE2eRequestId() {
        return this.e2eRequestId;
    }

    public String getCorrelationId() {
        return this.correlationId;
    }

    public String getMsName() {
        return this.msName;
    }

    public String getAppName() {
        return this.appName;
    }

    public String getEventType() {
        return this.eventType;
    }

    public String getLogType() {
        return this.logType;
    }

    public String getStatusMessage() {
        return this.statusMessage;
    }

    public String getApiStatusMsg() {
        return this.apiStatusMsg;
    }

    public Integer getStatusCode() {
        return this.statusCode;
    }

    public Integer getApiStatusCode() {
        return this.apiStatusCode;
    }

    public String getRequest() {
        return this.request;
    }

    public String getResponse() {
        return this.response;
    }

    public String getApiRequest() {
        return this.apiRequest;
    }

    public String getApiResponse() {
        return this.apiResponse;
    }

    public String getRequestHeaders() {
        return this.requestHeaders;
    }

    public String getResponseHeaders() {
        return this.responseHeaders;
    }

    public Integer getHttpStatusCode() {
        return this.httpStatusCode;
    }

    public String getApiUrl() {
        return this.apiUrl;
    }

    public String getRequestUri() {
        return this.requestUri;
    }

    public String getVsadId() {
        return this.vsadId;
    }

    public String getProjectApplicationVSAD() {
        return this.projectApplicationVSAD;
    }

    public String getType() {
        return this.type;
    }

    public String getAppGroup() {
        return this.appGroup;
    }

    public Integer getVastId() {
        return this.vastId;
    }

    public String getApiName() {
        return this.apiName;
    }

    public String getLogTimeStamp() {
        return this.logTimeStamp;
    }

    public String getFunctionPath() {
        return this.functionPath;
    }

    public String getErrorMessage() {
        return this.errorMessage;
    }

    public Integer getErrorCode() {
        return this.errorCode;
    }

    public String getResultStatus() {
        return this.resultStatus;
    }

    public Integer getResponseSize() {
        return this.responseSize;
    }

    public Integer getRequestSize() {
        return this.requestSize;
    }

    public String getHttpVerb() {
        return this.httpVerb;
    }

    public String getHttpMethod() {
        return this.httpMethod;
    }

    public String getCxpCorrelationId() {
        return this.cxpCorrelationId;
    }

    public String getCustIdNo() {
        return this.custIdNo;
    }

    public String getCustId() {
        return this.custId;
    }

    public String getAcctNo() {
        return this.acctNo;
    }

    public String getMtn() {
        return this.mtn;
    }

    public String getExternalSystem() {
        return this.externalSystem;
    }

    public String getExternalRequestId() {
        return this.externalRequestId;
    }

    public String getFunctionName() {
        return this.functionName;
    }

    public String getClientId() {
        return this.clientId;
    }

    public String getStatus() {
        return this.status;
    }

    public String getDvsCorrelationId() {
        return this.dvsCorrelationId;
    }

    public String getCartId() {
        return this.cartId;
    }

    public String getLoggedInUserId() {
        return this.loggedInUserId;
    }

    public String getUserId() {
        return this.userId;
    }

    public String getLogLevel() {
        return this.logLevel;
    }

    public String getLevel() {
        return this.level;
    }

    public Map<String, Object> getExtraInfo() {
        return this.extraInfo;
    }

    public String getErrorKey() {
        return this.errorKey;
    }

    public String getMsg() {
        return this.msg;
    }

    public boolean isLogPayload() {
        return this.logPayload;
    }

    public String getApplication() {
        return this.application;
    }

    public String getDomainCorrelationId() {
        return this.domainCorrelationId;
    }

    public String getResponseStatusCode() {
        return this.responseStatusCode;
    }

    public String getResponseStatusMessage() {
        return this.responseStatusMessage;
    }

    public String getResponseStatusDetailedMessage() {
        return this.responseStatusDetailedMessage;
    }

    public String getExternalApiUrl() {
        return this.externalApiUrl;
    }

    public String getRequestPath() {
        return this.requestPath;
    }

    public String getQueryParams() {
        return this.queryParams;
    }

    public String getRouteType() {
        return this.routeType;
    }

    public String getExternalCorrelationId() {
        return this.externalCorrelationId;
    }

    public String getSessionId() {
        return this.sessionId;
    }

    public String getSsoSessionId() {
        return this.ssoSessionId;
    }

    public String getAppSessionId() {
        return this.appSessionId;
    }

    public String getInputFields() {
        return this.inputFields;
    }

    public String getInputValues() {
        return this.inputValues;
    }

    public String getSystem() {
        return this.system;
    }

    public String getHostName() {
        return this.hostName;
    }

    public float getVersion() {
        return this.version;
    }

    public Integer getAppVersion() {
        return this.appVersion;
    }

    public String getTrueIp() {
        return this.trueIp;
    }

    public String getUserAgent() {
        return this.userAgent;
    }

    public String getUserDevice() {
        return this.userDevice;
    }

    public String getLoggerClass() {
        return this.loggerClass;
    }

    public String getPageName() {
        return this.pageName;
    }

    public String getBrowserThumbprint() {
        return this.browserThumbprint;
    }

    public String getViewPortX() {
        return this.viewPortX;
    }

    public String getViewPortY() {
        return this.viewPortY;
    }

    public String getClickedElement() {
        return this.clickedElement;
    }

    public String getClickX() {
        return this.clickX;
    }

    public String getClickY() {
        return this.clickY;
    }

    public String getCustomerType() {
        return this.customerType;
    }

    public String getPageReferrer() {
        return this.pageReferrer;
    }

    public String getServerHost() {
        return this.serverHost;
    }

    public Integer getServerPort() {
        return this.serverPort;
    }

    public String getAppFlow() {
        return this.appFlow;
    }

    public String getAppType() {
        return this.appType;
    }

    public String getAppEnvironment() {
        return this.appEnvironment;
    }

    public String getJourneyEntryPoint() {
        return this.journeyEntryPoint;
    }

    public String getTypeAlias() {
        return this.typeAlias;
    }

    public String getIsValuedTransaction() {
        return this.isValuedTransaction;
    }

    public Integer getTransactionValue() {
        return this.transactionValue;
    }

    public String getIsAccountInfoView() {
        return this.isAccountInfoView;
    }

    public String getAccountInfoViewType() {
        return this.accountInfoViewType;
    }

    public String getIsAccountInfoChange() {
        return this.isAccountInfoChange;
    }

    public String getAccountInfoChangeType() {
        return this.accountInfoChangeType;
    }

    public String getAppLevelInfo() {
        return this.appLevelInfo;
    }

    @JsonProperty("start_time")
    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    @JsonProperty("end_time")
    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

    @JsonProperty("duration")
    public void setDuration(long duration) {
        this.duration = duration;
    }

    @JsonProperty("e2erequestid")
    public void setE2eRequestId(String e2eRequestId) {
        this.e2eRequestId = e2eRequestId;
    }

    @JsonProperty("correlation_id")
    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    @JsonProperty("ms_name")
    public void setMsName(String msName) {
        this.msName = msName;
    }

    @JsonProperty("app_name")
    public void setAppName(String appName) {
        this.appName = appName;
    }

    @JsonProperty("event_type")
    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    @JsonProperty("log_type")
    public void setLogType(String logType) {
        this.logType = logType;
    }

    @JsonProperty("status_message")
    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    @JsonProperty("api_status_msg")
    public void setApiStatusMsg(String apiStatusMsg) {
        this.apiStatusMsg = apiStatusMsg;
    }

    @JsonProperty("status_code")
    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    @JsonProperty("api_status_code")
    public void setApiStatusCode(Integer apiStatusCode) {
        this.apiStatusCode = apiStatusCode;
    }

    public void setRequest(String request) {
        this.request = request;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    @JsonProperty("api_request")
    public void setApiRequest(String apiRequest) {
        this.apiRequest = apiRequest;
    }

    @JsonProperty("api_response")
    public void setApiResponse(String apiResponse) {
        this.apiResponse = apiResponse;
    }

    @JsonProperty("request_headers")
    public void setRequestHeaders(String requestHeaders) {
        this.requestHeaders = requestHeaders;
    }

    @JsonProperty("response_headers")
    public void setResponseHeaders(String responseHeaders) {
        this.responseHeaders = responseHeaders;
    }

    @JsonProperty("http_status_code")
    public void setHttpStatusCode(Integer httpStatusCode) {
        this.httpStatusCode = httpStatusCode;
    }

    @JsonProperty("api_url")
    public void setApiUrl(String apiUrl) {
        this.apiUrl = apiUrl;
    }

    @JsonProperty("request_uri")
    public void setRequestUri(String requestUri) {
        this.requestUri = requestUri;
    }

    @JsonProperty("VSAD_ID")
    public void setVsadId(String vsadId) {
        this.vsadId = vsadId;
    }

    @JsonProperty("project_application_vsad")
    public void setProjectApplicationVSAD(String projectApplicationVSAD) {
        this.projectApplicationVSAD = projectApplicationVSAD;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("app_group")
    public void setAppGroup(String appGroup) {
        this.appGroup = appGroup;
    }

    @JsonProperty("vast_id")
    public void setVastId(Integer vastId) {
        this.vastId = vastId;
    }

    @JsonProperty("api_name")
    public void setApiName(String apiName) {
        this.apiName = apiName;
    }

    @JsonProperty("log_time_stamp")
    public void setLogTimeStamp(String logTimeStamp) {
        this.logTimeStamp = logTimeStamp;
    }

    @JsonProperty("function_path")
    public void setFunctionPath(String functionPath) {
        this.functionPath = functionPath;
    }

    @JsonProperty("error_message")
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    @JsonProperty("error_code")
    public void setErrorCode(Integer errorCode) {
        this.errorCode = errorCode;
    }

    @JsonProperty("result_status")
    public void setResultStatus(String resultStatus) {
        this.resultStatus = resultStatus;
    }

    @JsonProperty("response_size")
    public void setResponseSize(Integer responseSize) {
        this.responseSize = responseSize;
    }

    @JsonProperty("request_size")
    public void setRequestSize(Integer requestSize) {
        this.requestSize = requestSize;
    }

    @JsonProperty("http_verb")
    public void setHttpVerb(String httpVerb) {
        this.httpVerb = httpVerb;
    }

    @JsonProperty("http_method")
    public void setHttpMethod(String httpMethod) {
        this.httpMethod = httpMethod;
    }

    @JsonProperty("cxp_correlation_id")
    public void setCxpCorrelationId(String cxpCorrelationId) {
        this.cxpCorrelationId = cxpCorrelationId;
    }

    @JsonProperty("cust_id_no")
    public void setCustIdNo(String custIdNo) {
        this.custIdNo = custIdNo;
    }

    @JsonProperty("cust_id")
    public void setCustId(String custId) {
        this.custId = custId;
    }

    @JsonProperty("acct_no")
    public void setAcctNo(String acctNo) {
        this.acctNo = acctNo;
    }

    @JsonProperty("mtn")
    public void setMtn(String mtn) {
        this.mtn = mtn;
    }

    @JsonProperty("external_system")
    public void setExternalSystem(String externalSystem) {
        this.externalSystem = externalSystem;
    }

    @JsonProperty("external_request_id")
    public void setExternalRequestId(String externalRequestId) {
        this.externalRequestId = externalRequestId;
    }

    @JsonProperty("function_name")
    public void setFunctionName(String functionName) {
        this.functionName = functionName;
    }

    @JsonProperty("client_id")
    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    @JsonProperty("status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("dvs_correlation_Id")
    public void setDvsCorrelationId(String dvsCorrelationId) {
        this.dvsCorrelationId = dvsCorrelationId;
    }

    @JsonProperty("cart_id")
    public void setCartId(String cartId) {
        this.cartId = cartId;
    }

    @JsonProperty("logged_in_user_id")
    public void setLoggedInUserId(String loggedInUserId) {
        this.loggedInUserId = loggedInUserId;
    }

    @JsonProperty("user_id")
    public void setUserId(String userId) {
        this.userId = userId;
    }

    @JsonProperty("log_level")
    public void setLogLevel(String logLevel) {
        this.logLevel = logLevel;
    }

    @JsonProperty("level")
    public void setLevel(String level) {
        this.level = level;
    }

    @JsonIgnore
    public void setExtraInfo(Map<String, Object> extraInfo) {
        this.extraInfo = extraInfo;
    }

    @JsonProperty("error_key")
    public void setErrorKey(String errorKey) {
        this.errorKey = errorKey;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setLogPayload(boolean logPayload) {
        this.logPayload = logPayload;
    }

    public void setApplication(String application) {
        this.application = application;
    }

    @JsonProperty("ds_correlation_id")
    public void setDomainCorrelationId(String domainCorrelationId) {
        this.domainCorrelationId = domainCorrelationId;
    }

    @JsonProperty("response_status_code")
    public void setResponseStatusCode(String responseStatusCode) {
        this.responseStatusCode = responseStatusCode;
    }

    @JsonProperty("response_status_message")
    public void setResponseStatusMessage(String responseStatusMessage) {
        this.responseStatusMessage = responseStatusMessage;
    }

    @JsonProperty("response_status_detailed_message")
    public void setResponseStatusDetailedMessage(String responseStatusDetailedMessage) {
        this.responseStatusDetailedMessage = responseStatusDetailedMessage;
    }

    @JsonProperty("external_api_url")
    public void setExternalApiUrl(String externalApiUrl) {
        this.externalApiUrl = externalApiUrl;
    }

    @JsonProperty("request_path")
    public void setRequestPath(String requestPath) {
        this.requestPath = requestPath;
    }

    @JsonProperty("query_params")
    public void setQueryParams(String queryParams) {
        this.queryParams = queryParams;
    }

    @JsonProperty("route-type")
    public void setRouteType(String routeType) {
        this.routeType = routeType;
    }

    @JsonProperty("external_correlation_id")
    public void setExternalCorrelationId(String externalCorrelationId) {
        this.externalCorrelationId = externalCorrelationId;
    }

    @JsonProperty("session_id")
    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    @JsonProperty("sso_session_id")
    public void setSsoSessionId(String ssoSessionId) {
        this.ssoSessionId = ssoSessionId;
    }

    @JsonProperty("app_session_id")
    public void setAppSessionId(String appSessionId) {
        this.appSessionId = appSessionId;
    }

    @JsonProperty("input_fields")
    public void setInputFields(String inputFields) {
        this.inputFields = inputFields;
    }

    @JsonProperty("input_values")
    public void setInputValues(String inputValues) {
        this.inputValues = inputValues;
    }

    @JsonProperty("system")
    public void setSystem(String system) {
        this.system = system;
    }

    @JsonProperty("host_name")
    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    @JsonProperty("version")
    public void setVersion(float version) {
        this.version = version;
    }

    @JsonProperty("app_version")
    public void setAppVersion(Integer appVersion) {
        this.appVersion = appVersion;
    }

    @JsonProperty("true_ip")
    public void setTrueIp(String trueIp) {
        this.trueIp = trueIp;
    }

    @JsonProperty("user_agent")
    public void setUserAgent(String userAgent) {
        this.userAgent = userAgent;
    }

    @JsonProperty("user_device")
    public void setUserDevice(String userDevice) {
        this.userDevice = userDevice;
    }

    @JsonProperty("logger_class")
    public void setLoggerClass(String loggerClass) {
        this.loggerClass = loggerClass;
    }

    @JsonProperty("page_name")
    public void setPageName(String pageName) {
        this.pageName = pageName;
    }

    @JsonProperty("browser_thumbprint")
    public void setBrowserThumbprint(String browserThumbprint) {
        this.browserThumbprint = browserThumbprint;
    }

    @JsonProperty("view_port_x")
    public void setViewPortX(String viewPortX) {
        this.viewPortX = viewPortX;
    }

    @JsonProperty("view_port_y")
    public void setViewPortY(String viewPortY) {
        this.viewPortY = viewPortY;
    }

    @JsonProperty("clicked_element")
    public void setClickedElement(String clickedElement) {
        this.clickedElement = clickedElement;
    }

    @JsonProperty("click_x")
    public void setClickX(String clickX) {
        this.clickX = clickX;
    }

    @JsonProperty("click_y")
    public void setClickY(String clickY) {
        this.clickY = clickY;
    }

    @JsonProperty("customer_type")
    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    @JsonProperty("page_referrer")
    public void setPageReferrer(String pageReferrer) {
        this.pageReferrer = pageReferrer;
    }

    @JsonProperty("server_host")
    public void setServerHost(String serverHost) {
        this.serverHost = serverHost;
    }

    @JsonProperty("server_port")
    public void setServerPort(Integer serverPort) {
        this.serverPort = serverPort;
    }

    @JsonProperty("app_flow")
    public void setAppFlow(String appFlow) {
        this.appFlow = appFlow;
    }

    @JsonProperty("app_type")
    public void setAppType(String appType) {
        this.appType = appType;
    }

    @JsonProperty("app_environment")
    public void setAppEnvironment(String appEnvironment) {
        this.appEnvironment = appEnvironment;
    }

    @JsonProperty("journey_entry_point")
    public void setJourneyEntryPoint(String journeyEntryPoint) {
        this.journeyEntryPoint = journeyEntryPoint;
    }

    @JsonProperty("type_alias")
    public void setTypeAlias(String typeAlias) {
        this.typeAlias = typeAlias;
    }

    @JsonProperty("is_valued_transaction")
    public void setIsValuedTransaction(String isValuedTransaction) {
        this.isValuedTransaction = isValuedTransaction;
    }

    @JsonProperty("transaction_value")
    public void setTransactionValue(Integer transactionValue) {
        this.transactionValue = transactionValue;
    }

    @JsonProperty("is_account_info_view")
    public void setIsAccountInfoView(String isAccountInfoView) {
        this.isAccountInfoView = isAccountInfoView;
    }

    @JsonProperty("account_info_view_type")
    public void setAccountInfoViewType(String accountInfoViewType) {
        this.accountInfoViewType = accountInfoViewType;
    }

    @JsonProperty("is_account_info_change")
    public void setIsAccountInfoChange(String isAccountInfoChange) {
        this.isAccountInfoChange = isAccountInfoChange;
    }

    @JsonProperty("account_info_change_type")
    public void setAccountInfoChangeType(String accountInfoChangeType) {
        this.accountInfoChangeType = accountInfoChangeType;
    }

    @JsonProperty("app_level_info")
    public void setAppLevelInfo(String appLevelInfo) {
        this.appLevelInfo = appLevelInfo;
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        } else if (!(o instanceof Event)) {
            return false;
        } else {
            Event other = (Event)o;
            if (!other.canEqual(this)) {
                return false;
            } else if (this.getStartTime() != other.getStartTime()) {
                return false;
            } else if (this.getEndTime() != other.getEndTime()) {
                return false;
            } else if (this.getDuration() != other.getDuration()) {
                return false;
            } else if (this.isLogPayload() != other.isLogPayload()) {
                return false;
            } else if (Float.compare(this.getVersion(), other.getVersion()) != 0) {
                return false;
            } else {
                Object this$statusCode = this.getStatusCode();
                Object other$statusCode = other.getStatusCode();
                if (this$statusCode == null) {
                    if (other$statusCode != null) {
                        return false;
                    }
                } else if (!this$statusCode.equals(other$statusCode)) {
                    return false;
                }

                label1192: {
                    Object this$apiStatusCode = this.getApiStatusCode();
                    Object other$apiStatusCode = other.getApiStatusCode();
                    if (this$apiStatusCode == null) {
                        if (other$apiStatusCode == null) {
                            break label1192;
                        }
                    } else if (this$apiStatusCode.equals(other$apiStatusCode)) {
                        break label1192;
                    }

                    return false;
                }

                label1185: {
                    Object this$httpStatusCode = this.getHttpStatusCode();
                    Object other$httpStatusCode = other.getHttpStatusCode();
                    if (this$httpStatusCode == null) {
                        if (other$httpStatusCode == null) {
                            break label1185;
                        }
                    } else if (this$httpStatusCode.equals(other$httpStatusCode)) {
                        break label1185;
                    }

                    return false;
                }

                Object this$vastId = this.getVastId();
                Object other$vastId = other.getVastId();
                if (this$vastId == null) {
                    if (other$vastId != null) {
                        return false;
                    }
                } else if (!this$vastId.equals(other$vastId)) {
                    return false;
                }

                Object this$errorCode = this.getErrorCode();
                Object other$errorCode = other.getErrorCode();
                if (this$errorCode == null) {
                    if (other$errorCode != null) {
                        return false;
                    }
                } else if (!this$errorCode.equals(other$errorCode)) {
                    return false;
                }

                label1164: {
                    Object this$responseSize = this.getResponseSize();
                    Object other$responseSize = other.getResponseSize();
                    if (this$responseSize == null) {
                        if (other$responseSize == null) {
                            break label1164;
                        }
                    } else if (this$responseSize.equals(other$responseSize)) {
                        break label1164;
                    }

                    return false;
                }

                Object this$requestSize = this.getRequestSize();
                Object other$requestSize = other.getRequestSize();
                if (this$requestSize == null) {
                    if (other$requestSize != null) {
                        return false;
                    }
                } else if (!this$requestSize.equals(other$requestSize)) {
                    return false;
                }

                Object this$appVersion = this.getAppVersion();
                Object other$appVersion = other.getAppVersion();
                if (this$appVersion == null) {
                    if (other$appVersion != null) {
                        return false;
                    }
                } else if (!this$appVersion.equals(other$appVersion)) {
                    return false;
                }

                label1143: {
                    Object this$serverPort = this.getServerPort();
                    Object other$serverPort = other.getServerPort();
                    if (this$serverPort == null) {
                        if (other$serverPort == null) {
                            break label1143;
                        }
                    } else if (this$serverPort.equals(other$serverPort)) {
                        break label1143;
                    }

                    return false;
                }

                Object this$transactionValue = this.getTransactionValue();
                Object other$transactionValue = other.getTransactionValue();
                if (this$transactionValue == null) {
                    if (other$transactionValue != null) {
                        return false;
                    }
                } else if (!this$transactionValue.equals(other$transactionValue)) {
                    return false;
                }

                label1129: {
                    Object this$e2eRequestId = this.getE2eRequestId();
                    Object other$e2eRequestId = other.getE2eRequestId();
                    if (this$e2eRequestId == null) {
                        if (other$e2eRequestId == null) {
                            break label1129;
                        }
                    } else if (this$e2eRequestId.equals(other$e2eRequestId)) {
                        break label1129;
                    }

                    return false;
                }

                label1122: {
                    Object this$correlationId = this.getCorrelationId();
                    Object other$correlationId = other.getCorrelationId();
                    if (this$correlationId == null) {
                        if (other$correlationId == null) {
                            break label1122;
                        }
                    } else if (this$correlationId.equals(other$correlationId)) {
                        break label1122;
                    }

                    return false;
                }

                Object this$msName = this.getMsName();
                Object other$msName = other.getMsName();
                if (this$msName == null) {
                    if (other$msName != null) {
                        return false;
                    }
                } else if (!this$msName.equals(other$msName)) {
                    return false;
                }

                Object this$appName = this.getAppName();
                Object other$appName = other.getAppName();
                if (this$appName == null) {
                    if (other$appName != null) {
                        return false;
                    }
                } else if (!this$appName.equals(other$appName)) {
                    return false;
                }

                label1101: {
                    Object this$eventType = this.getEventType();
                    Object other$eventType = other.getEventType();
                    if (this$eventType == null) {
                        if (other$eventType == null) {
                            break label1101;
                        }
                    } else if (this$eventType.equals(other$eventType)) {
                        break label1101;
                    }

                    return false;
                }

                Object this$logType = this.getLogType();
                Object other$logType = other.getLogType();
                if (this$logType == null) {
                    if (other$logType != null) {
                        return false;
                    }
                } else if (!this$logType.equals(other$logType)) {
                    return false;
                }

                Object this$statusMessage = this.getStatusMessage();
                Object other$statusMessage = other.getStatusMessage();
                if (this$statusMessage == null) {
                    if (other$statusMessage != null) {
                        return false;
                    }
                } else if (!this$statusMessage.equals(other$statusMessage)) {
                    return false;
                }

                label1080: {
                    Object this$apiStatusMsg = this.getApiStatusMsg();
                    Object other$apiStatusMsg = other.getApiStatusMsg();
                    if (this$apiStatusMsg == null) {
                        if (other$apiStatusMsg == null) {
                            break label1080;
                        }
                    } else if (this$apiStatusMsg.equals(other$apiStatusMsg)) {
                        break label1080;
                    }

                    return false;
                }

                label1073: {
                    Object this$request = this.getRequest();
                    Object other$request = other.getRequest();
                    if (this$request == null) {
                        if (other$request == null) {
                            break label1073;
                        }
                    } else if (this$request.equals(other$request)) {
                        break label1073;
                    }

                    return false;
                }

                Object this$response = this.getResponse();
                Object other$response = other.getResponse();
                if (this$response == null) {
                    if (other$response != null) {
                        return false;
                    }
                } else if (!this$response.equals(other$response)) {
                    return false;
                }

                Object this$apiRequest = this.getApiRequest();
                Object other$apiRequest = other.getApiRequest();
                if (this$apiRequest == null) {
                    if (other$apiRequest != null) {
                        return false;
                    }
                } else if (!this$apiRequest.equals(other$apiRequest)) {
                    return false;
                }

                label1052: {
                    Object this$apiResponse = this.getApiResponse();
                    Object other$apiResponse = other.getApiResponse();
                    if (this$apiResponse == null) {
                        if (other$apiResponse == null) {
                            break label1052;
                        }
                    } else if (this$apiResponse.equals(other$apiResponse)) {
                        break label1052;
                    }

                    return false;
                }

                Object this$requestHeaders = this.getRequestHeaders();
                Object other$requestHeaders = other.getRequestHeaders();
                if (this$requestHeaders == null) {
                    if (other$requestHeaders != null) {
                        return false;
                    }
                } else if (!this$requestHeaders.equals(other$requestHeaders)) {
                    return false;
                }

                Object this$responseHeaders = this.getResponseHeaders();
                Object other$responseHeaders = other.getResponseHeaders();
                if (this$responseHeaders == null) {
                    if (other$responseHeaders != null) {
                        return false;
                    }
                } else if (!this$responseHeaders.equals(other$responseHeaders)) {
                    return false;
                }

                label1031: {
                    Object this$apiUrl = this.getApiUrl();
                    Object other$apiUrl = other.getApiUrl();
                    if (this$apiUrl == null) {
                        if (other$apiUrl == null) {
                            break label1031;
                        }
                    } else if (this$apiUrl.equals(other$apiUrl)) {
                        break label1031;
                    }

                    return false;
                }

                Object this$requestUri = this.getRequestUri();
                Object other$requestUri = other.getRequestUri();
                if (this$requestUri == null) {
                    if (other$requestUri != null) {
                        return false;
                    }
                } else if (!this$requestUri.equals(other$requestUri)) {
                    return false;
                }

                label1017: {
                    Object this$vsadId = this.getVsadId();
                    Object other$vsadId = other.getVsadId();
                    if (this$vsadId == null) {
                        if (other$vsadId == null) {
                            break label1017;
                        }
                    } else if (this$vsadId.equals(other$vsadId)) {
                        break label1017;
                    }

                    return false;
                }

                Object this$projectApplicationVSAD = this.getProjectApplicationVSAD();
                Object other$projectApplicationVSAD = other.getProjectApplicationVSAD();
                if (this$projectApplicationVSAD == null) {
                    if (other$projectApplicationVSAD != null) {
                        return false;
                    }
                } else if (!this$projectApplicationVSAD.equals(other$projectApplicationVSAD)) {
                    return false;
                }

                Object this$type = this.getType();
                Object other$type = other.getType();
                if (this$type == null) {
                    if (other$type != null) {
                        return false;
                    }
                } else if (!this$type.equals(other$type)) {
                    return false;
                }

                Object this$appGroup = this.getAppGroup();
                Object other$appGroup = other.getAppGroup();
                if (this$appGroup == null) {
                    if (other$appGroup != null) {
                        return false;
                    }
                } else if (!this$appGroup.equals(other$appGroup)) {
                    return false;
                }

                label989: {
                    Object this$apiName = this.getApiName();
                    Object other$apiName = other.getApiName();
                    if (this$apiName == null) {
                        if (other$apiName == null) {
                            break label989;
                        }
                    } else if (this$apiName.equals(other$apiName)) {
                        break label989;
                    }

                    return false;
                }

                Object this$logTimeStamp = this.getLogTimeStamp();
                Object other$logTimeStamp = other.getLogTimeStamp();
                if (this$logTimeStamp == null) {
                    if (other$logTimeStamp != null) {
                        return false;
                    }
                } else if (!this$logTimeStamp.equals(other$logTimeStamp)) {
                    return false;
                }

                Object this$functionPath = this.getFunctionPath();
                Object other$functionPath = other.getFunctionPath();
                if (this$functionPath == null) {
                    if (other$functionPath != null) {
                        return false;
                    }
                } else if (!this$functionPath.equals(other$functionPath)) {
                    return false;
                }

                label968: {
                    Object this$errorMessage = this.getErrorMessage();
                    Object other$errorMessage = other.getErrorMessage();
                    if (this$errorMessage == null) {
                        if (other$errorMessage == null) {
                            break label968;
                        }
                    } else if (this$errorMessage.equals(other$errorMessage)) {
                        break label968;
                    }

                    return false;
                }

                label961: {
                    Object this$resultStatus = this.getResultStatus();
                    Object other$resultStatus = other.getResultStatus();
                    if (this$resultStatus == null) {
                        if (other$resultStatus == null) {
                            break label961;
                        }
                    } else if (this$resultStatus.equals(other$resultStatus)) {
                        break label961;
                    }

                    return false;
                }

                label954: {
                    Object this$httpVerb = this.getHttpVerb();
                    Object other$httpVerb = other.getHttpVerb();
                    if (this$httpVerb == null) {
                        if (other$httpVerb == null) {
                            break label954;
                        }
                    } else if (this$httpVerb.equals(other$httpVerb)) {
                        break label954;
                    }

                    return false;
                }

                Object this$httpMethod = this.getHttpMethod();
                Object other$httpMethod = other.getHttpMethod();
                if (this$httpMethod == null) {
                    if (other$httpMethod != null) {
                        return false;
                    }
                } else if (!this$httpMethod.equals(other$httpMethod)) {
                    return false;
                }

                label940: {
                    Object this$cxpCorrelationId = this.getCxpCorrelationId();
                    Object other$cxpCorrelationId = other.getCxpCorrelationId();
                    if (this$cxpCorrelationId == null) {
                        if (other$cxpCorrelationId == null) {
                            break label940;
                        }
                    } else if (this$cxpCorrelationId.equals(other$cxpCorrelationId)) {
                        break label940;
                    }

                    return false;
                }

                Object this$custIdNo = this.getCustIdNo();
                Object other$custIdNo = other.getCustIdNo();
                if (this$custIdNo == null) {
                    if (other$custIdNo != null) {
                        return false;
                    }
                } else if (!this$custIdNo.equals(other$custIdNo)) {
                    return false;
                }

                label926: {
                    Object this$custId = this.getCustId();
                    Object other$custId = other.getCustId();
                    if (this$custId == null) {
                        if (other$custId == null) {
                            break label926;
                        }
                    } else if (this$custId.equals(other$custId)) {
                        break label926;
                    }

                    return false;
                }

                label919: {
                    Object this$acctNo = this.getAcctNo();
                    Object other$acctNo = other.getAcctNo();
                    if (this$acctNo == null) {
                        if (other$acctNo == null) {
                            break label919;
                        }
                    } else if (this$acctNo.equals(other$acctNo)) {
                        break label919;
                    }

                    return false;
                }

                Object this$mtn = this.getMtn();
                Object other$mtn = other.getMtn();
                if (this$mtn == null) {
                    if (other$mtn != null) {
                        return false;
                    }
                } else if (!this$mtn.equals(other$mtn)) {
                    return false;
                }

                label905: {
                    Object this$externalSystem = this.getExternalSystem();
                    Object other$externalSystem = other.getExternalSystem();
                    if (this$externalSystem == null) {
                        if (other$externalSystem == null) {
                            break label905;
                        }
                    } else if (this$externalSystem.equals(other$externalSystem)) {
                        break label905;
                    }

                    return false;
                }

                label898: {
                    Object this$externalRequestId = this.getExternalRequestId();
                    Object other$externalRequestId = other.getExternalRequestId();
                    if (this$externalRequestId == null) {
                        if (other$externalRequestId == null) {
                            break label898;
                        }
                    } else if (this$externalRequestId.equals(other$externalRequestId)) {
                        break label898;
                    }

                    return false;
                }

                Object this$functionName = this.getFunctionName();
                Object other$functionName = other.getFunctionName();
                if (this$functionName == null) {
                    if (other$functionName != null) {
                        return false;
                    }
                } else if (!this$functionName.equals(other$functionName)) {
                    return false;
                }

                Object this$clientId = this.getClientId();
                Object other$clientId = other.getClientId();
                if (this$clientId == null) {
                    if (other$clientId != null) {
                        return false;
                    }
                } else if (!this$clientId.equals(other$clientId)) {
                    return false;
                }

                label877: {
                    Object this$status = this.getStatus();
                    Object other$status = other.getStatus();
                    if (this$status == null) {
                        if (other$status == null) {
                            break label877;
                        }
                    } else if (this$status.equals(other$status)) {
                        break label877;
                    }

                    return false;
                }

                label870: {
                    Object this$dvsCorrelationId = this.getDvsCorrelationId();
                    Object other$dvsCorrelationId = other.getDvsCorrelationId();
                    if (this$dvsCorrelationId == null) {
                        if (other$dvsCorrelationId == null) {
                            break label870;
                        }
                    } else if (this$dvsCorrelationId.equals(other$dvsCorrelationId)) {
                        break label870;
                    }

                    return false;
                }

                Object this$cartId = this.getCartId();
                Object other$cartId = other.getCartId();
                if (this$cartId == null) {
                    if (other$cartId != null) {
                        return false;
                    }
                } else if (!this$cartId.equals(other$cartId)) {
                    return false;
                }

                label856: {
                    Object this$loggedInUserId = this.getLoggedInUserId();
                    Object other$loggedInUserId = other.getLoggedInUserId();
                    if (this$loggedInUserId == null) {
                        if (other$loggedInUserId == null) {
                            break label856;
                        }
                    } else if (this$loggedInUserId.equals(other$loggedInUserId)) {
                        break label856;
                    }

                    return false;
                }

                label849: {
                    Object this$userId = this.getUserId();
                    Object other$userId = other.getUserId();
                    if (this$userId == null) {
                        if (other$userId == null) {
                            break label849;
                        }
                    } else if (this$userId.equals(other$userId)) {
                        break label849;
                    }

                    return false;
                }

                Object this$logLevel = this.getLogLevel();
                Object other$logLevel = other.getLogLevel();
                if (this$logLevel == null) {
                    if (other$logLevel != null) {
                        return false;
                    }
                } else if (!this$logLevel.equals(other$logLevel)) {
                    return false;
                }

                Object this$level = this.getLevel();
                Object other$level = other.getLevel();
                if (this$level == null) {
                    if (other$level != null) {
                        return false;
                    }
                } else if (!this$level.equals(other$level)) {
                    return false;
                }

                label828: {
                    Object this$extraInfo = this.getExtraInfo();
                    Object other$extraInfo = other.getExtraInfo();
                    if (this$extraInfo == null) {
                        if (other$extraInfo == null) {
                            break label828;
                        }
                    } else if (this$extraInfo.equals(other$extraInfo)) {
                        break label828;
                    }

                    return false;
                }

                Object this$errorKey = this.getErrorKey();
                Object other$errorKey = other.getErrorKey();
                if (this$errorKey == null) {
                    if (other$errorKey != null) {
                        return false;
                    }
                } else if (!this$errorKey.equals(other$errorKey)) {
                    return false;
                }

                Object this$msg = this.getMsg();
                Object other$msg = other.getMsg();
                if (this$msg == null) {
                    if (other$msg != null) {
                        return false;
                    }
                } else if (!this$msg.equals(other$msg)) {
                    return false;
                }

                label807: {
                    Object this$application = this.getApplication();
                    Object other$application = other.getApplication();
                    if (this$application == null) {
                        if (other$application == null) {
                            break label807;
                        }
                    } else if (this$application.equals(other$application)) {
                        break label807;
                    }

                    return false;
                }

                Object this$domainCorrelationId = this.getDomainCorrelationId();
                Object other$domainCorrelationId = other.getDomainCorrelationId();
                if (this$domainCorrelationId == null) {
                    if (other$domainCorrelationId != null) {
                        return false;
                    }
                } else if (!this$domainCorrelationId.equals(other$domainCorrelationId)) {
                    return false;
                }

                label793: {
                    Object this$responseStatusCode = this.getResponseStatusCode();
                    Object other$responseStatusCode = other.getResponseStatusCode();
                    if (this$responseStatusCode == null) {
                        if (other$responseStatusCode == null) {
                            break label793;
                        }
                    } else if (this$responseStatusCode.equals(other$responseStatusCode)) {
                        break label793;
                    }

                    return false;
                }

                label786: {
                    Object this$responseStatusMessage = this.getResponseStatusMessage();
                    Object other$responseStatusMessage = other.getResponseStatusMessage();
                    if (this$responseStatusMessage == null) {
                        if (other$responseStatusMessage == null) {
                            break label786;
                        }
                    } else if (this$responseStatusMessage.equals(other$responseStatusMessage)) {
                        break label786;
                    }

                    return false;
                }

                Object this$responseStatusDetailedMessage = this.getResponseStatusDetailedMessage();
                Object other$responseStatusDetailedMessage = other.getResponseStatusDetailedMessage();
                if (this$responseStatusDetailedMessage == null) {
                    if (other$responseStatusDetailedMessage != null) {
                        return false;
                    }
                } else if (!this$responseStatusDetailedMessage.equals(other$responseStatusDetailedMessage)) {
                    return false;
                }

                Object this$externalApiUrl = this.getExternalApiUrl();
                Object other$externalApiUrl = other.getExternalApiUrl();
                if (this$externalApiUrl == null) {
                    if (other$externalApiUrl != null) {
                        return false;
                    }
                } else if (!this$externalApiUrl.equals(other$externalApiUrl)) {
                    return false;
                }

                label765: {
                    Object this$requestPath = this.getRequestPath();
                    Object other$requestPath = other.getRequestPath();
                    if (this$requestPath == null) {
                        if (other$requestPath == null) {
                            break label765;
                        }
                    } else if (this$requestPath.equals(other$requestPath)) {
                        break label765;
                    }

                    return false;
                }

                Object this$queryParams = this.getQueryParams();
                Object other$queryParams = other.getQueryParams();
                if (this$queryParams == null) {
                    if (other$queryParams != null) {
                        return false;
                    }
                } else if (!this$queryParams.equals(other$queryParams)) {
                    return false;
                }

                Object this$routeType = this.getRouteType();
                Object other$routeType = other.getRouteType();
                if (this$routeType == null) {
                    if (other$routeType != null) {
                        return false;
                    }
                } else if (!this$routeType.equals(other$routeType)) {
                    return false;
                }

                label744: {
                    Object this$externalCorrelationId = this.getExternalCorrelationId();
                    Object other$externalCorrelationId = other.getExternalCorrelationId();
                    if (this$externalCorrelationId == null) {
                        if (other$externalCorrelationId == null) {
                            break label744;
                        }
                    } else if (this$externalCorrelationId.equals(other$externalCorrelationId)) {
                        break label744;
                    }

                    return false;
                }

                label737: {
                    Object this$sessionId = this.getSessionId();
                    Object other$sessionId = other.getSessionId();
                    if (this$sessionId == null) {
                        if (other$sessionId == null) {
                            break label737;
                        }
                    } else if (this$sessionId.equals(other$sessionId)) {
                        break label737;
                    }

                    return false;
                }

                Object this$ssoSessionId = this.getSsoSessionId();
                Object other$ssoSessionId = other.getSsoSessionId();
                if (this$ssoSessionId == null) {
                    if (other$ssoSessionId != null) {
                        return false;
                    }
                } else if (!this$ssoSessionId.equals(other$ssoSessionId)) {
                    return false;
                }

                Object this$appSessionId = this.getAppSessionId();
                Object other$appSessionId = other.getAppSessionId();
                if (this$appSessionId == null) {
                    if (other$appSessionId != null) {
                        return false;
                    }
                } else if (!this$appSessionId.equals(other$appSessionId)) {
                    return false;
                }

                label716: {
                    Object this$inputFields = this.getInputFields();
                    Object other$inputFields = other.getInputFields();
                    if (this$inputFields == null) {
                        if (other$inputFields == null) {
                            break label716;
                        }
                    } else if (this$inputFields.equals(other$inputFields)) {
                        break label716;
                    }

                    return false;
                }

                Object this$inputValues = this.getInputValues();
                Object other$inputValues = other.getInputValues();
                if (this$inputValues == null) {
                    if (other$inputValues != null) {
                        return false;
                    }
                } else if (!this$inputValues.equals(other$inputValues)) {
                    return false;
                }

                Object this$system = this.getSystem();
                Object other$system = other.getSystem();
                if (this$system == null) {
                    if (other$system != null) {
                        return false;
                    }
                } else if (!this$system.equals(other$system)) {
                    return false;
                }

                label695: {
                    Object this$hostName = this.getHostName();
                    Object other$hostName = other.getHostName();
                    if (this$hostName == null) {
                        if (other$hostName == null) {
                            break label695;
                        }
                    } else if (this$hostName.equals(other$hostName)) {
                        break label695;
                    }

                    return false;
                }

                Object this$trueIp = this.getTrueIp();
                Object other$trueIp = other.getTrueIp();
                if (this$trueIp == null) {
                    if (other$trueIp != null) {
                        return false;
                    }
                } else if (!this$trueIp.equals(other$trueIp)) {
                    return false;
                }

                label681: {
                    Object this$userAgent = this.getUserAgent();
                    Object other$userAgent = other.getUserAgent();
                    if (this$userAgent == null) {
                        if (other$userAgent == null) {
                            break label681;
                        }
                    } else if (this$userAgent.equals(other$userAgent)) {
                        break label681;
                    }

                    return false;
                }

                Object this$userDevice = this.getUserDevice();
                Object other$userDevice = other.getUserDevice();
                if (this$userDevice == null) {
                    if (other$userDevice != null) {
                        return false;
                    }
                } else if (!this$userDevice.equals(other$userDevice)) {
                    return false;
                }

                Object this$loggerClass = this.getLoggerClass();
                Object other$loggerClass = other.getLoggerClass();
                if (this$loggerClass == null) {
                    if (other$loggerClass != null) {
                        return false;
                    }
                } else if (!this$loggerClass.equals(other$loggerClass)) {
                    return false;
                }

                Object this$pageName = this.getPageName();
                Object other$pageName = other.getPageName();
                if (this$pageName == null) {
                    if (other$pageName != null) {
                        return false;
                    }
                } else if (!this$pageName.equals(other$pageName)) {
                    return false;
                }

                label653: {
                    Object this$browserThumbprint = this.getBrowserThumbprint();
                    Object other$browserThumbprint = other.getBrowserThumbprint();
                    if (this$browserThumbprint == null) {
                        if (other$browserThumbprint == null) {
                            break label653;
                        }
                    } else if (this$browserThumbprint.equals(other$browserThumbprint)) {
                        break label653;
                    }

                    return false;
                }

                label646: {
                    Object this$viewPortX = this.getViewPortX();
                    Object other$viewPortX = other.getViewPortX();
                    if (this$viewPortX == null) {
                        if (other$viewPortX == null) {
                            break label646;
                        }
                    } else if (this$viewPortX.equals(other$viewPortX)) {
                        break label646;
                    }

                    return false;
                }

                Object this$viewPortY = this.getViewPortY();
                Object other$viewPortY = other.getViewPortY();
                if (this$viewPortY == null) {
                    if (other$viewPortY != null) {
                        return false;
                    }
                } else if (!this$viewPortY.equals(other$viewPortY)) {
                    return false;
                }

                label632: {
                    Object this$clickedElement = this.getClickedElement();
                    Object other$clickedElement = other.getClickedElement();
                    if (this$clickedElement == null) {
                        if (other$clickedElement == null) {
                            break label632;
                        }
                    } else if (this$clickedElement.equals(other$clickedElement)) {
                        break label632;
                    }

                    return false;
                }

                label625: {
                    Object this$clickX = this.getClickX();
                    Object other$clickX = other.getClickX();
                    if (this$clickX == null) {
                        if (other$clickX == null) {
                            break label625;
                        }
                    } else if (this$clickX.equals(other$clickX)) {
                        break label625;
                    }

                    return false;
                }

                label618: {
                    Object this$clickY = this.getClickY();
                    Object other$clickY = other.getClickY();
                    if (this$clickY == null) {
                        if (other$clickY == null) {
                            break label618;
                        }
                    } else if (this$clickY.equals(other$clickY)) {
                        break label618;
                    }

                    return false;
                }

                Object this$customerType = this.getCustomerType();
                Object other$customerType = other.getCustomerType();
                if (this$customerType == null) {
                    if (other$customerType != null) {
                        return false;
                    }
                } else if (!this$customerType.equals(other$customerType)) {
                    return false;
                }

                label604: {
                    Object this$pageReferrer = this.getPageReferrer();
                    Object other$pageReferrer = other.getPageReferrer();
                    if (this$pageReferrer == null) {
                        if (other$pageReferrer == null) {
                            break label604;
                        }
                    } else if (this$pageReferrer.equals(other$pageReferrer)) {
                        break label604;
                    }

                    return false;
                }

                Object this$serverHost = this.getServerHost();
                Object other$serverHost = other.getServerHost();
                if (this$serverHost == null) {
                    if (other$serverHost != null) {
                        return false;
                    }
                } else if (!this$serverHost.equals(other$serverHost)) {
                    return false;
                }

                Object this$appFlow = this.getAppFlow();
                Object other$appFlow = other.getAppFlow();
                if (this$appFlow == null) {
                    if (other$appFlow != null) {
                        return false;
                    }
                } else if (!this$appFlow.equals(other$appFlow)) {
                    return false;
                }

                label583: {
                    Object this$appType = this.getAppType();
                    Object other$appType = other.getAppType();
                    if (this$appType == null) {
                        if (other$appType == null) {
                            break label583;
                        }
                    } else if (this$appType.equals(other$appType)) {
                        break label583;
                    }

                    return false;
                }

                Object this$appEnvironment = this.getAppEnvironment();
                Object other$appEnvironment = other.getAppEnvironment();
                if (this$appEnvironment == null) {
                    if (other$appEnvironment != null) {
                        return false;
                    }
                } else if (!this$appEnvironment.equals(other$appEnvironment)) {
                    return false;
                }

                label569: {
                    Object this$journeyEntryPoint = this.getJourneyEntryPoint();
                    Object other$journeyEntryPoint = other.getJourneyEntryPoint();
                    if (this$journeyEntryPoint == null) {
                        if (other$journeyEntryPoint == null) {
                            break label569;
                        }
                    } else if (this$journeyEntryPoint.equals(other$journeyEntryPoint)) {
                        break label569;
                    }

                    return false;
                }

                Object this$typeAlias = this.getTypeAlias();
                Object other$typeAlias = other.getTypeAlias();
                if (this$typeAlias == null) {
                    if (other$typeAlias != null) {
                        return false;
                    }
                } else if (!this$typeAlias.equals(other$typeAlias)) {
                    return false;
                }

                Object this$isValuedTransaction = this.getIsValuedTransaction();
                Object other$isValuedTransaction = other.getIsValuedTransaction();
                if (this$isValuedTransaction == null) {
                    if (other$isValuedTransaction != null) {
                        return false;
                    }
                } else if (!this$isValuedTransaction.equals(other$isValuedTransaction)) {
                    return false;
                }

                Object this$isAccountInfoView = this.getIsAccountInfoView();
                Object other$isAccountInfoView = other.getIsAccountInfoView();
                if (this$isAccountInfoView == null) {
                    if (other$isAccountInfoView != null) {
                        return false;
                    }
                } else if (!this$isAccountInfoView.equals(other$isAccountInfoView)) {
                    return false;
                }

                label541: {
                    Object this$accountInfoViewType = this.getAccountInfoViewType();
                    Object other$accountInfoViewType = other.getAccountInfoViewType();
                    if (this$accountInfoViewType == null) {
                        if (other$accountInfoViewType == null) {
                            break label541;
                        }
                    } else if (this$accountInfoViewType.equals(other$accountInfoViewType)) {
                        break label541;
                    }

                    return false;
                }

                label534: {
                    Object this$isAccountInfoChange = this.getIsAccountInfoChange();
                    Object other$isAccountInfoChange = other.getIsAccountInfoChange();
                    if (this$isAccountInfoChange == null) {
                        if (other$isAccountInfoChange == null) {
                            break label534;
                        }
                    } else if (this$isAccountInfoChange.equals(other$isAccountInfoChange)) {
                        break label534;
                    }

                    return false;
                }

                Object this$accountInfoChangeType = this.getAccountInfoChangeType();
                Object other$accountInfoChangeType = other.getAccountInfoChangeType();
                if (this$accountInfoChangeType == null) {
                    if (other$accountInfoChangeType != null) {
                        return false;
                    }
                } else if (!this$accountInfoChangeType.equals(other$accountInfoChangeType)) {
                    return false;
                }

                Object this$appLevelInfo = this.getAppLevelInfo();
                Object other$appLevelInfo = other.getAppLevelInfo();
                if (this$appLevelInfo == null) {
                    if (other$appLevelInfo != null) {
                        return false;
                    }
                } else if (!this$appLevelInfo.equals(other$appLevelInfo)) {
                    return false;
                }

                return true;
            }
        }
    }

    protected boolean canEqual(Object other) {
        return other instanceof Event;
    }

    public int hashCode() {
        //int PRIME = true;
        int result = 1;
        long $startTime = this.getStartTime();
        result = result * 59 + (int)($startTime >>> 32 ^ $startTime);
        long $endTime = this.getEndTime();
        result = result * 59 + (int)($endTime >>> 32 ^ $endTime);
        long $duration = this.getDuration();
        result = result * 59 + (int)($duration >>> 32 ^ $duration);
        result = result * 59 + (this.isLogPayload() ? 79 : 97);
        result = result * 59 + Float.floatToIntBits(this.getVersion());
        Object $statusCode = this.getStatusCode();
        result = result * 59 + ($statusCode == null ? 43 : $statusCode.hashCode());
        Object $apiStatusCode = this.getApiStatusCode();
        result = result * 59 + ($apiStatusCode == null ? 43 : $apiStatusCode.hashCode());
        Object $httpStatusCode = this.getHttpStatusCode();
        result = result * 59 + ($httpStatusCode == null ? 43 : $httpStatusCode.hashCode());
        Object $vastId = this.getVastId();
        result = result * 59 + ($vastId == null ? 43 : $vastId.hashCode());
        Object $errorCode = this.getErrorCode();
        result = result * 59 + ($errorCode == null ? 43 : $errorCode.hashCode());
        Object $responseSize = this.getResponseSize();
        result = result * 59 + ($responseSize == null ? 43 : $responseSize.hashCode());
        Object $requestSize = this.getRequestSize();
        result = result * 59 + ($requestSize == null ? 43 : $requestSize.hashCode());
        Object $appVersion = this.getAppVersion();
        result = result * 59 + ($appVersion == null ? 43 : $appVersion.hashCode());
        Object $serverPort = this.getServerPort();
        result = result * 59 + ($serverPort == null ? 43 : $serverPort.hashCode());
        Object $transactionValue = this.getTransactionValue();
        result = result * 59 + ($transactionValue == null ? 43 : $transactionValue.hashCode());
        Object $e2eRequestId = this.getE2eRequestId();
        result = result * 59 + ($e2eRequestId == null ? 43 : $e2eRequestId.hashCode());
        Object $correlationId = this.getCorrelationId();
        result = result * 59 + ($correlationId == null ? 43 : $correlationId.hashCode());
        Object $msName = this.getMsName();
        result = result * 59 + ($msName == null ? 43 : $msName.hashCode());
        Object $appName = this.getAppName();
        result = result * 59 + ($appName == null ? 43 : $appName.hashCode());
        Object $eventType = this.getEventType();
        result = result * 59 + ($eventType == null ? 43 : $eventType.hashCode());
        Object $logType = this.getLogType();
        result = result * 59 + ($logType == null ? 43 : $logType.hashCode());
        Object $statusMessage = this.getStatusMessage();
        result = result * 59 + ($statusMessage == null ? 43 : $statusMessage.hashCode());
        Object $apiStatusMsg = this.getApiStatusMsg();
        result = result * 59 + ($apiStatusMsg == null ? 43 : $apiStatusMsg.hashCode());
        Object $request = this.getRequest();
        result = result * 59 + ($request == null ? 43 : $request.hashCode());
        Object $response = this.getResponse();
        result = result * 59 + ($response == null ? 43 : $response.hashCode());
        Object $apiRequest = this.getApiRequest();
        result = result * 59 + ($apiRequest == null ? 43 : $apiRequest.hashCode());
        Object $apiResponse = this.getApiResponse();
        result = result * 59 + ($apiResponse == null ? 43 : $apiResponse.hashCode());
        Object $requestHeaders = this.getRequestHeaders();
        result = result * 59 + ($requestHeaders == null ? 43 : $requestHeaders.hashCode());
        Object $responseHeaders = this.getResponseHeaders();
        result = result * 59 + ($responseHeaders == null ? 43 : $responseHeaders.hashCode());
        Object $apiUrl = this.getApiUrl();
        result = result * 59 + ($apiUrl == null ? 43 : $apiUrl.hashCode());
        Object $requestUri = this.getRequestUri();
        result = result * 59 + ($requestUri == null ? 43 : $requestUri.hashCode());
        Object $vsadId = this.getVsadId();
        result = result * 59 + ($vsadId == null ? 43 : $vsadId.hashCode());
        Object $projectApplicationVSAD = this.getProjectApplicationVSAD();
        result = result * 59 + ($projectApplicationVSAD == null ? 43 : $projectApplicationVSAD.hashCode());
        Object $type = this.getType();
        result = result * 59 + ($type == null ? 43 : $type.hashCode());
        Object $appGroup = this.getAppGroup();
        result = result * 59 + ($appGroup == null ? 43 : $appGroup.hashCode());
        Object $apiName = this.getApiName();
        result = result * 59 + ($apiName == null ? 43 : $apiName.hashCode());
        Object $logTimeStamp = this.getLogTimeStamp();
        result = result * 59 + ($logTimeStamp == null ? 43 : $logTimeStamp.hashCode());
        Object $functionPath = this.getFunctionPath();
        result = result * 59 + ($functionPath == null ? 43 : $functionPath.hashCode());
        Object $errorMessage = this.getErrorMessage();
        result = result * 59 + ($errorMessage == null ? 43 : $errorMessage.hashCode());
        Object $resultStatus = this.getResultStatus();
        result = result * 59 + ($resultStatus == null ? 43 : $resultStatus.hashCode());
        Object $httpVerb = this.getHttpVerb();
        result = result * 59 + ($httpVerb == null ? 43 : $httpVerb.hashCode());
        Object $httpMethod = this.getHttpMethod();
        result = result * 59 + ($httpMethod == null ? 43 : $httpMethod.hashCode());
        Object $cxpCorrelationId = this.getCxpCorrelationId();
        result = result * 59 + ($cxpCorrelationId == null ? 43 : $cxpCorrelationId.hashCode());
        Object $custIdNo = this.getCustIdNo();
        result = result * 59 + ($custIdNo == null ? 43 : $custIdNo.hashCode());
        Object $custId = this.getCustId();
        result = result * 59 + ($custId == null ? 43 : $custId.hashCode());
        Object $acctNo = this.getAcctNo();
        result = result * 59 + ($acctNo == null ? 43 : $acctNo.hashCode());
        Object $mtn = this.getMtn();
        result = result * 59 + ($mtn == null ? 43 : $mtn.hashCode());
        Object $externalSystem = this.getExternalSystem();
        result = result * 59 + ($externalSystem == null ? 43 : $externalSystem.hashCode());
        Object $externalRequestId = this.getExternalRequestId();
        result = result * 59 + ($externalRequestId == null ? 43 : $externalRequestId.hashCode());
        Object $functionName = this.getFunctionName();
        result = result * 59 + ($functionName == null ? 43 : $functionName.hashCode());
        Object $clientId = this.getClientId();
        result = result * 59 + ($clientId == null ? 43 : $clientId.hashCode());
        Object $status = this.getStatus();
        result = result * 59 + ($status == null ? 43 : $status.hashCode());
        Object $dvsCorrelationId = this.getDvsCorrelationId();
        result = result * 59 + ($dvsCorrelationId == null ? 43 : $dvsCorrelationId.hashCode());
        Object $cartId = this.getCartId();
        result = result * 59 + ($cartId == null ? 43 : $cartId.hashCode());
        Object $loggedInUserId = this.getLoggedInUserId();
        result = result * 59 + ($loggedInUserId == null ? 43 : $loggedInUserId.hashCode());
        Object $userId = this.getUserId();
        result = result * 59 + ($userId == null ? 43 : $userId.hashCode());
        Object $logLevel = this.getLogLevel();
        result = result * 59 + ($logLevel == null ? 43 : $logLevel.hashCode());
        Object $level = this.getLevel();
        result = result * 59 + ($level == null ? 43 : $level.hashCode());
        Object $extraInfo = this.getExtraInfo();
        result = result * 59 + ($extraInfo == null ? 43 : $extraInfo.hashCode());
        Object $errorKey = this.getErrorKey();
        result = result * 59 + ($errorKey == null ? 43 : $errorKey.hashCode());
        Object $msg = this.getMsg();
        result = result * 59 + ($msg == null ? 43 : $msg.hashCode());
        Object $application = this.getApplication();
        result = result * 59 + ($application == null ? 43 : $application.hashCode());
        Object $domainCorrelationId = this.getDomainCorrelationId();
        result = result * 59 + ($domainCorrelationId == null ? 43 : $domainCorrelationId.hashCode());
        Object $responseStatusCode = this.getResponseStatusCode();
        result = result * 59 + ($responseStatusCode == null ? 43 : $responseStatusCode.hashCode());
        Object $responseStatusMessage = this.getResponseStatusMessage();
        result = result * 59 + ($responseStatusMessage == null ? 43 : $responseStatusMessage.hashCode());
        Object $responseStatusDetailedMessage = this.getResponseStatusDetailedMessage();
        result = result * 59 + ($responseStatusDetailedMessage == null ? 43 : $responseStatusDetailedMessage.hashCode());
        Object $externalApiUrl = this.getExternalApiUrl();
        result = result * 59 + ($externalApiUrl == null ? 43 : $externalApiUrl.hashCode());
        Object $requestPath = this.getRequestPath();
        result = result * 59 + ($requestPath == null ? 43 : $requestPath.hashCode());
        Object $queryParams = this.getQueryParams();
        result = result * 59 + ($queryParams == null ? 43 : $queryParams.hashCode());
        Object $routeType = this.getRouteType();
        result = result * 59 + ($routeType == null ? 43 : $routeType.hashCode());
        Object $externalCorrelationId = this.getExternalCorrelationId();
        result = result * 59 + ($externalCorrelationId == null ? 43 : $externalCorrelationId.hashCode());
        Object $sessionId = this.getSessionId();
        result = result * 59 + ($sessionId == null ? 43 : $sessionId.hashCode());
        Object $ssoSessionId = this.getSsoSessionId();
        result = result * 59 + ($ssoSessionId == null ? 43 : $ssoSessionId.hashCode());
        Object $appSessionId = this.getAppSessionId();
        result = result * 59 + ($appSessionId == null ? 43 : $appSessionId.hashCode());
        Object $inputFields = this.getInputFields();
        result = result * 59 + ($inputFields == null ? 43 : $inputFields.hashCode());
        Object $inputValues = this.getInputValues();
        result = result * 59 + ($inputValues == null ? 43 : $inputValues.hashCode());
        Object $system = this.getSystem();
        result = result * 59 + ($system == null ? 43 : $system.hashCode());
        Object $hostName = this.getHostName();
        result = result * 59 + ($hostName == null ? 43 : $hostName.hashCode());
        Object $trueIp = this.getTrueIp();
        result = result * 59 + ($trueIp == null ? 43 : $trueIp.hashCode());
        Object $userAgent = this.getUserAgent();
        result = result * 59 + ($userAgent == null ? 43 : $userAgent.hashCode());
        Object $userDevice = this.getUserDevice();
        result = result * 59 + ($userDevice == null ? 43 : $userDevice.hashCode());
        Object $loggerClass = this.getLoggerClass();
        result = result * 59 + ($loggerClass == null ? 43 : $loggerClass.hashCode());
        Object $pageName = this.getPageName();
        result = result * 59 + ($pageName == null ? 43 : $pageName.hashCode());
        Object $browserThumbprint = this.getBrowserThumbprint();
        result = result * 59 + ($browserThumbprint == null ? 43 : $browserThumbprint.hashCode());
        Object $viewPortX = this.getViewPortX();
        result = result * 59 + ($viewPortX == null ? 43 : $viewPortX.hashCode());
        Object $viewPortY = this.getViewPortY();
        result = result * 59 + ($viewPortY == null ? 43 : $viewPortY.hashCode());
        Object $clickedElement = this.getClickedElement();
        result = result * 59 + ($clickedElement == null ? 43 : $clickedElement.hashCode());
        Object $clickX = this.getClickX();
        result = result * 59 + ($clickX == null ? 43 : $clickX.hashCode());
        Object $clickY = this.getClickY();
        result = result * 59 + ($clickY == null ? 43 : $clickY.hashCode());
        Object $customerType = this.getCustomerType();
        result = result * 59 + ($customerType == null ? 43 : $customerType.hashCode());
        Object $pageReferrer = this.getPageReferrer();
        result = result * 59 + ($pageReferrer == null ? 43 : $pageReferrer.hashCode());
        Object $serverHost = this.getServerHost();
        result = result * 59 + ($serverHost == null ? 43 : $serverHost.hashCode());
        Object $appFlow = this.getAppFlow();
        result = result * 59 + ($appFlow == null ? 43 : $appFlow.hashCode());
        Object $appType = this.getAppType();
        result = result * 59 + ($appType == null ? 43 : $appType.hashCode());
        Object $appEnvironment = this.getAppEnvironment();
        result = result * 59 + ($appEnvironment == null ? 43 : $appEnvironment.hashCode());
        Object $journeyEntryPoint = this.getJourneyEntryPoint();
        result = result * 59 + ($journeyEntryPoint == null ? 43 : $journeyEntryPoint.hashCode());
        Object $typeAlias = this.getTypeAlias();
        result = result * 59 + ($typeAlias == null ? 43 : $typeAlias.hashCode());
        Object $isValuedTransaction = this.getIsValuedTransaction();
        result = result * 59 + ($isValuedTransaction == null ? 43 : $isValuedTransaction.hashCode());
        Object $isAccountInfoView = this.getIsAccountInfoView();
        result = result * 59 + ($isAccountInfoView == null ? 43 : $isAccountInfoView.hashCode());
        Object $accountInfoViewType = this.getAccountInfoViewType();
        result = result * 59 + ($accountInfoViewType == null ? 43 : $accountInfoViewType.hashCode());
        Object $isAccountInfoChange = this.getIsAccountInfoChange();
        result = result * 59 + ($isAccountInfoChange == null ? 43 : $isAccountInfoChange.hashCode());
        Object $accountInfoChangeType = this.getAccountInfoChangeType();
        result = result * 59 + ($accountInfoChangeType == null ? 43 : $accountInfoChangeType.hashCode());
        Object $appLevelInfo = this.getAppLevelInfo();
        result = result * 59 + ($appLevelInfo == null ? 43 : $appLevelInfo.hashCode());
        return result;
    }

    public String toString() {
        String var10000 = "Event(startTime=" + this.getStartTime() + ", endTime=" + this.getEndTime() + ", duration=" + this.getDuration() + ", e2eRequestId=" + this.getE2eRequestId() + ", correlationId=" + this.getCorrelationId() + ", msName=" + this.getMsName() + ", appName=" + this.getAppName() + ", eventType=" + this.getEventType() + ", logType=" + this.getLogType() + ", statusMessage=" + this.getStatusMessage() + ", apiStatusMsg=" + this.getApiStatusMsg() + ", statusCode=" + this.getStatusCode() + ", apiStatusCode=" + this.getApiStatusCode() + ", request=" + this.getRequest() + ", response=" + this.getResponse() + ", apiRequest=" + this.getApiRequest() + ", apiResponse=" + this.getApiResponse() + ", requestHeaders=" + this.getRequestHeaders() + ", responseHeaders=" + this.getResponseHeaders() + ", httpStatusCode=" + this.getHttpStatusCode() + ", apiUrl=" + this.getApiUrl() + ", requestUri=" + this.getRequestUri() + ", vsadId=" + this.getVsadId() + ", projectApplicationVSAD=" + this.getProjectApplicationVSAD() + ", type=" + this.getType() + ", appGroup=" + this.getAppGroup() + ", vastId=" + this.getVastId() + ", apiName=" + this.getApiName() + ", logTimeStamp=" + this.getLogTimeStamp() + ", functionPath=" + this.getFunctionPath() + ", errorMessage=" + this.getErrorMessage() + ", errorCode=" + this.getErrorCode() + ", resultStatus=" + this.getResultStatus() + ", responseSize=" + this.getResponseSize() + ", requestSize=" + this.getRequestSize() + ", httpVerb=" + this.getHttpVerb() + ", httpMethod=" + this.getHttpMethod() + ", cxpCorrelationId=" + this.getCxpCorrelationId() + ", custIdNo=" + this.getCustIdNo() + ", custId=" + this.getCustId() + ", acctNo=" + this.getAcctNo() + ", mtn=" + this.getMtn() + ", externalSystem=" + this.getExternalSystem() + ", externalRequestId=" + this.getExternalRequestId() + ", functionName=" + this.getFunctionName() + ", clientId=" + this.getClientId() + ", status=" + this.getStatus() + ", dvsCorrelationId=" + this.getDvsCorrelationId() + ", cartId=" + this.getCartId() + ", loggedInUserId=" + this.getLoggedInUserId() + ", userId=" + this.getUserId() + ", logLevel=" + this.getLogLevel() + ", level=" + this.getLevel() + ", extraInfo=" + this.getExtraInfo() + ", errorKey=" + this.getErrorKey() + ", msg=" + this.getMsg() + ", logPayload=" + this.isLogPayload() + ", application=" + this.getApplication() + ", domainCorrelationId=" + this.getDomainCorrelationId() + ", responseStatusCode=" + this.getResponseStatusCode() + ", responseStatusMessage=" + this.getResponseStatusMessage() + ", responseStatusDetailedMessage=" + this.getResponseStatusDetailedMessage() + ", externalApiUrl=" + this.getExternalApiUrl() + ", requestPath=" + this.getRequestPath() + ", queryParams=" + this.getQueryParams() + ", routeType=" + this.getRouteType() + ", externalCorrelationId=" + this.getExternalCorrelationId() + ", sessionId=" + this.getSessionId() + ", ssoSessionId=" + this.getSsoSessionId() + ", appSessionId=" + this.getAppSessionId() + ", inputFields=" + this.getInputFields() + ", inputValues=" + this.getInputValues() + ", system=" + this.getSystem() + ", hostName=" + this.getHostName() + ", version=" + this.getVersion() + ", appVersion=" + this.getAppVersion() + ", trueIp=" + this.getTrueIp() + ", userAgent=" + this.getUserAgent() + ", userDevice=" + this.getUserDevice() + ", loggerClass=" + this.getLoggerClass() + ", pageName=" + this.getPageName() + ", browserThumbprint=" + this.getBrowserThumbprint() + ", viewPortX=" + this.getViewPortX() + ", viewPortY=" + this.getViewPortY() + ", clickedElement=" + this.getClickedElement() + ", clickX=" + this.getClickX() + ", clickY=" + this.getClickY() + ", customerType=" + this.getCustomerType() + ", pageReferrer=" + this.getPageReferrer() + ", serverHost=" + this.getServerHost() + ", serverPort=" + this.getServerPort() + ", appFlow=" + this.getAppFlow() + ", appType=" + this.getAppType() + ", appEnvironment=" + this.getAppEnvironment() + ", journeyEntryPoint=" + this.getJourneyEntryPoint() + ", typeAlias=" + this.getTypeAlias() + ", isValuedTransaction=" + this.getIsValuedTransaction() + ", transactionValue=" + this.getTransactionValue();
        String var10001 = this.getIsAccountInfoView();
        return var10000 + ", isAccountInfoView=" + var10001 + ", accountInfoViewType=" + this.getAccountInfoViewType() + ", isAccountInfoChange=" + this.getIsAccountInfoChange() + ", accountInfoChangeType=" + this.getAccountInfoChangeType() + ", appLevelInfo=" + this.getAppLevelInfo() + ")";
    }

    public Event(long startTime, long endTime, long duration, String e2eRequestId, String correlationId, String msName, String appName, String eventType, String logType, String statusMessage, String apiStatusMsg, Integer statusCode, Integer apiStatusCode, String request, String response, String apiRequest, String apiResponse, String requestHeaders, String responseHeaders, Integer httpStatusCode, String apiUrl, String requestUri, String vsadId, String projectApplicationVSAD, String type, String appGroup, Integer vastId, String apiName, String logTimeStamp, String functionPath, String errorMessage, Integer errorCode, String resultStatus, Integer responseSize, Integer requestSize, String httpVerb, String httpMethod, String cxpCorrelationId, String custIdNo, String custId, String acctNo, String mtn, String externalSystem, String externalRequestId, String functionName, String clientId, String status, String dvsCorrelationId, String cartId, String loggedInUserId, String userId, String logLevel, String level, Map<String, Object> extraInfo, String errorKey, String msg, boolean logPayload, String application, String domainCorrelationId, String responseStatusCode, String responseStatusMessage, String responseStatusDetailedMessage, String externalApiUrl, String requestPath, String queryParams, String routeType, String externalCorrelationId, String sessionId, String ssoSessionId, String appSessionId, String inputFields, String inputValues, String system, String hostName, float version, Integer appVersion, String trueIp, String userAgent, String userDevice, String loggerClass, String pageName, String browserThumbprint, String viewPortX, String viewPortY, String clickedElement, String clickX, String clickY, String customerType, String pageReferrer, String serverHost, Integer serverPort, String appFlow, String appType, String appEnvironment, String journeyEntryPoint, String typeAlias, String isValuedTransaction, Integer transactionValue, String isAccountInfoView, String accountInfoViewType, String isAccountInfoChange, String accountInfoChangeType, String appLevelInfo) {
        this.startTime = startTime;
        this.endTime = endTime;
        this.duration = duration;
        this.e2eRequestId = e2eRequestId;
        this.correlationId = correlationId;
        this.msName = msName;
        this.appName = appName;
        this.eventType = eventType;
        this.logType = logType;
        this.statusMessage = statusMessage;
        this.apiStatusMsg = apiStatusMsg;
        this.statusCode = statusCode;
        this.apiStatusCode = apiStatusCode;
        this.request = request;
        this.response = response;
        this.apiRequest = apiRequest;
        this.apiResponse = apiResponse;
        this.requestHeaders = requestHeaders;
        this.responseHeaders = responseHeaders;
        this.httpStatusCode = httpStatusCode;
        this.apiUrl = apiUrl;
        this.requestUri = requestUri;
        this.vsadId = vsadId;
        this.projectApplicationVSAD = projectApplicationVSAD;
        this.type = type;
        this.appGroup = appGroup;
        this.vastId = vastId;
        this.apiName = apiName;
        this.logTimeStamp = logTimeStamp;
        this.functionPath = functionPath;
        this.errorMessage = errorMessage;
        this.errorCode = errorCode;
        this.resultStatus = resultStatus;
        this.responseSize = responseSize;
        this.requestSize = requestSize;
        this.httpVerb = httpVerb;
        this.httpMethod = httpMethod;
        this.cxpCorrelationId = cxpCorrelationId;
        this.custIdNo = custIdNo;
        this.custId = custId;
        this.acctNo = acctNo;
        this.mtn = mtn;
        this.externalSystem = externalSystem;
        this.externalRequestId = externalRequestId;
        this.functionName = functionName;
        this.clientId = clientId;
        this.status = status;
        this.dvsCorrelationId = dvsCorrelationId;
        this.cartId = cartId;
        this.loggedInUserId = loggedInUserId;
        this.userId = userId;
        this.logLevel = logLevel;
        this.level = level;
        this.extraInfo = extraInfo;
        this.errorKey = errorKey;
        this.msg = msg;
        this.logPayload = logPayload;
        this.application = application;
        this.domainCorrelationId = domainCorrelationId;
        this.responseStatusCode = responseStatusCode;
        this.responseStatusMessage = responseStatusMessage;
        this.responseStatusDetailedMessage = responseStatusDetailedMessage;
        this.externalApiUrl = externalApiUrl;
        this.requestPath = requestPath;
        this.queryParams = queryParams;
        this.routeType = routeType;
        this.externalCorrelationId = externalCorrelationId;
        this.sessionId = sessionId;
        this.ssoSessionId = ssoSessionId;
        this.appSessionId = appSessionId;
        this.inputFields = inputFields;
        this.inputValues = inputValues;
        this.system = system;
        this.hostName = hostName;
        this.version = version;
        this.appVersion = appVersion;
        this.trueIp = trueIp;
        this.userAgent = userAgent;
        this.userDevice = userDevice;
        this.loggerClass = loggerClass;
        this.pageName = pageName;
        this.browserThumbprint = browserThumbprint;
        this.viewPortX = viewPortX;
        this.viewPortY = viewPortY;
        this.clickedElement = clickedElement;
        this.clickX = clickX;
        this.clickY = clickY;
        this.customerType = customerType;
        this.pageReferrer = pageReferrer;
        this.serverHost = serverHost;
        this.serverPort = serverPort;
        this.appFlow = appFlow;
        this.appType = appType;
        this.appEnvironment = appEnvironment;
        this.journeyEntryPoint = journeyEntryPoint;
        this.typeAlias = typeAlias;
        this.isValuedTransaction = isValuedTransaction;
        this.transactionValue = transactionValue;
        this.isAccountInfoView = isAccountInfoView;
        this.accountInfoViewType = accountInfoViewType;
        this.isAccountInfoChange = isAccountInfoChange;
        this.accountInfoChangeType = accountInfoChangeType;
        this.appLevelInfo = appLevelInfo;
    }

    public Event() {
    }

    private static final class EventBuilderImpl extends EventBuilder<Event, EventBuilderImpl> {
        private EventBuilderImpl() {
        }

        protected EventBuilderImpl self() {
            return this;
        }

        public Event build() {
            return new Event(this);
        }
    }

    public abstract static class EventBuilder<C extends Event, B extends EventBuilder<C, B>> {
        private long startTime;
        private long endTime;
        private long duration;
        private String e2eRequestId;
        private String correlationId;
        private String msName;
        private String appName;
        private String eventType;
        private String logType;
        private String statusMessage;
        private String apiStatusMsg;
        private Integer statusCode;
        private Integer apiStatusCode;
        private String request;
        private String response;
        private String apiRequest;
        private String apiResponse;
        private String requestHeaders;
        private String responseHeaders;
        private Integer httpStatusCode;
        private String apiUrl;
        private String requestUri;
        private String vsadId;
        private String projectApplicationVSAD;
        private String type;
        private String appGroup;
        private Integer vastId;
        private String apiName;
        private String logTimeStamp;
        private String functionPath;
        private String errorMessage;
        private Integer errorCode;
        private String resultStatus;
        private Integer responseSize;
        private Integer requestSize;
        private String httpVerb;
        private String httpMethod;
        private String cxpCorrelationId;
        private String custIdNo;
        private String custId;
        private String acctNo;
        private String mtn;
        private String externalSystem;
        private String externalRequestId;
        private String functionName;
        private String clientId;
        private String status;
        private String dvsCorrelationId;
        private String cartId;
        private String loggedInUserId;
        private String userId;
        private String logLevel;
        private String level;
        private Map<String, Object> extraInfo;
        private String errorKey;
        private String msg;
        private boolean logPayload;
        private String application;
        private String domainCorrelationId;
        private String responseStatusCode;
        private String responseStatusMessage;
        private String responseStatusDetailedMessage;
        private String externalApiUrl;
        private String requestPath;
        private String queryParams;
        private String routeType;
        private String externalCorrelationId;
        private String sessionId;
        private String ssoSessionId;
        private String appSessionId;
        private String inputFields;
        private String inputValues;
        private String system;
        private String hostName;
        private float version;
        private Integer appVersion;
        private String trueIp;
        private String userAgent;
        private String userDevice;
        private String loggerClass;
        private String pageName;
        private String browserThumbprint;
        private String viewPortX;
        private String viewPortY;
        private String clickedElement;
        private String clickX;
        private String clickY;
        private String customerType;
        private String pageReferrer;
        private String serverHost;
        private Integer serverPort;
        private String appFlow;
        private String appType;
        private String appEnvironment;
        private String journeyEntryPoint;
        private String typeAlias;
        private String isValuedTransaction;
        private Integer transactionValue;
        private String isAccountInfoView;
        private String accountInfoViewType;
        private String isAccountInfoChange;
        private String accountInfoChangeType;
        private String appLevelInfo;

        public EventBuilder() {
        }

        protected abstract B self();

        public abstract C build();

        @JsonProperty("start_time")
        public B startTime(long startTime) {
            this.startTime = startTime;
            return this.self();
        }

        @JsonProperty("end_time")
        public B endTime(long endTime) {
            this.endTime = endTime;
            return this.self();
        }

        @JsonProperty("duration")
        public B duration(long duration) {
            this.duration = duration;
            return this.self();
        }

        @JsonProperty("e2erequestid")
        public B e2eRequestId(String e2eRequestId) {
            this.e2eRequestId = e2eRequestId;
            return this.self();
        }

        @JsonProperty("correlation_id")
        public B correlationId(String correlationId) {
            this.correlationId = correlationId;
            return this.self();
        }

        @JsonProperty("ms_name")
        public B msName(String msName) {
            this.msName = msName;
            return this.self();
        }

        @JsonProperty("app_name")
        public B appName(String appName) {
            this.appName = appName;
            return this.self();
        }

        @JsonProperty("event_type")
        public B eventType(String eventType) {
            this.eventType = eventType;
            return this.self();
        }

        @JsonProperty("log_type")
        public B logType(String logType) {
            this.logType = logType;
            return this.self();
        }

        @JsonProperty("status_message")
        public B statusMessage(String statusMessage) {
            this.statusMessage = statusMessage;
            return this.self();
        }

        @JsonProperty("api_status_msg")
        public B apiStatusMsg(String apiStatusMsg) {
            this.apiStatusMsg = apiStatusMsg;
            return this.self();
        }

        @JsonProperty("status_code")
        public B statusCode(Integer statusCode) {
            this.statusCode = statusCode;
            return this.self();
        }

        @JsonProperty("api_status_code")
        public B apiStatusCode(Integer apiStatusCode) {
            this.apiStatusCode = apiStatusCode;
            return this.self();
        }

        public B request(String request) {
            this.request = request;
            return this.self();
        }

        public B response(String response) {
            this.response = response;
            return this.self();
        }

        @JsonProperty("api_request")
        public B apiRequest(String apiRequest) {
            this.apiRequest = apiRequest;
            return this.self();
        }

        @JsonProperty("api_response")
        public B apiResponse(String apiResponse) {
            this.apiResponse = apiResponse;
            return this.self();
        }

        @JsonProperty("request_headers")
        public B requestHeaders(String requestHeaders) {
            this.requestHeaders = requestHeaders;
            return this.self();
        }

        @JsonProperty("response_headers")
        public B responseHeaders(String responseHeaders) {
            this.responseHeaders = responseHeaders;
            return this.self();
        }

        @JsonProperty("http_status_code")
        public B httpStatusCode(Integer httpStatusCode) {
            this.httpStatusCode = httpStatusCode;
            return this.self();
        }

        @JsonProperty("api_url")
        public B apiUrl(String apiUrl) {
            this.apiUrl = apiUrl;
            return this.self();
        }

        @JsonProperty("request_uri")
        public B requestUri(String requestUri) {
            this.requestUri = requestUri;
            return this.self();
        }

        @JsonProperty("VSAD_ID")
        public B vsadId(String vsadId) {
            this.vsadId = vsadId;
            return this.self();
        }

        @JsonProperty("project_application_vsad")
        public B projectApplicationVSAD(String projectApplicationVSAD) {
            this.projectApplicationVSAD = projectApplicationVSAD;
            return this.self();
        }

        @JsonProperty("type")
        public B type(String type) {
            this.type = type;
            return this.self();
        }

        @JsonProperty("app_group")
        public B appGroup(String appGroup) {
            this.appGroup = appGroup;
            return this.self();
        }

        @JsonProperty("vast_id")
        public B vastId(Integer vastId) {
            this.vastId = vastId;
            return this.self();
        }

        @JsonProperty("api_name")
        public B apiName(String apiName) {
            this.apiName = apiName;
            return this.self();
        }

        @JsonProperty("log_time_stamp")
        public B logTimeStamp(String logTimeStamp) {
            this.logTimeStamp = logTimeStamp;
            return this.self();
        }

        @JsonProperty("function_path")
        public B functionPath(String functionPath) {
            this.functionPath = functionPath;
            return this.self();
        }

        @JsonProperty("error_message")
        public B errorMessage(String errorMessage) {
            this.errorMessage = errorMessage;
            return this.self();
        }

        @JsonProperty("error_code")
        public B errorCode(Integer errorCode) {
            this.errorCode = errorCode;
            return this.self();
        }

        @JsonProperty("result_status")
        public B resultStatus(String resultStatus) {
            this.resultStatus = resultStatus;
            return this.self();
        }

        @JsonProperty("response_size")
        public B responseSize(Integer responseSize) {
            this.responseSize = responseSize;
            return this.self();
        }

        @JsonProperty("request_size")
        public B requestSize(Integer requestSize) {
            this.requestSize = requestSize;
            return this.self();
        }

        @JsonProperty("http_verb")
        public B httpVerb(String httpVerb) {
            this.httpVerb = httpVerb;
            return this.self();
        }

        @JsonProperty("http_method")
        public B httpMethod(String httpMethod) {
            this.httpMethod = httpMethod;
            return this.self();
        }

        @JsonProperty("cxp_correlation_id")
        public B cxpCorrelationId(String cxpCorrelationId) {
            this.cxpCorrelationId = cxpCorrelationId;
            return this.self();
        }

        @JsonProperty("cust_id_no")
        public B custIdNo(String custIdNo) {
            this.custIdNo = custIdNo;
            return this.self();
        }

        @JsonProperty("cust_id")
        public B custId(String custId) {
            this.custId = custId;
            return this.self();
        }

        @JsonProperty("acct_no")
        public B acctNo(String acctNo) {
            this.acctNo = acctNo;
            return this.self();
        }

        @JsonProperty("mtn")
        public B mtn(String mtn) {
            this.mtn = mtn;
            return this.self();
        }

        @JsonProperty("external_system")
        public B externalSystem(String externalSystem) {
            this.externalSystem = externalSystem;
            return this.self();
        }

        @JsonProperty("external_request_id")
        public B externalRequestId(String externalRequestId) {
            this.externalRequestId = externalRequestId;
            return this.self();
        }

        @JsonProperty("function_name")
        public B functionName(String functionName) {
            this.functionName = functionName;
            return this.self();
        }

        @JsonProperty("client_id")
        public B clientId(String clientId) {
            this.clientId = clientId;
            return this.self();
        }

        @JsonProperty("status")
        public B status(String status) {
            this.status = status;
            return this.self();
        }

        @JsonProperty("dvs_correlation_Id")
        public B dvsCorrelationId(String dvsCorrelationId) {
            this.dvsCorrelationId = dvsCorrelationId;
            return this.self();
        }

        @JsonProperty("cart_id")
        public B cartId(String cartId) {
            this.cartId = cartId;
            return this.self();
        }

        @JsonProperty("logged_in_user_id")
        public B loggedInUserId(String loggedInUserId) {
            this.loggedInUserId = loggedInUserId;
            return this.self();
        }

        @JsonProperty("user_id")
        public B userId(String userId) {
            this.userId = userId;
            return this.self();
        }

        @JsonProperty("log_level")
        public B logLevel(String logLevel) {
            this.logLevel = logLevel;
            return this.self();
        }

        @JsonProperty("level")
        public B level(String level) {
            this.level = level;
            return this.self();
        }

        @JsonIgnore
        public B extraInfo(Map<String, Object> extraInfo) {
            this.extraInfo = extraInfo;
            return this.self();
        }

        @JsonProperty("error_key")
        public B errorKey(String errorKey) {
            this.errorKey = errorKey;
            return this.self();
        }

        public B msg(String msg) {
            this.msg = msg;
            return this.self();
        }

        public B logPayload(boolean logPayload) {
            this.logPayload = logPayload;
            return this.self();
        }

        public B application(String application) {
            this.application = application;
            return this.self();
        }

        @JsonProperty("ds_correlation_id")
        public B domainCorrelationId(String domainCorrelationId) {
            this.domainCorrelationId = domainCorrelationId;
            return this.self();
        }

        @JsonProperty("response_status_code")
        public B responseStatusCode(String responseStatusCode) {
            this.responseStatusCode = responseStatusCode;
            return this.self();
        }

        @JsonProperty("response_status_message")
        public B responseStatusMessage(String responseStatusMessage) {
            this.responseStatusMessage = responseStatusMessage;
            return this.self();
        }

        @JsonProperty("response_status_detailed_message")
        public B responseStatusDetailedMessage(String responseStatusDetailedMessage) {
            this.responseStatusDetailedMessage = responseStatusDetailedMessage;
            return this.self();
        }

        @JsonProperty("external_api_url")
        public B externalApiUrl(String externalApiUrl) {
            this.externalApiUrl = externalApiUrl;
            return this.self();
        }

        @JsonProperty("request_path")
        public B requestPath(String requestPath) {
            this.requestPath = requestPath;
            return this.self();
        }

        @JsonProperty("query_params")
        public B queryParams(String queryParams) {
            this.queryParams = queryParams;
            return this.self();
        }

        @JsonProperty("route-type")
        public B routeType(String routeType) {
            this.routeType = routeType;
            return this.self();
        }

        @JsonProperty("external_correlation_id")
        public B externalCorrelationId(String externalCorrelationId) {
            this.externalCorrelationId = externalCorrelationId;
            return this.self();
        }

        @JsonProperty("session_id")
        public B sessionId(String sessionId) {
            this.sessionId = sessionId;
            return this.self();
        }

        @JsonProperty("sso_session_id")
        public B ssoSessionId(String ssoSessionId) {
            this.ssoSessionId = ssoSessionId;
            return this.self();
        }

        @JsonProperty("app_session_id")
        public B appSessionId(String appSessionId) {
            this.appSessionId = appSessionId;
            return this.self();
        }

        @JsonProperty("input_fields")
        public B inputFields(String inputFields) {
            this.inputFields = inputFields;
            return this.self();
        }

        @JsonProperty("input_values")
        public B inputValues(String inputValues) {
            this.inputValues = inputValues;
            return this.self();
        }

        @JsonProperty("system")
        public B system(String system) {
            this.system = system;
            return this.self();
        }

        @JsonProperty("host_name")
        public B hostName(String hostName) {
            this.hostName = hostName;
            return this.self();
        }

        @JsonProperty("version")
        public B version(float version) {
            this.version = version;
            return this.self();
        }

        @JsonProperty("app_version")
        public B appVersion(Integer appVersion) {
            this.appVersion = appVersion;
            return this.self();
        }

        @JsonProperty("true_ip")
        public B trueIp(String trueIp) {
            this.trueIp = trueIp;
            return this.self();
        }

        @JsonProperty("user_agent")
        public B userAgent(String userAgent) {
            this.userAgent = userAgent;
            return this.self();
        }

        @JsonProperty("user_device")
        public B userDevice(String userDevice) {
            this.userDevice = userDevice;
            return this.self();
        }

        @JsonProperty("logger_class")
        public B loggerClass(String loggerClass) {
            this.loggerClass = loggerClass;
            return this.self();
        }

        @JsonProperty("page_name")
        public B pageName(String pageName) {
            this.pageName = pageName;
            return this.self();
        }

        @JsonProperty("browser_thumbprint")
        public B browserThumbprint(String browserThumbprint) {
            this.browserThumbprint = browserThumbprint;
            return this.self();
        }

        @JsonProperty("view_port_x")
        public B viewPortX(String viewPortX) {
            this.viewPortX = viewPortX;
            return this.self();
        }

        @JsonProperty("view_port_y")
        public B viewPortY(String viewPortY) {
            this.viewPortY = viewPortY;
            return this.self();
        }

        @JsonProperty("clicked_element")
        public B clickedElement(String clickedElement) {
            this.clickedElement = clickedElement;
            return this.self();
        }

        @JsonProperty("click_x")
        public B clickX(String clickX) {
            this.clickX = clickX;
            return this.self();
        }

        @JsonProperty("click_y")
        public B clickY(String clickY) {
            this.clickY = clickY;
            return this.self();
        }

        @JsonProperty("customer_type")
        public B customerType(String customerType) {
            this.customerType = customerType;
            return this.self();
        }

        @JsonProperty("page_referrer")
        public B pageReferrer(String pageReferrer) {
            this.pageReferrer = pageReferrer;
            return this.self();
        }

        @JsonProperty("server_host")
        public B serverHost(String serverHost) {
            this.serverHost = serverHost;
            return this.self();
        }

        @JsonProperty("server_port")
        public B serverPort(Integer serverPort) {
            this.serverPort = serverPort;
            return this.self();
        }

        @JsonProperty("app_flow")
        public B appFlow(String appFlow) {
            this.appFlow = appFlow;
            return this.self();
        }

        @JsonProperty("app_type")
        public B appType(String appType) {
            this.appType = appType;
            return this.self();
        }

        @JsonProperty("app_environment")
        public B appEnvironment(String appEnvironment) {
            this.appEnvironment = appEnvironment;
            return this.self();
        }

        @JsonProperty("journey_entry_point")
        public B journeyEntryPoint(String journeyEntryPoint) {
            this.journeyEntryPoint = journeyEntryPoint;
            return this.self();
        }

        @JsonProperty("type_alias")
        public B typeAlias(String typeAlias) {
            this.typeAlias = typeAlias;
            return this.self();
        }

        @JsonProperty("is_valued_transaction")
        public B isValuedTransaction(String isValuedTransaction) {
            this.isValuedTransaction = isValuedTransaction;
            return this.self();
        }

        @JsonProperty("transaction_value")
        public B transactionValue(Integer transactionValue) {
            this.transactionValue = transactionValue;
            return this.self();
        }

        @JsonProperty("is_account_info_view")
        public B isAccountInfoView(String isAccountInfoView) {
            this.isAccountInfoView = isAccountInfoView;
            return this.self();
        }

        @JsonProperty("account_info_view_type")
        public B accountInfoViewType(String accountInfoViewType) {
            this.accountInfoViewType = accountInfoViewType;
            return this.self();
        }

        @JsonProperty("is_account_info_change")
        public B isAccountInfoChange(String isAccountInfoChange) {
            this.isAccountInfoChange = isAccountInfoChange;
            return this.self();
        }

        @JsonProperty("account_info_change_type")
        public B accountInfoChangeType(String accountInfoChangeType) {
            this.accountInfoChangeType = accountInfoChangeType;
            return this.self();
        }

        @JsonProperty("app_level_info")
        public B appLevelInfo(String appLevelInfo) {
            this.appLevelInfo = appLevelInfo;
            return this.self();
        }

        public String toString() {
            String var10000 = "Event.EventBuilder(startTime=" + this.startTime + ", endTime=" + this.endTime + ", duration=" + this.duration + ", e2eRequestId=" + this.e2eRequestId + ", correlationId=" + this.correlationId + ", msName=" + this.msName + ", appName=" + this.appName + ", eventType=" + this.eventType + ", logType=" + this.logType + ", statusMessage=" + this.statusMessage + ", apiStatusMsg=" + this.apiStatusMsg + ", statusCode=" + this.statusCode + ", apiStatusCode=" + this.apiStatusCode + ", request=" + this.request + ", response=" + this.response + ", apiRequest=" + this.apiRequest + ", apiResponse=" + this.apiResponse + ", requestHeaders=" + this.requestHeaders + ", responseHeaders=" + this.responseHeaders + ", httpStatusCode=" + this.httpStatusCode + ", apiUrl=" + this.apiUrl + ", requestUri=" + this.requestUri + ", vsadId=" + this.vsadId + ", projectApplicationVSAD=" + this.projectApplicationVSAD + ", type=" + this.type + ", appGroup=" + this.appGroup + ", vastId=" + this.vastId + ", apiName=" + this.apiName + ", logTimeStamp=" + this.logTimeStamp + ", functionPath=" + this.functionPath + ", errorMessage=" + this.errorMessage + ", errorCode=" + this.errorCode + ", resultStatus=" + this.resultStatus + ", responseSize=" + this.responseSize + ", requestSize=" + this.requestSize + ", httpVerb=" + this.httpVerb + ", httpMethod=" + this.httpMethod + ", cxpCorrelationId=" + this.cxpCorrelationId + ", custIdNo=" + this.custIdNo + ", custId=" + this.custId + ", acctNo=" + this.acctNo + ", mtn=" + this.mtn + ", externalSystem=" + this.externalSystem + ", externalRequestId=" + this.externalRequestId + ", functionName=" + this.functionName + ", clientId=" + this.clientId + ", status=" + this.status + ", dvsCorrelationId=" + this.dvsCorrelationId + ", cartId=" + this.cartId + ", loggedInUserId=" + this.loggedInUserId + ", userId=" + this.userId + ", logLevel=" + this.logLevel + ", level=" + this.level + ", extraInfo=" + this.extraInfo + ", errorKey=" + this.errorKey + ", msg=" + this.msg + ", logPayload=" + this.logPayload + ", application=" + this.application + ", domainCorrelationId=" + this.domainCorrelationId + ", responseStatusCode=" + this.responseStatusCode + ", responseStatusMessage=" + this.responseStatusMessage + ", responseStatusDetailedMessage=" + this.responseStatusDetailedMessage + ", externalApiUrl=" + this.externalApiUrl + ", requestPath=" + this.requestPath + ", queryParams=" + this.queryParams + ", routeType=" + this.routeType + ", externalCorrelationId=" + this.externalCorrelationId + ", sessionId=" + this.sessionId + ", ssoSessionId=" + this.ssoSessionId + ", appSessionId=" + this.appSessionId + ", inputFields=" + this.inputFields + ", inputValues=" + this.inputValues + ", system=" + this.system + ", hostName=" + this.hostName + ", version=" + this.version + ", appVersion=" + this.appVersion + ", trueIp=" + this.trueIp + ", userAgent=" + this.userAgent + ", userDevice=" + this.userDevice + ", loggerClass=" + this.loggerClass + ", pageName=" + this.pageName + ", browserThumbprint=" + this.browserThumbprint + ", viewPortX=" + this.viewPortX + ", viewPortY=" + this.viewPortY + ", clickedElement=" + this.clickedElement + ", clickX=" + this.clickX + ", clickY=" + this.clickY + ", customerType=" + this.customerType + ", pageReferrer=" + this.pageReferrer + ", serverHost=" + this.serverHost + ", serverPort=" + this.serverPort + ", appFlow=" + this.appFlow + ", appType=" + this.appType + ", appEnvironment=" + this.appEnvironment + ", journeyEntryPoint=" + this.journeyEntryPoint + ", typeAlias=" + this.typeAlias + ", isValuedTransaction=" + this.isValuedTransaction + ", transactionValue=" + this.transactionValue;
            return var10000 + ", isAccountInfoView=" + this.isAccountInfoView + ", accountInfoViewType=" + this.accountInfoViewType + ", isAccountInfoChange=" + this.isAccountInfoChange + ", accountInfoChangeType=" + this.accountInfoChangeType + ", appLevelInfo=" + this.appLevelInfo + ")";
        }
    }
}
