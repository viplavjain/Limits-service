package com.vzw.tools.common.util;

public interface IConstants {
    public final String DPI_SYSTEM = "DPI";
    public final String DMD_SYSTEM = "DMD";
    public final String SAP_SYSTEM = "SAP";
    public final String EPC_SYSTEM = "EPC";
    public final String CASSANDRA_SYSTEM = "Cassandra";
    public final String FEDERATE_DB_SYSTEM = "FederatedDB";
    public final String REDIS_SYSTEM = "Redis";
    public final String ELASTIC_SYSTEM = "ElasticSearch";
    public final String FUSION_SYSTEM = "Fusion";
    public final String CXPCATALOGDOMAIN_SYSTEM = "CXPCatalogDomain";
}
