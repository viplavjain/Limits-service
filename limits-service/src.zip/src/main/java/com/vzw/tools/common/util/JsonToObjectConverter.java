package com.vzw.tools.common.util;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.tools.common.exception.ConverterException;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.io.InputStream;

@Slf4j
public class JsonToObjectConverter {

    private JsonToObjectConverter() {
    }

    public static <T> T jsonToObject(String filePath, Class<T> clazz) throws ConverterException {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        try (InputStream inputStream = JsonToObjectConverter.class.getClassLoader()
                .getResourceAsStream(filePath)) {
            if (inputStream == null) {
                throw new IllegalArgumentException("File not found in resources");
            }
            return objectMapper.readValue(inputStream, clazz);
        } catch (IOException e) {
            log.error("Error parsing JSON file", e);
            // Consider throwing a more specific exception or handling the error differently
            throw new ConverterException("Error parsing JSON file", e);
        }
    }
}
