package com.vzw.tools.common.exception;

public class NoActionExceptionTranslator implements ExceptionTranslator {
    public NoActionExceptionTranslator() {
    }

    public FCToolsMSException translate(Throwable t) {
        return null;
    }

    public boolean canTranslate(Throwable t) {
        return false;
    }
}
