package com.vzw.tools.cache.constant;


public class RedisConstants {

    private RedisConstants() {
    }

    public static final String INVALID_MSG = "Invalid Asset or ID";

    public static final String DEVICE = "Device";

    public static final String ACCESSORY = "Accessory";

    public static final String DEVICE_CATALOG = "DeviceSkuCatalog";

    public static final String ACCESSORY_CATALOG = "AccessorySkuCatalog";

    public static final String SKU = "Sku";

    public static final String SAP_PRICE = "SapSkuPrices";

    public static final String DEVICE_PRODUCT_CATALOG = "DeviceProductCatalog";

    public static final String ACCESSORY_PRODUCT_CATALOG = "AccessoryProductCatalog";

    public static final String PRODUCT_ID_MAP = "productIdMap";

    public static final String POST_PAY_PRODUCT = "postPayProduct";

    public static final String PARENT_PRODUCT = "parentProducts";

    public static final String NO_DATA = "No Data Found";

    public static final String COLON = ":";

    public static final int ZERO = 0;

    public static final int ONE = 1;

    public static final int THIRTY_ONE = 31;

    public static final String PRIMARY_KEY_FORMAT = "spring.enum.%s.primarykey";

    public static final String SECONDARY_KEY_FORMAT = "spring.enum.%s.secondarykey";

    public static final String FETCH_DATA_FAILED = "Data fetch is failed";

    public static final boolean FALSE = false;

    public static final boolean TRUE = true;

    public static final String EPC_REDIS_PREFIX = "spring.redis.";

    public static final int DURATION = 360000;

    public static final int TIMEOUT = 60000;

    public static final int HUNDRED = 100;

    public static final String CLUSTER = ".cluster";

    public static final String PASSWORD = ".password";

    public static final String SSL = ".ssl";

    public static final String TRUE_VALUE = "true";

    public static final String PLAIN_PASSWORD = ".plainPassword";

    public static final String USE_PLAIN_PASSWORD = ".usePlainPassword";

    public static final String ENV = "ENV";

    public static final String REDIS = "redis-";

    public static final String MINUS = "-";

    public static final int FIFTY = 50;

    public static final int TWENTY = 20;

    public static final int FIVE = 5;

    public static final String STRING = "String";

    public static final String INTEGER = "Integer";

    public static final String DOUBLE = "Double";

    public static final String BOOLEAN = "Boolean";

    public static final String LONG = "Long";

    public static final String LIST = "List";

    public static final String DATA = "Data";

    public static final String RESPONSE = "Response";

    public static final String PRICE = "price";

    public static final String IMAGE_URL_MAP = "imageUrlMap";

}
