package com.vzw.tools.source.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class DeviceInfo {

    private String prodName;
    private String familyName;
    private String mfgCode;
    private String mfgName;
    private String prodType;
    private String dacc;
    private String imProdName;
    private String imImageUrl;
    private String imDeviceCategory;
    private String deviceType;
    private String globalPhone;
    private String deviceCategory;
    private String deviceCapabilityInd;
    private String backupAssistCapable;
    private String preferredSim;
    private String preferredSoftSim;
    private String alternateSim;
    private String simClass4G;
    private String nfcCapable;
    private String nfcCompatible;
    private String smsCapable;
    private String deviceFamilyType;
    private String buddyUpgrdEligInd;
    private String restrictToFamilyInd;
    private String hdVoice;
    private String coverageCheck4G;
    private String v4b;
    private String numberShareCapable;
    private String euiccCapable;
    private String esimOnlyInd;
    private String vendorKey;
    private String dsds;
    private String operatingSystem;
    private String eligibleNumShareOS;
    private String universalDevice;
    private String wifiCalling;
    private String e911AddrInd;
    private String cdmaCapableInd;
    private String gsmCapableInd;
    private String deviceCarrier;
    private String postpaidRestrictStartDate;
    private String prepayRestrictStartDate;
    @JsonProperty("universalPropCdList")
    private UniversalPropCdList universalPropCdList;
    @JsonProperty("deviceSkuList")
    private DeviceSkuList deviceSkuList;
    private String imFeatureNameList;
    private String marketingCompatibleSimSkuList;

}
