package com.vzw.tools.cache.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ElasticSearchConfigModel {
    private String url;
    private int port;
    private String scheme;
    private String username;
    private String password;
    private boolean authEnabled;
    private String pathPrefix;
}
