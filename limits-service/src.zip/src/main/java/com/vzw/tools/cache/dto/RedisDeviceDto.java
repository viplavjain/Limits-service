package com.vzw.tools.cache.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class RedisDeviceDto {

    private String skuDisplayName;
    private String sorId;
    private String equipId;
    private String upcCode;
    private String upcCodeFull;
    private String instorePickupFlag;
    private String sorDisplayName;
    private String carrier;
    private String billToAccountFlag;
    private String edgeDeviceCap;
    private String edgedpc;
    private String edgedpcgroup;
    private String imageUrlMap;
    private String itemCost;
    private String prodCode1;
    private String prodCode2;
    private String prodCode3;
    private String prodCode4;
    private String prodCode5;
    private String prodName;
    private String prop65Warning;
    private String sorProductFamily;
    private String sorSkuType;
    private String h1Tag;
    private String pairedImeiSku;
    private String productDisplayName;
    private String manufacturerName;
    private String isGlobalReady;
    private String sorDeviceType;
    private String sorDeviceCategory;
    private String coverageCheck4G;
    private String sorBuddyUpgrdEligInd;
    private String daccId;
    private String deviceCapabInd;
    private String dsdsCapable;
    private String sorDeviceFamilyType;
    private String sorHdVoiceInd;
    private String sorImDeviceCategory;
    private String preferredSoftSim;
    private String simClass4G;
    private String smsCapableFlag;
    private String isWifiCalling;
    private String isCdmaCapable;
    private String isGsmCapable;
    private String operatingSystem;
    private String isEuiccCapable;
    private String isNumberShareCapable;
    private String isV4b;
    private String isE911Address;
    private String eSimOnly;
    private List<String> compatibleSimSorIds;
    private String seoUrlName;
    private String fullRetailPrice;
    private String prepayPrice;
    private String edgeFullRetailPrice;
    private String oneYrPrice;
    private String twoYrPrice;
    private String virtualSimSku;
    private String preferredSimSku;

}