package com.vzw.tools.authoring.entity;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class ProductOfferingGroupSearchRequest {
    public Context context;
    public Item item;
    public ResponseFilter responseFilter;


    @Getter
    @Setter
    public static class Context {
        public String level;
        public String workstreamName;
        public String businessRequestID;
        public String user;
        public List<String> types;
        public String securityFilter;
    }

    @Getter
    @Setter
    public static class Item {
        public String type;
        public List<TraversalIDsSearchItem> or;
    }

    @Getter
    @Setter
    public static class TraversalIDsSearchItem {
        public String type;
        public List<ID> ids;
        public int findPaths;
        public List<TraversalPath> traversalPath;
        public boolean includeDocuments;
    }

    @Getter
    @Setter
    public static class ID {
        public String id;
        public String type;
    }

    @Getter
    @Setter
    public static class TraversalPath {
        public String direction;
        public int depth;
        public List<String> relationTypes;
        public List<String> types;
    }

    @Getter
    @Setter
    public static class ResponseFilter {
        public List<String> includeFields;
    }
}
