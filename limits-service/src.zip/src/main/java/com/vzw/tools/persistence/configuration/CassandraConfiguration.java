package com.vzw.tools.persistence.configuration;

import com.vzw.tools.persistence.constant.CassandraConstants;
import com.vzw.tools.persistence.properties.CassandraProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;

import static com.vzw.tools.common.constant.CommonConstants.*;

@Configuration
public class CassandraConfiguration {

    private final CassandraProperties cassandraProperties;

    public CassandraConfiguration(CassandraProperties cassandraProperties) {
        this.cassandraProperties = cassandraProperties;
    }

    public HttpHeaders getHttpHeaders(String productType) {
        HttpHeaders headers = new HttpHeaders();
        if(productType.equalsIgnoreCase(PROD_TYPE_DEVICE)|| productType.equalsIgnoreCase(PROD_TYPE_ACCESSORY)) {
            headers.add(CassandraConstants.HEADER_CLIENT_ID, cassandraProperties.getHeader().getClientId());
            headers.add(CassandraConstants.HEADER_CHANNEL_ID, cassandraProperties.getHeader().getChannelId());
        }
        else if(productType.equalsIgnoreCase(PROD_TYPE_PROMOTION)) {
            headers.add(CassandraConstants.HEADER_CLIENT_ID, cassandraProperties.getHeaderForPromotion().getClientId());
            headers.add(CassandraConstants.headerXApiKey, cassandraProperties.getHeaderForPromotion().getXApiKey());
        }

        return headers;
    }


    public String getHost() {
        return cassandraProperties.getHost().getUrl();
    }
}
