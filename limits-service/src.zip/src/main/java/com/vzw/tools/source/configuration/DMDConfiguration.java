package com.vzw.tools.source.configuration;

import com.vzw.tools.source.properties.DMDProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;

@Component
public class DMDConfiguration {

    private final DMDProperties dmdProperties;

    public DMDConfiguration(DMDProperties dmdProperties) {
        this.dmdProperties = dmdProperties;
    }

    @Bean(name = "dmdDataSource")
    public DataSource dmdDataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setUrl(dmdProperties.getUrl());
        dataSource.setUsername(dmdProperties.getUsername());
        dataSource.setPassword(dmdProperties.getPassword());
        return dataSource;
    }

    @Bean(name = "dmdJdbcTemplate")
    public JdbcTemplate dmdJdbcTemplate() {
        return new JdbcTemplate(dmdDataSource());
    }
}
