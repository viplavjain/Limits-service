package com.vzw.tools.compare.service;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.tools.authoring.service.AuthoringService;
import com.vzw.tools.authoring.service.EPCService;
import com.vzw.tools.cache.service.ElasticSearchService;
import com.vzw.tools.cache.service.RedisService;
import com.vzw.tools.common.constant.CommonConstants;
import com.vzw.tools.common.entity.*;
import com.vzw.tools.common.exception.*;
import com.vzw.tools.common.util.CommonUtil;
import com.vzw.tools.compare.constant.ComparatorConstant;
import com.vzw.tools.consumer.dto.CXPCatalogDto;
import com.vzw.tools.consumer.service.CXPService;
import com.vzw.tools.consumer.service.FusionService;
import com.vzw.tools.persistence.service.CassandraService;
import com.vzw.tools.persistence.service.FedCatalogGetDataService;
import com.vzw.tools.source.configuration.RunTimeMapInitializer;
import com.vzw.tools.source.dao.DeviceDMDDAO;
import com.vzw.tools.source.dao.DeviceDMDFamilyDAO;
import com.vzw.tools.source.dao.DeviceDPIDAO;
import com.vzw.tools.source.entity.DeviceSkuInfo;
import com.vzw.tools.source.service.DeviceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static com.vzw.tools.common.util.CommonUtil.isMatchedObjects;

@Slf4j
@Service
public class ComparatorService {

    private final DeviceService deviceService;
    private final EPCService epcService;
    private final CassandraService cassandraService;
    private final RedisService redisService;
    private final FedCatalogGetDataService fedCatalogGetDataService;

    private final ElasticSearchService elasticSearchService;
    private final FusionService fusionService;
    private final CXPService cxpService;
    private final ErrorBuilder errorBuilder;

    @Autowired
    private AuthoringService authoringService;

    @Autowired
    RunTimeMapInitializer runTimeMapInitializer;


	@Autowired
    ComparatorService(DeviceService deviceService, EPCService epcService, CassandraService cassandraService, RedisService redisService,FedCatalogGetDataService fedCatalogGetDataService,ElasticSearchService elasticSearchService, FusionService fusionService, CXPService cxpService, ErrorBuilder errorBuilder) {
        this.deviceService = deviceService;
        this.epcService = epcService;
        this.cassandraService = cassandraService;
        this.redisService = redisService;
        this.fedCatalogGetDataService = fedCatalogGetDataService;
        this.elasticSearchService = elasticSearchService;
        this.fusionService = fusionService;
        this.cxpService = cxpService;
        this.errorBuilder = errorBuilder;
    }

    public Mono<Map<String, String>> getCacheMappedJson(String sorId, String productType, String env) {

        try {
            return redisService.getRedisMappedJson(sorId, productType, env)
                    .flatMap(cacheBaseMap -> Mono.just(CommonUtil.getFormattedMap(cacheBaseMap)));
        } catch (JsonProcessingException e) {
            return Mono.error(errorBuilder.buildApplicationException(e));
        }

    }

    public Mono<Map<String, String>> getCacheAccessoryMappedJson(String sorId, String productType, String env) {

        try {
            return redisService.getRedisAccessoryMappedJson(sorId, productType, env)
                    .flatMap(cacheBaseMap -> Mono.just(CommonUtil.getFormattedMap(cacheBaseMap)));
        } catch (JsonProcessingException e) {
            return Mono.error(errorBuilder.buildApplicationException(e));
        }

    }

    public Mono<Map<String, String>> getFedCatalogMappedJson1(String sorId, String productType, String env) {
       return  fedCatalogGetDataService.getFedCatalogMappedJson(sorId, productType, env).flatMap(res -> {
            formateDateAndBoolean(res);
            return Mono.just(res);
        });
    }
    private void formateDateAndBoolean(Map<String, String> response) {

        formateDate(ComparatorConstant.dateFormatFields, response);
        response.entrySet().stream()
                .filter(res -> ComparatorConstant.booleanFieldsFederated.contains(res.getKey())
                        && res.getValue() != null)
                .forEach(res -> {
                    if (res.getValue().equals("1")) {
                        response.put(res.getKey(), "Y");
                    } else {
                        response.put(res.getKey(), "N");
                    }
                });
    }

    private void formateDate(List<String> dates, Map<String, String> response) {
        dates.forEach(date -> {
            if (response.get(date) != null
                    && !response.get(date).isEmpty()) {
                response.put(date, LocalDateTime.parse(response.get(date), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S"))
                        .format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
            }
        });
    }

    public Mono<Map<String, String>> getFusionMappedJson1(String sorId, String productType, String env) {
        return fusionService.getFusionMappedJson1(sorId, productType,env)
                .onErrorMap(err -> errorBuilder.buildApplicationException(err));
    }

    public Mono<Map<String,String>> getCXPCatalogMappedJson(String sorId, String productType, String env) {
        Mono<JsonNode> jsonNodeMono = cxpService.getCXPCatalogDetails(sorId,productType,env);
        ObjectMapper mapper = new ObjectMapper();
        return jsonNodeMono.flatMap(jsonNode -> {
            CXPCatalogDto cxpCatalogDto = mapper.convertValue(jsonNode, CXPCatalogDto.class);
            Map<String,String> res= cxpService.getCxpCatalogMappedJson(cxpCatalogDto,sorId,productType);
            formatCxpBoolean(res);
            return Mono.just(res);
        }).onErrorResume(e -> {
            log.error("Error occurred while mapping cxp catalog response call:",e);
            return Mono.error(errorBuilder.buildApplicationException(e));
        });
    }

    public Mono<Map<String,String>> getCXPCatalogMappedJsonForAccessries(String sorId, String productType, String env) {
        Mono<JsonNode> jsonNodeMono = cxpService.getCXPCatalogDetails(sorId,productType,env);
        ObjectMapper mapper = new ObjectMapper();
        return jsonNodeMono.flatMap(jsonNode -> {
            CXPCatalogDto cxpCatalogDto = mapper.convertValue(jsonNode, CXPCatalogDto.class);
            Map<String,String> res= cxpService.getCxpCatalogMappedJsonAccessories(cxpCatalogDto,sorId, productType);
            formatCxpBoolean(res);
            return Mono.just(res);
        }).onErrorResume(e -> {
            log.error("Error occurred while mapping cxp catalog response call:",e);
             return Mono.error(errorBuilder.buildApplicationException(e));
        });
    }

    private void formatCxpBoolean(Map<String, String> response) {
        response.entrySet().stream().filter(res -> res.getValue() != null).forEach(res -> {
                    if (response.get(res.getKey()).equalsIgnoreCase("true")) {
                        response.put(res.getKey(), "Y");
                    } else if (response.get(res.getKey()).equalsIgnoreCase("false")) {
                        response.put(res.getKey(), "N");
                    }
                });
    }

    private EntityDetails getEntityDetails(Map<String, String> sourceMap, Map<String, String> authorizationMap, Map<String, String> persistenceMap, Map<String, String> cacheMap, Map<String, String> fedCatalogMap, Map<String, String> elasticSearchMap,Map<String,String> fusionMap, Map<String,String> cxpCatalogMap) {
        if (isErrorMap(sourceMap))
            return new EntityDetails();
        EntityDetails entityDetails = new EntityDetails();
        List<EntityRowDetails> entityRowDetails = new LinkedList<>();
        sourceMap.keySet().forEach(key -> {
                    EntityRowDetails entityRowDetail = new EntityRowDetails();
                    entityRowDetail.setField(key);
                    //Extract actual values
                    String sourceVal = extractValue(sourceMap, key);
                    String authVal = extractValue(authorizationMap, key);
                    String persistenceVal = extractValue(persistenceMap, key);
                    String cacheVal = extractValue(cacheMap, key);
                    String fedCatalogVal = extractValue(fedCatalogMap, key);
                    String fusionCatalogVal = extractValue(fusionMap, key);
                    String cxpCatalogVal = extractValue(cxpCatalogMap, key);
                    String elasticSearchVal = extractValue(elasticSearchMap, key);
                    // Converting for comparison
                    String sourceValLower = toLowerCase(sourceVal);
                    String authValLower = toLowerCase(authVal);
                    String persistenceValLower = toLowerCase(persistenceVal);
                    String cacheValLower = toLowerCase(cacheVal);
                    String fedCatalogValLower = toLowerCase(fedCatalogVal);
                    String fusionCatalogValLower = toLowerCase(fusionCatalogVal);
                    String cxpCatalogValLower = toLowerCase(cxpCatalogVal);
                    String elasticSearchValLower = toLowerCase(elasticSearchVal);

                    if (null != elasticSearchMap && null != elasticSearchMap.get(key)) {
                        elasticSearchVal = elasticSearchMap.get(key);
                        elasticSearchValLower = elasticSearchMap.get(key).toLowerCase();
                    }

                    boolean isMatched = isMatchedObjects(sourceValLower, authValLower, persistenceValLower, cacheValLower, fedCatalogValLower, elasticSearchValLower, fusionCatalogValLower, cxpCatalogValLower);

                    entityRowDetail.setIsMatch(isMatched);
                    Map<String, String> details = new LinkedHashMap<>();
                    getSourceSystem(details, key, sourceVal);
                    details.put(CommonConstants.EPC, authVal);
                    details.put(CommonConstants.CASSANDRA, persistenceVal);
                    details.put(CommonConstants.FEDERATEDCATALOG, fedCatalogVal);
                    details.put(CommonConstants.REDIS, cacheVal);
                    details.put(CommonConstants.ELASTICSEARCH, elasticSearchVal);
                    details.put(CommonConstants.CXP_CATALOG, cxpCatalogVal);
                    details.put(CommonConstants.FUSION, fusionCatalogVal);
                    entityRowDetail.setDetails(details);
                    entityRowDetails.add(entityRowDetail);
                }
        );
        entityRowDetails.sort(Comparator.comparing(e -> e.getDetails().entrySet().iterator().next().getKey(), Comparator.reverseOrder()));
        entityDetails.setEntityRowDetails(entityRowDetails);
        return entityDetails;
    }

    private String extractValue(Map<String, String> map, String key) {
        return (map != null) ? map.get(key) : null;
    }

    private String toLowerCase(String value) {
        return value != null ? value.toLowerCase() : null;
    }

    private CompareSummary getCompareSummary(Map<String, String> sourceMap, Map<String, String> authorizationMap, Map<String, String> persistenceMap, Map<String, String> cacheMap, Map<String, String> fedCatalogMap, Map<String, String> elasticSearchMap, Map<String,String> fusionMap, Map<String,String> cxpCatalogMap) {
        CompareSummary compareSummaryObj = new CompareSummary();
        List<CompareDetails> compareSummary = new ArrayList<>();
        compareSummary.add(getCompareDetails(CommonConstants.DPI, CommonConstants.EPC, sourceMap, authorizationMap, DeviceDPIDAO.class));
        compareSummary.add(getCompareDetails(CommonConstants.DMD, CommonConstants.EPC, sourceMap, authorizationMap, DeviceDMDDAO.class, DeviceSkuInfo.class, DeviceDMDFamilyDAO.class));
        compareSummary.add(getCompareDetails(CommonConstants.EPC, CommonConstants.CASSANDRA, sourceMap, persistenceMap));
        compareSummary.add(getCompareDetails(CommonConstants.CASSANDRA, CommonConstants.REDIS, persistenceMap, cacheMap));
        compareSummary.add(getCompareDetails(CommonConstants.EPC,CommonConstants.FEDERATEDCATALOG,authorizationMap, fedCatalogMap));
        compareSummary.add(getCompareDetails(CommonConstants.CASSANDRA,CommonConstants.ELASTICSEARCH,persistenceMap, elasticSearchMap));
        compareSummary.add(getCompareDetails(CommonConstants.REDIS,CommonConstants.FUSION,cacheMap,fusionMap));
        compareSummary.add(getCompareDetails(CommonConstants.REDIS,CommonConstants.CXP_CATALOG,cacheMap,cxpCatalogMap));
        compareSummaryObj.setCompares(compareSummary);
        return compareSummaryObj;
    }

    private CompareDetails getCompareDetails(String source, String target, Map<String, String> sourceMap, Map<String, String> targetMap, Class<?>... classes) {
        CompareDetails compareEPCItem = new CompareDetails();
        compareEPCItem.setSource(source);
        compareEPCItem.setTarget(target);
        if(isErrorMap(sourceMap) || isErrorMap(targetMap)){
            compareEPCItem.setIsMatch(Boolean.FALSE);
            return compareEPCItem;

        }
        compareEPCItem.setIsMatch(CommonUtil.isMapMatched(sourceMap, targetMap, classes));
        return compareEPCItem;
    }

    private boolean isErrorMap(Map<String, String> map){
        return map.containsKey(CommonConstants.ERROR_MESSAGE);
    }

    private void getSourceSystem(Map<String, String> details, String key, String value) {
        List<String> propsList = new ArrayList<>();
        Class<?>[] classes = new Class<?>[]{DeviceDPIDAO.class};
        for (Class<?> clazz : classes) {
            for (Field f : clazz.getDeclaredFields()) {
                propsList.add(f.getName().toLowerCase());
            }
        }
        if (propsList.stream().anyMatch(s -> s.equalsIgnoreCase(key))) {
            details.put(CommonConstants.DPI, value);
            details.put(CommonConstants.DMD, null);
        } else {
            details.put(CommonConstants.DPI, null);
            details.put(CommonConstants.DMD, value);
        }
    }

    public Mono<Map<String, String>> getSourceMappedJson1(String sorId, String productType, String env) {
        try {
            return deviceService.getSourceMappedJson(sorId, productType);
        } catch (Exception e) {
            return Mono.error(errorBuilder.buildApplicationException(e));
        }


    }

    public Mono<Map<String, String>> getAuthMappedJson1(String sorId, String productType, String env) throws XmlConversionException, JsonProcessingException {
        try {
            return epcService.getEpcMappedJson1(sorId, env,productType)
                    .flatMap(epcMap ->  Mono.just(CommonUtil.getFormattedMap(epcMap)))
                    .onErrorMap(errorBuilder::buildApplicationException);
        } catch (XmlConversionException | JsonProcessingException e) {
            return Mono.error(errorBuilder.buildApplicationException(e));
        } catch (ConverterException e) {
            return Mono.error(errorBuilder.buildApplicationException(e));
        }
    }


    public Mono<Map<String, String>> getPersistenceMappedJson1(String sorId, String productType, String env){
        return cassandraService.getCassandraMap(sorId, productType, env).
                flatMap(persistentBaseMap ->
                        Mono.just(CommonUtil.getFormattedMap(persistentBaseMap)))
                .onErrorMap(err -> errorBuilder.buildApplicationException(err));

    }

	public Mono<Map<String, String>> getElasticSearchMappedJson(String sorId, String productType, String env) {
		return elasticSearchService.getElasticSearchDataMap(sorId, productType, env)
				.flatMap(elasticSearchBaseMap -> Mono.just(CommonUtil.getFormattedMap(elasticSearchBaseMap)))
				.onErrorMap(errorBuilder::buildApplicationException);
	}
    
    public Mono<EntityResponse> compare(String sorId, String productType, String env) throws XmlConversionException, JsonProcessingException {
        Mono<Map<String, String>> sourceMono = handleException(getSourceMappedJson1(sorId, productType, env), "Source");
        Mono<Map<String, String>> authMono = handleException(getAuthMappedJson1(sorId, productType, env), CommonConstants.EPC);
        Mono<Map<String, String>> persistMono = handleException(getPersistenceMappedJson1(sorId, productType, env), CommonConstants.CASSANDRA);
        Mono<Map<String, String>> cacheMono = handleException(getCacheMappedJson(sorId, productType, env), CommonConstants.REDIS);
        Mono<Map<String, String>> fedCatalogMono = handleException(getFedCatalogMappedJson1(sorId, productType, env), CommonConstants.FEDERATEDCATALOG);
        Mono<Map<String, String>> elasticSearchMono = handleException(getElasticSearchMappedJson(sorId,productType,env), CommonConstants.ELASTICSEARCH);
        Mono<Map<String, String>> fusionMono = handleException(getFusionMappedJson1(sorId,productType,env), CommonConstants.FUSION);
        Mono<Map<String, String>> catalogMono = handleException(getCXPCatalogMappedJson(sorId,productType,env), CommonConstants.CXP_CATALOG);

        return Mono.zip(sourceMono, authMono, persistMono, cacheMono, fedCatalogMono, elasticSearchMono, fusionMono, catalogMono).flatMap(result -> {
            EntityResponse entityResponse = new EntityResponse();
            DataFlow dataFlow = new DataFlow();
            entityResponse.setFlow(dataFlow);
            entityResponse.setCompareSummary(getCompareSummary(result.getT1(), result.getT2(), result.getT3(), result.getT4(), result.getT5(),result.getT6(),result.getT7(), result.getT8()));
            entityResponse.setEntityDetails(getEntityDetails(result.getT1(), result.getT2(), result.getT3(), result.getT4(), result.getT5(),result.getT6(), result.getT7(), result.getT8()));
            entityResponse.setErrorDetails(getErrorDetails(result.getT1(), result.getT2(), result.getT3(), result.getT4(), result.getT5(),result.getT6(), result.getT7(), result.getT8()));
            return Mono.just(entityResponse);
        });

    }

    private Mono<Map<String, String>> handleException(Mono<Map<String, String>> resultMono, String system){
        return resultMono.onErrorResume(err -> {
            Map<String, String> resp = new HashMap<>();
            if (err instanceof FCToolsMSException fcToolsMSException)
                resp.put(CommonConstants.ERROR_MESSAGE, fcToolsMSException.getErrorResponse().getMessage());
            else
                resp.put(CommonConstants.ERROR_MESSAGE, err.getMessage());
            resp.put(CommonConstants.SYSTEM, system);
            return Mono.just(resp);
        });
    }

    private List<ErrorDetails> getErrorDetails(Map<String, String>... results) {
        List<ErrorDetails> errorDetailsList = new ArrayList<>();
        for(Map<String, String> result : results){
            if(result.containsKey(CommonConstants.ERROR_MESSAGE)) {
                errorDetailsList.add(new ErrorDetails(result.get(CommonConstants.SYSTEM),result.get(CommonConstants.ERROR_MESSAGE)));
            }
        }
        return errorDetailsList;
    }


    public Mono<EntityResponse> compareAcccessoriesData(String sorId, String productType, String env) throws ConverterException {
        Mono<Map<String, String>> sourceMono =  handleException(getSourceMappedJson1(sorId, productType, env), "Source");
        Mono<Map<String, String>> authMono = handleException(getECPAccessories(sorId, productType, env), CommonConstants.EPC);
        Mono<Map<String, String>> persistMono = handleException(getPersistenceMappedJson1(sorId, productType, env), CommonConstants.CASSANDRA);
        Mono<Map<String, String>> cacheMono =  handleException(getCacheAccessoryMappedJson(sorId, productType, env), CommonConstants.REDIS);
        Mono<Map<String, String>> fedCatalogMono = handleException(getFedCatalogMappedJson1(sorId, productType, env), CommonConstants.FEDERATEDCATALOG);
        Mono<Map<String, String>> fusionMono = handleException(getFusionMappedJson1(sorId,productType,env), CommonConstants.FUSION);
        Mono<Map<String, String>> elasticSearchMono = handleException(getElasticSearchMappedJson(sorId,productType,env), CommonConstants.ELASTICSEARCH);
        Mono<Map<String, String>> catalogMono = handleException(getCXPCatalogMappedJsonForAccessries(sorId,productType,env), CommonConstants.CXP_CATALOG);

        return Mono.zip(sourceMono, authMono, persistMono, cacheMono, fedCatalogMono, elasticSearchMono, fusionMono, catalogMono).flatMap(result -> {
            EntityResponse entityResponse = new EntityResponse();
            DataFlow dataFlow = new DataFlow();
            entityResponse.setFlow(dataFlow);
            entityResponse.setCompareSummary(getCompareSummary(result.getT1(), result.getT2(), result.getT3(), result.getT4(), result.getT5(),result.getT6(),result.getT7(), result.getT8()));
            entityResponse.setEntityDetails(getEntityDetails(result.getT1(), result.getT2(), result.getT3(), result.getT4(), result.getT5(),result.getT6(), result.getT7(), result.getT8()));
            entityResponse.setErrorDetails(getErrorDetails(result.getT1(), result.getT2(), result.getT3(), result.getT4(), result.getT5(),result.getT6(), result.getT7(), result.getT8()));
            return Mono.just(entityResponse);
        });

    }


    public Mono<Map<String, String>> getECPAccessories(String sorId, String productType, String env) throws ConverterException {
        Mono<JsonNode> jsonNodeMono = authoringService.getEPCRecords(sorId, env);
        ObjectMapper objectMapper = new ObjectMapper();
        return jsonNodeMono.flatMap(jsonNode -> {
            try {
                Map<String, Object> epcResponse = objectMapper.readValue(jsonNode.traverse(), new TypeReference<Map<String, Object>>() {

                });
                Map<String, String> epcMap = new HashMap<String, String>();
                Map<String, String> epcFinalMap =  getEPCMappedRecords(CommonUtil.convertEPCJsonMapToMap(epcResponse, epcMap, ""), productType);
                return Mono.just(epcFinalMap);
            } catch (IOException e) {
                throw new CustomThrowableException("Failed to read the EPC JSON node", e);
            }
        })
                .onErrorMap(errorBuilder::buildApplicationException);
    }

    private Map<String, String> getEPCMappedRecords(Map<String, String> epcMap,String productType) {
        HashMap<String, String> epcMappedFields = new HashMap<>();
        try {
            HashMap<String, String> epcConfigMap = runTimeMapInitializer.getAuthorizationMap(productType);
            for (Map.Entry<String, String> e : epcConfigMap.entrySet()) {
                String value = epcMap.get(e.getValue());
                epcMappedFields.put(e.getKey(), value);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return epcMappedFields;
    }
}