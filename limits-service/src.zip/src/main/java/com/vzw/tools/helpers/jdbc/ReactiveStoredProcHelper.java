package com.vzw.tools.helpers.jdbc;
import com.vzw.tools.helpers.logging.EventLogger;
import com.vzw.tools.helpers.logging.FCEventLogger;
import com.vzw.tools.helpers.logging.vo.AppInfo;
import com.vzw.tools.helpers.logging.Event;
import com.vzw.tools.helpers.logging.vo.TraceInfo;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Metrics;
import org.apache.commons.lang3.StringUtils;
import org.reactivestreams.Publisher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ParameterMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.object.StoredProcedure;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Scheduler;
import reactor.core.scheduler.Schedulers;

import java.sql.JDBCType;
import java.util.*;
import java.util.concurrent.TimeUnit;

import static com.vzw.tools.helpers.logging.LogConstants.*;


public class ReactiveStoredProcHelper {

	private Logger logger = LoggerFactory.getLogger(ReactiveStoredProcHelper.class);
	private JdbcTemplate jdbcTemplate;
	private Map<String, SimpleJdbcCall> calls;
	private MeterRegistry registry;
	private Scheduler scheduler;
	private EventLogger eventLogger;
	private static final String EXECUTE_METRIC_NAME = "com.domainservices.jdbc_proc_execute";
	private static final String INIT_METRIC_NAME = "com.domainservices.jdbc_proc_init";

	public ReactiveStoredProcHelper(JdbcTemplate jdbcTemplate) {
		this(jdbcTemplate, Metrics.globalRegistry, Schedulers.parallel());

	}

	public ReactiveStoredProcHelper(JdbcTemplate jdbcTemplate, MeterRegistry registry) {
		this(jdbcTemplate, registry, Schedulers.parallel());

	}

	public ReactiveStoredProcHelper(JdbcTemplate jdbcTemplate, MeterRegistry registry, Scheduler scheduler) {
		this(jdbcTemplate, registry, scheduler, new FCEventLogger());
	}

	public ReactiveStoredProcHelper(JdbcTemplate jdbcTemplate, MeterRegistry registry, Scheduler scheduler,
									EventLogger eventLogger) {
		this.jdbcTemplate = jdbcTemplate;
		this.calls = new HashMap<>();
		this.registry = registry;
		this.scheduler = scheduler;
		this.eventLogger = eventLogger;
	}

	public void initialize(String schemaName, String catalogName, String procedureName,
						   List<SqlOutParameter> parameters) {
		createJdbcCall(schemaName, catalogName, procedureName, parameters);
	}

	public SimpleJdbcCall createJdbcCall(String schemaName, String catalogName, String procedureName,
										 List<SqlOutParameter> parameters) {
		String name = StringUtils.defaultString(schemaName, "NA") + "." + StringUtils.defaultString(catalogName, "NA")
				+ "." + procedureName;
		SimpleJdbcCall call = calls.computeIfAbsent(name, (n) -> {
			long start = System.currentTimeMillis();
			SimpleJdbcCall c = new SimpleJdbcCall(jdbcTemplate);
			if (!StringUtils.isBlank(catalogName)) {
				c.withCatalogName(catalogName);
			}
			if (!StringUtils.isBlank(schemaName)) {
				c.withSchemaName(schemaName);
			}
			c.withProcedureName(procedureName);
			if (parameters != null) {
				parameters.forEach(p -> {
					c.addDeclaredParameter(p);
					logger.trace("Added parameter  {} , {}  ", p.getName(), JDBCType.valueOf(p.getSqlType()).getName());
				});
			}
			c.compile();
			logger.trace("Initialized stored procedure {} ", name);
			long end = System.currentTimeMillis();
			registry.timer("com.domainservices.jdbc_proc_init", "proc_name", name).record((end - start),
					TimeUnit.MILLISECONDS);
			return c;
		});
		return call;
	}
	
	public SimpleJdbcCall createJdbcCallWithFetchSize(String schemaName, String catalogName, String procedureName,
			List<SqlOutParameter> parameters,int fetchSize) {
		String name = StringUtils.defaultString(schemaName, "NA") + "." + StringUtils.defaultString(catalogName, "NA")
		+ "." + procedureName;
		SimpleJdbcCall call = calls.computeIfAbsent(name, (n) -> {
			long start = System.currentTimeMillis();
			
			if(fetchSize > 0)
				jdbcTemplate.setFetchSize(fetchSize);
			else
				jdbcTemplate.setFetchSize(600);
			
			
			SimpleJdbcCall c = new SimpleJdbcCall(jdbcTemplate);
			if (!StringUtils.isBlank(catalogName)) {
				c.withCatalogName(catalogName);
			}
			if (!StringUtils.isBlank(schemaName)) {
				c.withSchemaName(schemaName);
			}
			c.withProcedureName(procedureName);
			if (parameters != null) {
				parameters.forEach(p -> {
					c.addDeclaredParameter(p);
					logger.trace("Added parameter with fetchSize {} , {}  ", p.getName(), JDBCType.valueOf(p.getSqlType()).getName());
				});
			}
			c.compile();
			logger.trace("Initialized stored procedure with fetchSize {} ", name);
			long end = System.currentTimeMillis();
			registry.timer("com.domainservices.jdbc_proc_init", "proc_name", name).record((end - start),
					TimeUnit.MILLISECONDS);
			return c;
		});
		return call;
}

	public void initialize(String catalogName, String procedureName, List<SqlOutParameter> parameters) {
		this.initialize(null, catalogName, procedureName, parameters);
	}

	public void initialize(String procedureName, List<SqlOutParameter> parameters) {
		this.initialize(null, procedureName, parameters);
	}

	public SimpleJdbcCall getJdbcCall(String schemaName, String catalogName, String procedureName) {
		String name = StringUtils.defaultString(schemaName, "NA") + "." + StringUtils.defaultString(catalogName, "NA")
				+ "." + procedureName;
		return calls.computeIfAbsent(name, (n) -> {
			logger.trace("Initializing procedure {} on execute ", n);
			return createJdbcCall(schemaName, catalogName, procedureName, null);
		});
	}
	
	public SimpleJdbcCall getJdbcCallWithFetchSize(String schemaName, String catalogName, String procedureName,int fetchSize) {
		String name = StringUtils.defaultString(schemaName, "NA") + "." + StringUtils.defaultString(catalogName, "NA")
				+ "." + procedureName;
		return calls.computeIfAbsent(name, (n) -> {
			logger.trace("Initializing procedure {} on executeWithFetchSize ", n);
			return createJdbcCallWithFetchSize(schemaName, catalogName, procedureName, null,fetchSize);
		});
	}

	public Mono<Map<String, Object>> execute(String procedureName, Map<String, Object> arguments) {
		SimpleJdbcCall call = getJdbcCall(null, null, procedureName);
		return execute(call, arguments);
	}

	public Mono<Map<String, Object>> execute(String catalogName, String procedureName, Map<String, Object> arguments) {
		SimpleJdbcCall call = getJdbcCall(null, catalogName, procedureName);
		return execute(call, arguments);
	}

	public Mono<Map<String, Object>> execute(String schemaName, String catalogName, String procedureName,
											 Map<String, Object> arguments) {
		SimpleJdbcCall call = getJdbcCall(schemaName, catalogName, procedureName);
		return execute(call, arguments);
	}
	
	public Mono<Map<String, Object>> execute(String schemaName, String catalogName, String procedureName,
			Map<String, Object> arguments,int fetchSize) {
		SimpleJdbcCall call = getJdbcCallWithFetchSize(schemaName, catalogName, procedureName,fetchSize);
		return execute(call, arguments);
    }

	protected Mono<Map<String, Object>> execute(SimpleJdbcCall call, Map<String, Object> arguments) {

		return Mono.deferContextual(Mono::just).flatMap(c -> {
			long start = System.currentTimeMillis();
			return wrapPublisher(Mono.<Map<String, Object>>create(emitter -> {
				SqlParameterSource in = new MapSqlParameterSource(arguments);
				Map<String, Object> results = call.execute(in);
				emitter.success(results);
			}).doOnSuccess(r -> {
				logger.trace("Results {} ", r.size());
				long end = System.currentTimeMillis();
				registry.timer("com.domainservices.jdbc_proc_execute", "proc_name", call.getProcedureName(), "status",
						"success").record((end - start), TimeUnit.MILLISECONDS);
				logSuccess(start, end, r, call.getProcedureName(), StringUtils.join(arguments),
						c.getOrEmpty(TRACE_INFO_KEY));

			})).doOnError(t -> {
				logger.warn(t.getMessage());
				long end = System.currentTimeMillis();
				registry.timer("com.domainservices.jdbc_proc_execute", "proc_name", call.getProcedureName(), "status",
						"failure").record((end - start), TimeUnit.MILLISECONDS);
				logFailure(start, end, t, call.getProcedureName(), StringUtils.join(arguments),
						c.getOrEmpty(TRACE_INFO_KEY));

			});
		});
	}

	private <T> Mono<T> wrapPublisher(Publisher<T> publisher) {
		return Mono.from(publisher).publishOn(scheduler);
	}

	private void logSuccess(long startTime, long endTime, Map<String, Object> results, String procName, String sql,
							Optional<TraceInfo> traceInfo) {
		Event event = new Event();
		event.setEventType(EVENT_TYPE_EXTERNAL_CALL);
		event.setExternalSystem(EXTERNAL_SYSTEM_DB);
		event.setFunctionName(procName);
		event.setStartTime(startTime);
		event.setEndTime(endTime);
		event.setDuration(endTime - startTime);
		event.setApiRequest(sql);
		event.setApiResponse(results.toString());
		event.setResponseSize(results.size());
		event.setResponseStatusCode("SUCCESS");
		event.setResultStatus("SUCCESS");
		event.setStatusMessage("SUCCESS");
		event.setStatusCode(200);
		if (traceInfo.isPresent()) {
			TraceInfo trace = traceInfo.get();
			event.setCorrelationId(trace.getCorrelationId());
			event.setDomainCorrelationId(trace.getDomainCorrelationId());
			event.setE2eRequestId(trace.getE2eRequestId());
			event.setSsoSessionId(trace.getSessionId());
			event.setRouteType(trace.getRouteType());
			event.setLogPayload(trace.isLogPayload());
			event.setAppSessionId(trace.getSessionId());
			event.setClientId(trace.getClientId());
			if (Objects.nonNull(trace.getAppInfo())) {
				AppInfo appInfo = trace.getAppInfo();
				event.setVsadId(appInfo.getProjectApplicationVSAD());
				event.setVastId(appInfo.getVastId());
				event.setApplication(appInfo.getName());
				event.setAppName(appInfo.getName());
			}

		}
		// Need more discussion on this
		event.setLogType("OutboundCall");
		eventLogger.logEvent(event);
	}

	private void logFailure(long startTime, long endTime, Throwable t, String procName, String sql,
							Optional<TraceInfo> traceInfo) {
		Event event = new Event();
		event.setEventType(EVENT_TYPE_EXTERNAL_CALL);
		event.setExternalSystem(EXTERNAL_SYSTEM_DB);
		event.setFunctionName(procName);
		event.setStartTime(startTime);
		event.setEndTime(endTime);
		event.setDuration(endTime - startTime);
		event.setApiRequest(sql);
		event.setResponseStatusCode("FAILURE");
		event.setResultStatus("FAILURE");
		event.setResponseStatusMessage(t.getMessage());
		event.setStatusMessage("ERROR");
		event.setStatusCode(500);
		if (traceInfo.isPresent()) {
			TraceInfo trace = traceInfo.get();
			event.setCorrelationId(trace.getCorrelationId());
			event.setDomainCorrelationId(trace.getDomainCorrelationId());
			event.setE2eRequestId(trace.getE2eRequestId());
			event.setSessionId(trace.getSessionId());
			event.setRouteType(trace.getRouteType());
			event.setAppSessionId(trace.getSessionId());
			event.setClientId(trace.getClientId());

			if (Objects.nonNull(trace.getAppInfo())) {
				AppInfo appInfo = trace.getAppInfo();
				event.setVsadId(appInfo.getProjectApplicationVSAD());
				event.setVastId(appInfo.getVastId());
				event.setApplication(appInfo.getName());
				event.setAppName(appInfo.getName());
			}
		}
		// Need more discussion on this
		event.setLogType("OutboundCall");
		eventLogger.logEvent(event);
	}

	public Mono<Map<String, Object>> execute(StoredProcedure proc, ParameterMapper inParamMapper) {
		return Mono.deferContextual(Mono::just).flatMap(c -> {
			long start = System.currentTimeMillis();
			return wrapPublisher(Mono.<Map<String, Object>>create(emitter -> {
				Map<String, Object> results = proc.execute(inParamMapper);
				emitter.success(results);
			}).doOnSuccess(r -> {
				logger.trace("Results {} ", r.size());
				long end = System.currentTimeMillis();
				registry.timer("com.domainservices.jdbc_proc_execute", "proc_name", proc.getSql(), "status", "success")
						.record((end - start), TimeUnit.MILLISECONDS);
				logSuccess(start, end, r, proc.getSql(), proc.getCallString(), c.getOrEmpty(TRACE_INFO_KEY));

			})).doOnError(t -> {
				logger.warn(t.getMessage());
				long end = System.currentTimeMillis();
				registry.timer("com.domainservices.jdbc_proc_execute", "proc_name", proc.getSql(), "status", "failure")
						.record((end - start), TimeUnit.MILLISECONDS);
				logFailure(start, end, t,proc.getSql(), proc.getCallString(), c.getOrEmpty(TRACE_INFO_KEY));

			});
		});

	}


	public StoredProcedure createStoredProc(String name, List<SqlParameter> parameters) {
		logger.trace("Creating stored procedure {} ", name);
		long start = System.currentTimeMillis();
		StoredProcedure sp =  new StoredProcedure(this.jdbcTemplate, name) {};
		parameters.forEach(p -> {
			sp.declareParameter(p);
		});
		sp.compile();
		long end = System.currentTimeMillis();
		registry.timer("com.domainservices.jdbc_proc_init", "proc_name", name).record((end - start),
				TimeUnit.MILLISECONDS);
		return sp;

	}

}
