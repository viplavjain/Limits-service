package com.vzw.tools.consumer.configuration;

import com.vzw.tools.consumer.constant.CXPConstant;
import com.vzw.tools.consumer.properties.CXPProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

@Configuration
@Slf4j
public class CXPConfiguration {

    private final CXPProperties cxpProperties;

    public CXPConfiguration(CXPProperties cxpProperties ){
        this.cxpProperties = cxpProperties;
    }

    public String getAPIUrl(String env){
        String apiUrl = null;
        if(cxpProperties.getApiUrl() !=null){
            apiUrl=cxpProperties.getApiUrl().get(env.toLowerCase());
        }
        if(apiUrl == null){
           log.debug("CXP API url is not configured for env: {}",env);
        }
        return apiUrl;
    }
    public HttpHeaders getHeader(){
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add(CXPConstant.API_KEY,cxpProperties.getApiKey());
        httpHeaders.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        return httpHeaders;
    }
}
