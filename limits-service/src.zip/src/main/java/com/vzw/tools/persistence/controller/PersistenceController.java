package com.vzw.tools.persistence.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.tools.common.constant.CommonConstants;
import com.vzw.tools.common.exception.ErrorBuilder;
import com.vzw.tools.common.exception.XmlConversionException;
import com.vzw.tools.common.util.CommonUtil;
import com.vzw.tools.persistence.service.CassandraService;
import com.vzw.tools.persistence.service.FedCatalogGetDataService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.util.Map;

import static com.vzw.tools.common.constant.CommonConstants.PROD_TYPE_DEVICE;

@RestController
@Slf4j
public class PersistenceController {

    private final CassandraService cassandraService;
    private final FedCatalogGetDataService fedCatalogService;
    private final ErrorBuilder errorBuilder;

    @Autowired
    public PersistenceController(CassandraService cassandraService,
                                 FedCatalogGetDataService fedCatalogService,
                                 ErrorBuilder errorBuilder) {
        this.cassandraService = cassandraService;
        this.fedCatalogService = fedCatalogService;
        this.errorBuilder = errorBuilder;
    }

    @GetMapping("/cassandra/{productType}/{env}")
    public Mono<ResponseEntity<Object>> getCassandraDeviceDetails(@PathVariable String productType, @PathVariable String env, @RequestParam(value = "id", required = true) String id) throws JsonProcessingException {
        log.info(" Begin getCassandraDeviceDetails API call for product Type:{},on environment:{}", productType, env);
        Mono<Object> cassandraData = null;
        if(productType.equalsIgnoreCase(PROD_TYPE_DEVICE)||productType.equalsIgnoreCase(CommonConstants.PROD_TYPE_ACCESSORY)) {
            cassandraData = cassandraService.getDeviceDetailsUpdated(id, productType, env);
        }
        else if(productType.equalsIgnoreCase(CommonConstants.PROD_TYPE_PROMOTION)) {
            Mono<JsonNode> combinedResponse = cassandraService.getPromotionDetails(id, productType, env);
            cassandraData = CommonUtil.getPromotionDetails(combinedResponse);
        }

        if(cassandraData!=null) {
            return cassandraData.flatMap(res ->
                    Mono.just(ResponseEntity
                            .ok()
                            .contentType(MediaType.APPLICATION_JSON)
                            .body(res))
            ).onErrorMap(errorBuilder::buildApplicationException);
        }
        else
            return Mono.empty();
    }

    @GetMapping("/fedCatalogDetails/{productType}/{env}")
    public Mono<Map<String,String>> getFedCatalogDeviceDetails(@PathVariable String productType, @PathVariable String env, @RequestParam(value = "id", required = true) String id) throws XmlConversionException {
        log.info(" fedCatalogDetails API called");
        return  fedCatalogService.getFederatedDBResponse(id, productType);
    }

}
