package com.vzw.tools.authoring.entity;

import java.util.List;

public class TokenModel {
    private String clientID;
    private String flow;
    private String intent;
    private String sub;
    private List<String> roles;

    public TokenModel() {
    }

    public TokenModel(String clientId, String flow, String intent, String sub, List<String> roles) {
        this.clientID = clientId;
        this.flow = flow;
        this.intent = intent;
        this.sub = sub;
        this.roles = roles;
    }

    public String getClientID() {
        return clientID;
    }

    public void setClientID(String clientId) {
        this.clientID = clientId;
    }

    public String getFlow() {
        return flow;
    }

    public void setFlow(String flow) {
        this.flow = flow;
    }

    public String getIntent() {
        return intent;
    }

    public void setIntent(String intent) {
        this.intent = intent;
    }

    public String getSub() {
        return sub;
    }

    public void setSub(String sub) {
        this.sub = sub;
    }

    public List<String> getRoles() {
        return roles;
    }

    public void setRoles(List<String> roles) {
        this.roles = roles;
    }
}
