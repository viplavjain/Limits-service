package com.vzw.tools.source.dao;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import com.vzw.tools.source.entity.ImAccessoryList;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@JacksonXmlRootElement(localName = "deviceFamilyInfo")
public class DeviceDMDFamilyDAO {

    private String familyName;
    private ImAccessoryList imAccessoryList;
}
