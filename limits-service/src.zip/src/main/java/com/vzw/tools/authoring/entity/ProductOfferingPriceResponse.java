package com.vzw.tools.authoring.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductOfferingPriceResponse {
    private List<PriceRecord> priceRecords;
    private Links _links;
    private int totalCharges;
    private int nonFilteredTotalCharges;
    private boolean hasPriority;
    private Boolean isRecordDuplicate;
    private boolean isInvalidRecord;

    @Getter
    @Setter
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class PriceRecord {
        private String priceRecordId;
        private int priority;
        private List<Price> price;
        private List<Parameter> parameter;
        private List<Object> externalIds;
        private boolean hasDefaultInstallment;
    }

    @Getter
    @Setter
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Price {
        private String id;
        private Object taxIncludedAmount;
        private DutyFreeAmount dutyFreeAmount;
        private Object priceReduction;
        private Object percentage;
        private Object priceAttribute;
        private ValidFor validFor;
        private Object pricedNumberOfUnits;
    }

    @Getter
    @Setter
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DutyFreeAmount {
        private String value;
        private String unit;
        private Object symbol;
    }

    @Getter
    @Setter
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ValidFor {
        private String startDateTime;
        private Object endDateTime;
    }

    @Getter
    @Setter
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Parameter {
        private String name;
        private ParameterValue value;
        private Object unitOfMeasure;
        private Object valueTo;
        private Object valueFrom;
        private Object valueList;
    }

    @Getter
    @Setter
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ParameterValue {
        private String name;
        private List<LocalizedName> localizedName;
        private Object valueTo;
        private Object valueFrom;
    }

    @Getter
    @Setter
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class LocalizedName {
        private String locale;
        private String value;
    }

    @Getter
    @Setter
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Links {
        private Self self;
    }

    @Getter
    @Setter
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Self {
        private String href;
        private Object method;
    }
}
