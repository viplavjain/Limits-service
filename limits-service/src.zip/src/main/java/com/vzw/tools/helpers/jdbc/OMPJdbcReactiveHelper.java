package com.vzw.tools.helpers.jdbc;

import com.vzw.tools.common.constant.CommonConstants;
import com.vzw.tools.common.exception.ErrorBuilder;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.internal.OracleTypes;
import org.elasticsearch.common.inject.Inject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.*;

import static com.vzw.tools.common.constant.CommonConstants.*;

@Component
@Slf4j
public class OMPJdbcReactiveHelper {

    private final ReactiveStoredProcHelper reactiveStoredProcHelper;

    @Inject
    public OMPJdbcReactiveHelper(@Qualifier("ompJdbcTemplate") JdbcTemplate jdbcTemplate) {
        super();
        this.reactiveStoredProcHelper = new ReactiveStoredProcHelper(jdbcTemplate);
    }

    @Autowired
    ErrorBuilder errorBuilder;

    @PostConstruct
    private void init() {
        log.trace("Entering into InstallmentLoanProcedure init()");
        List<SqlOutParameter> parameters = new ArrayList<>();
        parameters.add(new SqlOutParameter(CommonConstants.P_RESULT_SET, OracleTypes.REF_CURSOR, (resultSet, i) -> setResultSet(resultSet)));
        reactiveStoredProcHelper.initialize(OMP_SCHEMA, "", SP_PROMOTIONS_OMP, parameters);
        log.trace("Exiting from InstallmentLoanProcedure init()");
    }

    private Map<String, String> setResultSet(ResultSet resultSet) throws SQLException {
        ResultSetMetaData metaData = resultSet.getMetaData();
        int columnCount = metaData.getColumnCount();
        Map<String, String> result = new HashMap<>();
        for (int i = 1; i <= columnCount; i++) {
            String columnName = metaData.getColumnName(i).toLowerCase();
            Object columnValue = resultSet.getObject(i);
            result.put(columnName, null != columnValue ? columnValue.toString() : null);

        }
        return result;
    }

    //@LogExecutionTime
    public Mono<Map<String, String>> retrieveOMPResponse(String offerId) {
        Map<String, Object> arguments = new HashMap<>();
        arguments.put(P_OFFER_ID, offerId);
        Mono<Map<String, Object>> monoResponse = reactiveStoredProcHelper
                .execute(OMP_SCHEMA, "", SP_PROMOTIONS_OMP, arguments)
                .subscribeOn(Schedulers.boundedElastic())
                .onErrorMap(e -> errorBuilder.buildApplicationException(e));
        return monoResponse.flatMap(data -> {
            List<?> result = (List<?>) data.get(CommonConstants.P_RESULT_SET);
            Optional<Map<String, String>> responseMap = (Optional<Map<String, String>>) result.stream().findFirst();
            if (responseMap.isPresent())
                return Mono.just(responseMap.get());
            return Mono.just(new HashMap<>());
        });
    }
}
