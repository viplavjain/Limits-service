package com.vzw.tools.authoring.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.vzw.tools.authoring.configuration.EpcConfiguration;
import com.vzw.tools.authoring.entity.ProductOfferSearchRequest;
import com.vzw.tools.authoring.entity.ProductOfferingGroupSearchRequest;
import com.vzw.tools.authoring.entity.ProductOfferingRequest;
import com.vzw.tools.authoring.entity.Token;
import com.vzw.tools.authoring.properties.EpcProperties;
import com.vzw.tools.common.constant.AmdocsConstants;
import com.vzw.tools.common.constant.CommonConstants;
import com.vzw.tools.common.exception.ConverterException;
import com.vzw.tools.common.exception.CustomThrowableException;
import com.vzw.tools.common.service.TokenService;
import com.vzw.tools.common.util.GenericWebClient;
import com.vzw.tools.common.util.JsonToObjectConverter;
import com.vzw.tools.helpers.http.HttpService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static com.vzw.tools.common.constant.AmdocsConstants.*;
import static com.vzw.tools.common.constant.CommonConstants.ID;
import static com.vzw.tools.common.constant.CommonConstants.PROD_TYPE_PROMOTION;
import static com.vzw.tools.common.util.CommonUtil.*;

@Slf4j
@Service
public class AuthoringService {

    @Autowired
    TokenService tokenService;

    @Autowired
    GenericWebClient genericWebClient;

    @Autowired
    EpcConfiguration epcConfiguration;
    @Autowired
    EpcProperties epcProperties;

    @Autowired
    ObjectMapper mapper;

    @Autowired
    @Qualifier("amdocsPromotions")
    private HttpService amdocsPromotion;

    @Autowired
    @Qualifier("epcAmdocsHost")
    private HttpService epcAmdocsHost;

    @Autowired
    @Qualifier("amdocsPriceRecords")
    private HttpService amdocsPriceRecords;

    @Value("${spring.epc.amdocsHost.search:#{null}}")
    private String searchuri;

    @Value("${spring.epc.amdocsHost.searchProduct:#{null}}")
    private String searchProductUri;

    @Value("${spring.epc.amdocsHost.pop:#{null}}")
    private String popUri;

    public Mono<JsonNode> getEPCRecords(String sorId, String env) throws ConverterException {
        log.info("getEPCDeviceDetails API called");
        Mono<Token> tokenMono = tokenService.getTokenHttpService();
        ProductOfferSearchRequest productOfferSearchRequest = createSearchRequest(sorId);
        return tokenMono.flatMap(token -> {
            String bearerToken = CommonConstants.BEARER + token.getToken();
            log.info("Bearer token generated is {} environment", bearerToken);
            try {
                return fetchProductOffering(bearerToken, env, productOfferSearchRequest);
            } catch (Exception e) {
                log.error("Error occurred in productOffering call", e);
                return Mono.error(new CustomThrowableException("Unexpected error in fetch from Product Offering", e));
            }
        }).onErrorResume(e -> {
            log.error("Error occurred while generating token in TokenService:", e);
            return Mono.error(new CustomThrowableException("Unexpected error in generating token", e));
        });
    }

    public Mono<JsonNode> fetchProductOffering(String bearerToken, String env, ProductOfferSearchRequest amdocsSearchRequest) throws JsonProcessingException {
        //Product Offer search api
       //return genericWebClient.callPostApi(bearerToken, epcConfiguration.getAmdocsSearchApi(env), amdocsSearchRequest, JsonNode.class, AmdocsConstants.PRODUCT_OFFER_SEARCH)
        Map<String, String> headers = populateHeadersWithToken(bearerToken);
        String amdocsSearchRequestStr = convertObjToString(amdocsSearchRequest, mapper);
        return epcAmdocsHost.postRequest(amdocsSearchRequestStr,headers, searchuri,AmdocsConstants.PRODUCT_OFFER_SEARCH)
                .flatMap(searchResponseStr -> {
                    JsonNode searchResponse;
                    try {
                        searchResponse = getObjFromStr(searchResponseStr, mapper, JsonNode.class);
                        log.info("Response from epc search call  is {}", searchResponse);
                        String documentID = getValue(searchResponse, "/documents/0/documentMetaData/documentID");
                        return fetchProductSpecification(bearerToken, env, documentID);
                    } catch (Exception e) {
                        return Mono.error(new CustomThrowableException("Unexpected error in fetch from Product Specification", e));
                    }
                }).onErrorResume(e -> {
                    log.error("Error occurred while calling Product Offer Search api:", e);
                    return Mono.error(new CustomThrowableException("Error occurred while calling Product Offer Search api", e));
                });
    }

    public Mono<JsonNode> fetchProductSpecification(String bearerToken, String env, String documentID) throws ConverterException, JsonProcessingException {
        ProductOfferingRequest productOfferingRequest = JsonToObjectConverter.jsonToObject(AmdocsConstants.AMDOCS_PRODUCT_OFFER_JSON, ProductOfferingRequest.class);
        productOfferingRequest.getIds().get(0).setId(documentID);
        // Product offering json fetch api
        Map<String, String> headers = populateHeadersWithToken(bearerToken);
        String productOfferingRequestStr = mapper.writeValueAsString(productOfferingRequest);
        //return genericWebClient.callPostApi(bearerToken, epcConfiguration.getAmdocsProductApi(env), productOfferingRequest, JsonNode.class, AmdocsConstants.PRODUCT_OFFER)
        return epcAmdocsHost.postRequest(productOfferingRequestStr,headers, searchProductUri, AmdocsConstants.PRODUCT_OFFER)
                .flatMap(poResponseStr -> {
                   // try {
                        JsonNode poResponse = getObjFromStr(poResponseStr, mapper, JsonNode.class);
                        String productSpecificationId = getValue(poResponse, "/documents/0/document/productSpecification/id");
                        Mono<JsonNode> monoProductOfferingPrice = fetchPriceRecords(poResponse, bearerToken, env);
                        return monoProductOfferingPrice.flatMap(prodOferPrice -> {
                            try {
                                return fetchProductDetails(bearerToken, env, poResponse, prodOferPrice, productSpecificationId);
                            } catch (JsonProcessingException | ConverterException e) {
                                return Mono.error(new CustomThrowableException("Unexpected error in fetch from Product Details", e));
                            }
                        }).onErrorResume(err ->
                                zipAndTransformResponse(poResponse, null, null, null, null)
                        );
//                    } catch (JsonProcessingException e) {
//                        throw new RuntimeException(e);
//                    }

                }).onErrorResume(e -> {
                    log.error("Error occurred while calling Product Offer  api:", e);
                    return Mono.error(new CustomThrowableException("Error occurred while calling Product Offer  api", e));
                });
    }

    public Mono<JsonNode> fetchProductDetails(String bearerToken, String env, JsonNode poResponse, JsonNode monoProductOfferingPrice, String productSpecificationId) throws ConverterException, JsonProcessingException {
        ProductOfferingRequest productSpecificationRequest = JsonToObjectConverter.jsonToObject(AmdocsConstants.AMDOCS_PRODUCT_SPECIFICATION_JSON, ProductOfferingRequest.class);
        productSpecificationRequest.getIds().get(0).setId(productSpecificationId);
        Map<String, String> headers = populateHeadersWithToken(bearerToken);
        String productSpecificationRequestStr = mapper.writeValueAsString(productSpecificationRequest);
//        Mono<JsonNode> monoProductSpecificationSkuResponse = genericWebClient.callPostApi(
//                bearerToken, epcConfiguration.getAmdocsProductApi(env), productSpecificationRequest, JsonNode.class, AmdocsConstants.PRODUCT_SPECIFICATION_SKU
//        );
        Mono<JsonNode> monoProductSpecificationSkuResponse = epcAmdocsHost.postRequest(productSpecificationRequestStr,headers, searchProductUri, AmdocsConstants.PRODUCT_SPECIFICATION_SKU).flatMap( prodDetailsResStr -> getMonoObjFromStr(prodDetailsResStr, mapper, JsonNode.class));
        return monoProductSpecificationSkuResponse.flatMap(psskuResponse -> {
            String bundledProductSpecification = getValue(psskuResponse, "/documents/0/document/bundledProductSpecification/0/id");
            if (bundledProductSpecification != null && bundledProductSpecification.length() > 0) {
                try {
                    return fetchBundledProductDetails(bearerToken, env, poResponse, monoProductOfferingPrice, psskuResponse);
                } catch (Exception e) {
                    log.info("Error in fetchBundledProductDetails api", e);
                    return zipAndTransformResponse(poResponse, monoProductOfferingPrice, null, null, null);
                }
            } else {
                try {
                    return fetchProductOfferingGroup(bearerToken, poResponse, env)
                            .flatMap(monoProductOfferingGroupResponse ->
                                    zipAndTransformResponse(poResponse, monoProductOfferingPrice, psskuResponse, null, monoProductOfferingGroupResponse)
                            );
                } catch (Exception e) {
                    return Mono.error(new CustomThrowableException("Unexpected error in fetch from Product Offering Group", e));
                }
            }
        }).onErrorResume(e -> {
            log.error("Error occurred while calling product specification sku api:", e);
            return zipAndTransformResponse(poResponse, monoProductOfferingPrice, null, null, null);
        });
    }

    public Mono<JsonNode> fetchBundledProductDetails(String bearerToken, String env, JsonNode poResponse, JsonNode monoProductOfferingPrice, JsonNode psskuResponse) throws ConverterException, JsonProcessingException {
        String bundledProductId = getValue(psskuResponse, "/documents/0/document/bundledProductSpecification/0/id");
        ProductOfferingRequest productSpecificationPrdRequest = JsonToObjectConverter.jsonToObject(AmdocsConstants.AMDOCS_PRODUCT_SPECIFICATION_JSON, ProductOfferingRequest.class);
        productSpecificationPrdRequest.getIds().get(0).setId(bundledProductId);

        Map<String, String> headers = populateHeadersWithToken(bearerToken);

        String productSpecificationRequestStr = mapper.writeValueAsString(productSpecificationPrdRequest);

//        Mono<JsonNode> monoProductSpecificationPrdResponse = genericWebClient.callPostApi(
//                bearerToken, epcConfiguration.getAmdocsProductApi(env), productSpecificationPrdRequest, JsonNode.class, AmdocsConstants.PRODUCT_SPECIFICATION_PRD
//        );
        Mono<JsonNode> monoProductSpecificationPrdResponse = epcAmdocsHost.postRequest(productSpecificationRequestStr,headers, searchProductUri, AmdocsConstants.PRODUCT_SPECIFICATION_PRD).flatMap( prodDetailsResStr -> getMonoObjFromStr(prodDetailsResStr, mapper, JsonNode.class));
        return monoProductSpecificationPrdResponse.flatMap(prodeSpecRes -> {
            try {
                return fetchProductOfferingGroup(bearerToken, poResponse, env)
                        .flatMap(monoProductOfferingGroupResponse ->
                                zipAndTransformResponse(poResponse, monoProductOfferingPrice, psskuResponse, prodeSpecRes, monoProductOfferingGroupResponse)
                        );
            } catch (ConverterException | JsonProcessingException e) {
                return Mono.error(new CustomThrowableException("Unexpected error in fetch from Bundle Product Details", e));
            }
        });
    }

    public Mono<JsonNode> zipAndTransformResponse(
            JsonNode poResponse,
            JsonNode monoProductOfferingPrice,
            JsonNode monoProductSpecificationSkuResponse,
            JsonNode monoProductSpecificationPrdResponse,
            JsonNode monoProductOfferingGroupResponse
    ) {
        ObjectMapper objectMapper = new ObjectMapper();
        ObjectNode combinedNodes = objectMapper.createObjectNode();
        combinedNodes.set(AmdocsConstants.PRODUCT_OFFER, poResponse);
        combinedNodes.set(AmdocsConstants.PRODUCT_OFFER_PRICE, monoProductOfferingPrice);
        combinedNodes.set(AmdocsConstants.PRODUCT_SPECIFICATION_SKU, monoProductSpecificationSkuResponse);
        combinedNodes.set(AmdocsConstants.PRODUCT_SPECIFICATION_PRD, monoProductSpecificationPrdResponse);
        combinedNodes.set(AmdocsConstants.PRODUCT_OFFER_GROUP, monoProductOfferingGroupResponse);
        return Mono.just(combinedNodes);

    }

    public Mono<JsonNode> fetchProductOfferingGroup(String bearerToken, JsonNode poResponse, String env) throws ConverterException, JsonProcessingException {
        ProductOfferingGroupSearchRequest productOfferingGroupSearchRequest = JsonToObjectConverter.jsonToObject(AmdocsConstants.AMDOCS_PRODUCT_OFFERGROUP_SEARCH_JSON, ProductOfferingGroupSearchRequest.class);
        ProductOfferingRequest productOfferingGroupRequest = JsonToObjectConverter.jsonToObject(AmdocsConstants.AMDOCS_PRODUCT_OFFERGROUP_JSON, ProductOfferingRequest.class);

        String poDocumentId = getValue(poResponse, "/documents/0/documentMetaData/documentID");
        productOfferingGroupSearchRequest.getItem().getOr().get(0).getIds().get(0).setId(poDocumentId);
        productOfferingGroupSearchRequest.getItem().getOr().get(1).getIds().get(0).setId(poDocumentId);

        Map<String, String> headers = populateHeadersWithToken(bearerToken);
        
        String productSpecificationRequestStr = mapper.writeValueAsString(productOfferingGroupSearchRequest);
        return epcAmdocsHost.postRequest(productSpecificationRequestStr,headers, searchuri, AmdocsConstants.PRODUCT_OFFER_GROUP_SEARCH)
        //return genericWebClient.callPostApi(bearerToken, epcConfiguration.getAmdocsSearchApi(env), productOfferingGroupSearchRequest, JsonNode.class, AmdocsConstants.PRODUCT_OFFER_GROUP_SEARCH)
                .flatMap(searchResponseStr -> {
                    try {
                        JsonNode searchResponse = getObjFromStr(searchResponseStr, mapper, JsonNode.class);
                        String pogDocumentId = retrieveDocumentId(searchResponse);
                        if (pogDocumentId.isEmpty()) {
                            return null;  // Return empty response if no POG found
                        }
                        productOfferingGroupRequest.getIds().get(0).setId(pogDocumentId);
                        String productOfferingGroupRequestStr = mapper.writeValueAsString(productOfferingGroupRequest);

                        //return genericWebClient.callPostApi(bearerToken, epcConfiguration.getAmdocsProductApi(env), productOfferingGroupRequest, JsonNode.class, AmdocsConstants.PRODUCT_OFFERING_GROUP);
                        return epcAmdocsHost.postRequest(productOfferingGroupRequestStr,headers, searchProductUri, AmdocsConstants.PRODUCT_OFFERING_GROUP)
                                .flatMap(res-> getMonoObjFromStr(res, mapper, JsonNode.class));

                    } catch (JsonProcessingException e) {
                        throw new RuntimeException(e);
                    }

                }).onErrorResume(e -> {
                    log.error("Error occurred while calling Product Offer group search api call:", e);
                    return Mono.error(new CustomThrowableException("Error occurred while calling Product Offer group search api call", e));
                });
    }

    public String retrieveDocumentId(JsonNode amdocsSearchResponse) {
        JsonNode documentList = getJsonNodeList(amdocsSearchResponse, "documents", 0, "document");
        if (null != documentList && documentList.size() > 0) {
            for (int i = 0; i < documentList.size(); i++) {
                String entityTypeValue = getValue(documentList.get(i), "/entityType");
                if (AmdocsConstants.PRODUCT_OFFERING_GROUP.equalsIgnoreCase(entityTypeValue)) {
                    return getValue(documentList.get(i), "/documentMetaData/documentID");
                }
            }
        }
        return StringUtils.EMPTY;
    }

    public Mono<JsonNode> fetchPriceRecords(JsonNode poResponse, String bearerToken, String env) {
        try {
            String entityTypeValue = getValue(poResponse, "/documents/0/entityType");
            String productOfferingPriceId = null;
            if (entityTypeValue != null && entityTypeValue.length() > 0) {
                productOfferingPriceId = getValue(poResponse, "/documents/0/document/productOfferingPrice/0/id");
            }
            Map<String, String> pathParams = new HashMap<>();
            pathParams.put("id", productOfferingPriceId);

            MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();
            queryParams.put(LEVEL, Arrays.asList(WORKSTREAM));

            Map<String, String> headers = populateHeadersWithToken(bearerToken);

            //return genericWebClient.callPostApi(bearerToken, productOfferingPriceUrl, null, JsonNode.class, AmdocsConstants.PRODUCT_OFFER_PRICE);
            return epcAmdocsHost.postRequestWithParams(pathParams, queryParams,"",headers, popUri, AmdocsConstants.PRODUCT_OFFER_PRICE)
                    .flatMap(res -> getMonoObjFromStr(res, mapper, JsonNode.class));

        } catch (Exception e) {
            return Mono.error(new CustomThrowableException("Unexpected error in fetch from Price Records", e));
        }
    }

    public static String getValue(JsonNode jsonNode, String jsonPath) {
        if (jsonNode == null) {
            return null;
        }
        JsonNode valueNode = jsonNode.at(jsonPath);
        String value;
        if (valueNode.isArray() && valueNode.size() > 0) {
            value = String.valueOf(valueNode.get(0).get("id"));
        } else {
            value = valueNode.isMissingNode() ? null : valueNode.asText();
        }
        return value;
    }

    public static JsonNode getJsonNodeList(JsonNode jsonNode, String key, int index, String fieldName) {
        if (jsonNode == null || !jsonNode.has(key)) {
            return null;
        }
        JsonNode valueNode = jsonNode.get(key);
        if (valueNode.isArray() && index > 0 && index < valueNode.size()) {
            JsonNode arrayElement = valueNode.get(index);
            if (fieldName != null && arrayElement.has(fieldName)) {
                return arrayElement.get(fieldName);
            }
            return arrayElement;
        }
        return valueNode;
    }

    public ProductOfferSearchRequest createSearchRequest(String sorId) {
        try {
            ProductOfferSearchRequest request = JsonToObjectConverter.jsonToObject(AmdocsConstants.AMDOCS_DOCUMENT_SEARCH_JSON, ProductOfferSearchRequest.class);
            request.getItem().getOr().get(0).setText("\"" + sorId + "\"");
            request.getItem().getOr().get(1).getCriteria().getFilterCondition().getCondition().getValues().set(0, sorId);
            log.info("Product Offer Search request is {}", request);
            return request;
        } catch (Exception e) {
            log.error("Error creating search request:", e);
            throw new CustomThrowableException("Failed to create search request", e);
        }
    }


    public Mono<JsonNode> getEPCDataForPromo(String sedId, String env) throws ConverterException, JsonProcessingException {
        log.info("getTokenAPIAPI called");
        Mono<Token> tokenMono = tokenService.getTokenHttpService();
        return tokenMono.flatMap(token -> {
            String bearerToken = CommonConstants.BEARER + token.getToken();
            log.info("Bearer token generated is {} environment", bearerToken);
            try {
                ProductOfferSearchRequest productOfferSearchRequest = createSearchRequestForPromotions(sedId);
                return fetchPromotionsC1Id(bearerToken, env, productOfferSearchRequest);
            } catch (Exception e) {
                log.error("Error occurred in productOffering call", e);
                return Mono.error(new CustomThrowableException("Unexpected error in fetch from Product Offering", e));
            }
        }).onErrorResume(e -> {
            log.error("Error occurred while generating token in TokenService:", e);
            return Mono.error(new CustomThrowableException("Unexpected error in generating token", e));
        });
    }

    public ProductOfferSearchRequest createSearchRequestForPromotions(String sedId) {
        try {
            ProductOfferSearchRequest request = JsonToObjectConverter.jsonToObject(AmdocsConstants.AMDOCS_DOCUMENT_SEARCH_JSON, ProductOfferSearchRequest.class);
            request.getItem().getOr().get(0).setText("\"" + sedId + "\"");
            request.getItem().getOr().get(0).setTypes(Arrays.asList(PROD_TYPE_PROMOTION));
            request.getItem().getOr().get(1).getCriteria().getFilterCondition().getCondition().getValues().set(0, sedId);
            request.getItem().getOr().get(1).setTypes(Arrays.asList(PROD_TYPE_PROMOTION));
            request.getItem().getFilter().getAnd().get(0).getAnd().get(0).setValues(Arrays.asList("Promotion"));
            log.info("Promo Offer Search request is {}", request);
            return request;
        } catch (Exception e) {
            log.error("Error creating promo search request:", e);
            throw new CustomThrowableException("Failed to create search request", e);
        }
    }
    public Mono<JsonNode> fetchPromotionsC1Id(String bearerToken, String env, ProductOfferSearchRequest amdocsSearchRequest) throws JsonProcessingException {
        log.info("fetchPromotionsC1Id called to get doc ID");
        Map<String, String> headers = populateHeadersWithToken(bearerToken);
        
        String amdocsSearchRequestStr = convertObjToString(amdocsSearchRequest, mapper);
        // return genericWebClient.callPostApi(bearerToken, epcConfiguration.getAmdocsSearchApi(env), amdocsSearchRequest, JsonNode.class, AmdocsConstants.PROMO_OFFER_SEARCH)
        return epcAmdocsHost.postRequest(amdocsSearchRequestStr,headers, searchuri,  AmdocsConstants.PROMO_OFFER_SEARCH)
                .flatMap(response -> {
                    JsonNode docIDResp;
                    try {
                        docIDResp = getObjFromStr(response, mapper, JsonNode.class);
                        log.info("Response from epc search call  is {}", docIDResp);
                        String documentID = getValue(docIDResp, "/documents/0/documentMetaData/documentID");
                        return fetchPromotionDetails(bearerToken, env, documentID);
                    } catch (Exception e) {
                        return Mono.error(new CustomThrowableException("Unexpected error during promotions call", e));
                    }
                }).onErrorResume(e -> {
                    log.error("Error occurred while calling Promotions Search api:", e);
                    return Mono.error(new CustomThrowableException("Error occurred while calling Product Offer Search api", e));
                });
    }



    public Mono<JsonNode> fetchPromotionDetails(String bearerToken, String env, String documentID){
        Map<String, String> pathParams = new HashMap<>();
        pathParams.put(DOCUMENT_ID, documentID);

        MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();
        queryParams.put(LEVEL, Arrays.asList(WORKSTREAM));

        Map<String, String> headers = populateHeadersWithToken(bearerToken);
        //return genericWebClient.callGetApi(bearerToken, epcProperties.getAmdocsHost().getBaseUrl(), epcProperties.getAmdocsHost().getPromotionsUri(), pathParams, queryParams, JsonNode.class)
       return amdocsPromotion.get(pathParams, queryParams, headers, PROMOTIONS)
        .flatMap(promotionsStr -> {
            try {
                log.info("Promotions call response is {}", promotionsStr);

                JsonNode promotions = getObjFromStr(promotionsStr, mapper, JsonNode.class);
                String promotionPriceAlterationID = getValue(promotions, "/action/0/promotionPriceAlteration/id");
                log.info("promotionPriceAlterationID from Promotions call response is {}", promotionPriceAlterationID);
                return fetchDiscountPriceRecords(promotionPriceAlterationID, bearerToken, env, promotions);
            } catch (ConverterException e) {
                return Mono.error(new CustomThrowableException("Unexpected error in fetch from Product Offering", e));
            }
        }).onErrorResume(e -> {
            log.error("Error occurred while calling Promotions api:", e);
            return Mono.error(new CustomThrowableException("Error occurred while calling Product Offer  api", e));
        });
    }

    public Mono<JsonNode> fetchDiscountPriceRecords(String promotionPriceAlterationID, String bearerToken, String env, JsonNode promotions) throws ConverterException {
        log.info("Inside fetchDiscountPriceRecords method");
        ProductOfferingRequest priceReq = JsonToObjectConverter.jsonToObject(AmdocsConstants.AMDOCS_PRODUCT_SPECIFICATION_JSON, ProductOfferingRequest.class);
        priceReq.getIds().get(0).setId(promotionPriceAlterationID);
        priceReq.getIds().get(0).setType("price");
        try {
            Map<String, String> headers = populateHeadersWithToken(bearerToken);

            Map<String, String> pathParams = new HashMap<>();
            pathParams.put(ID, promotionPriceAlterationID);

            MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();
            queryParams.put(LEVEL, Arrays.asList(WORKSTREAM));

            
            String priceReqStr = mapper.writeValueAsString(priceReq);
            //Mono<JsonNode> priceResponseMono = genericWebClient.callPostApi(bearerToken, epcConfiguration.getAmdocsProductApi(env), priceReq, JsonNode.class, AmdocsConstants.PRODUCT_OFFER_PRICE);
            Mono<JsonNode> priceResponseMono = epcAmdocsHost.postRequest(priceReqStr,headers,searchProductUri, AmdocsConstants.PRODUCT_OFFER_PRICE)
                    .flatMap(priceRes -> getMonoObjFromStr(priceRes, mapper, JsonNode.class));

            //Mono<JsonNode> priceRecordMono = genericWebClient.callPostApiWithPathAndQueryParam(bearerToken,  epcProperties.getAmdocsHost().getBaseUrl() , epcProperties.getAmdocsHost().getPriceUri(), null,pathParams, queryParams ,JsonNode.class, AmdocsConstants.PRODUCT_OFFER_PRICE);
            Mono<JsonNode> priceRecordMono = amdocsPriceRecords.postRequestWithParams(pathParams, queryParams, "", headers,null, AmdocsConstants.PRODUCT_OFFER_PRICE)
                    .flatMap(priceRecordRes -> getMonoObjFromStr(priceRecordRes, mapper, JsonNode.class));
            return Mono.zip(priceResponseMono, priceRecordMono).flatMap(priceRes ->{
                log.info("Prices response : {}", priceRes.getT1());
                log.info("PriceRecord response : {}", priceRes.getT2());
                ObjectMapper objectMapper = new ObjectMapper();
                ObjectNode combinedNodes = objectMapper.createObjectNode();
                combinedNodes.set(AmdocsConstants.PROMOTIONS, promotions);
                combinedNodes.set(AmdocsConstants.PRICES, priceRes.getT1());
                return Mono.just(combinedNodes);
            });
        } catch (Exception e) {
            return Mono.error(new CustomThrowableException("Unexpected error in fetch from Price Records", e));
        }
    }



}
