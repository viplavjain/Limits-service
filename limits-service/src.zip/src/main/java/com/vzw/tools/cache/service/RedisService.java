package com.vzw.tools.cache.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonParser;
import com.vzw.tools.cache.configuration.RedisConfiguration;
import com.vzw.tools.cache.constant.RedisConstants;
import com.vzw.tools.cache.dto.RedisAccessoryDto;
import com.vzw.tools.cache.dto.RedisDeviceDto;
import com.vzw.tools.cache.model.RedisModel;
import com.vzw.tools.common.exception.CustomException;
import com.vzw.tools.common.exception.ErrorBuilder;
import com.vzw.tools.common.exception.ExceptionHandler;
import com.vzw.tools.common.exception.XmlConversionException;
import com.vzw.tools.common.util.CommonUtil;
import com.vzw.tools.source.configuration.RunTimeMapInitializer;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.core.BoundValueOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.lang.reflect.Field;
import java.util.*;
import java.util.stream.Collectors;

import static com.vzw.tools.cache.constant.RedisConstants.*;
import static com.vzw.tools.common.constant.CommonConstants.EMPTY_STRING;

@Slf4j
@Service
public class RedisService {

    @Autowired
    RunTimeMapInitializer runTimeMapInitializer;

    private final Environment environment;

    private final RedisConfiguration redisConfiguration;

    private final ErrorBuilder errorBuilder;

    public RedisService(Environment environment, RedisConfiguration redisConfiguration, ErrorBuilder errorBuilder) {
        this.environment = environment;
        this.redisConfiguration = redisConfiguration;
        this.errorBuilder = errorBuilder;
    }

    public Mono<Object> redisData(String id, String productType, String env) {
        log.info("getRedisData() begins for sorId:{}", id);
        String data = EMPTY_STRING;
        ObjectMapper objectMapper = new ObjectMapper();
        return retrieveRedisData(id, productType, env, data)
                .flatMap(responseList -> {
                    List<Object> responses = responseList.stream().map(item -> {
                        Object jsonObj;
                        try {
                            jsonObj = objectMapper.readValue(item, Object.class);

                        } catch (JsonProcessingException e) {
                            return Mono.error(errorBuilder.buildApplicationException(e));
                        }
                        return jsonObj;
                    }).collect(Collectors.toList());
                    log.info("getRedisData() ends for sorId:{}", id);
                    return Mono.just(responses);
                });
    }

    public RedisModel loadRedisData(String env, String assetName, String id) {
        RedisTemplate<Object, Object> redisTemplate = redisConfiguration.getRedisTemplatesForEnvs(env);
        RedisModel model = new RedisModel();
        model.setEnv(env);
        produceRedisModel(model, assetName, id, redisTemplate);
        return model;
    }

    private void produceRedisModel(RedisModel redisModel, String assetName, String id,
                                   RedisTemplate<Object, Object> redisTemplate) {
        redisModel.setAssetName(assetName);
        redisModel.setId(id.trim());
        String primaryKeyPrefix = getPrimaryKeyPrefix(assetName);
        String secondaryKey = getSecondaryKeyPrefix(assetName);
        if (StringUtils.isNotEmpty(secondaryKey)) {
            String key = primaryKeyPrefix + COLON + id.trim() + COLON + secondaryKey;
            redisModel.setPrimaryKey(key);
            BoundValueOperations<Object, Object> valueOps = redisTemplate.boundValueOps(key);
            String data = (String) valueOps.get();
            if (data != null && data.isEmpty()) {
                redisModel.setMessage(RedisConstants.INVALID_MSG);
            } else {
                redisModel.setData(data);
            }
        } else {
            String primaryKey = primaryKeyPrefix + COLON + id.trim();
            redisModel.setPrimaryKey(primaryKey);
            Set<Object> secondaryKeys = redisTemplate.opsForHash().keys(primaryKey);
            List<Object> keyList = Arrays.asList(secondaryKeys.toArray());
            redisModel.setHashKeyList((keyList));
            if (CollectionUtils.size(keyList) == ZERO) {
                redisModel.setMessage(RedisConstants.INVALID_MSG);
            } else if (CollectionUtils.size(keyList) <= ONE) {
                Object value = redisTemplate.opsForHash().get(primaryKey, keyList.get(ZERO));
                if (value != null && StringUtils.isNotEmpty(value.toString())) {
                    String output = JsonParser.parseString(value.toString()).toString();
                    redisModel.setData(output);
                } else {
                    redisModel.setMessage(RedisConstants.INVALID_MSG);
                }
            }
        }
    }

    public String getPrimaryKeyPrefix(String assetName) {
        return environment.getProperty(String.format(PRIMARY_KEY_FORMAT, assetName));
    }

    private String getSecondaryKeyPrefix(String assetName) {
        return environment.getProperty(String.format(SECONDARY_KEY_FORMAT, assetName));
    }

    public RedisModel fetchRedisDataForID(String assetName, String id, String env, String hashKey) {
        RedisTemplate<Object, Object> redisTemplate = redisConfiguration.getRedisTemplatesForEnvs(env);
        RedisModel model = new RedisModel();
        model.setEnv(env);
        model.setAssetName(assetName);
        model.setId(id);
        model.setSecHash(hashKey);
        produceRedisModelForHashKey(model, assetName, id, hashKey, redisTemplate);
        return model;
    }

    public String fetchID(String data, String productType) {
        String result = NO_DATA;
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            if (!EMPTY_STRING.equalsIgnoreCase(data)) {
                Map<String, Object> responseData = objectMapper.readValue(data, Map.class);
                if (productType.equalsIgnoreCase(DEVICE)) {
                    if (responseData.containsKey(PRODUCT_ID_MAP)) {
                        Map<String, Object> productIdMap = (Map<String, Object>) responseData.get(PRODUCT_ID_MAP);
                        if (productIdMap.containsKey(POST_PAY_PRODUCT)) {
                            result = (String) productIdMap.get(POST_PAY_PRODUCT);
                            log.info("postPayProduct id is :" + result);
                        } else {
                            log.info("postPayProduct Key is missing in productMap");
                            result = null;
                        }
                    } else {
                        log.info("productIdMap is missing in response");
                        result = null;
                    }
                } else if (responseData.containsKey(PARENT_PRODUCT)) {
                    List<String> parentProductList = (List<String>) responseData.get(PARENT_PRODUCT);
                    if (parentProductList != null && !parentProductList.isEmpty()) {
                        result = parentProductList.get(parentProductList.size() - 1);
                    }
                } else {
                    log.info("parentProducts is missing in productMap");
                    result = null;
                }
            }
        } catch (CustomException ex) {
            return ExceptionHandler.handleIdNotFoundException(ex);
        } catch (JsonProcessingException ex) {
            result = ExceptionHandler.jsonException(ex);
        }
        return result;
    }

    private void produceRedisModelForHashKey(RedisModel redisModel, String assetName, String id, String hashKey,
                                             RedisTemplate<Object, Object> redisTemplate) {

        String primaryKeyPrefix = getPrimaryKeyPrefix(assetName);
        String primaryKey = primaryKeyPrefix + COLON + id.trim();
        redisModel.setPrimaryKey(primaryKey);
        List<Object> keyList = Arrays.asList(redisTemplate.opsForHash().keys(primaryKey).toArray());
        redisModel.setHashKeyList((keyList));
        String hashValue = null;
        if (StringUtils.isNotEmpty(hashKey)) {
            redisModel.setSecondaryKey(hashKey);
            Object hashValueObj = redisTemplate.opsForHash().get(primaryKey, hashKey);
            if (hashValueObj != null)
                hashValue = hashValueObj.toString();
        }
        if (hashValue != null && hashValue.isEmpty()) {
            redisModel.setMessage(RedisConstants.INVALID_MSG);
        } else {
            redisModel.setData(hashValue);
        }
    }

    public Mono<Object> fetchRedisData(String sorId, String productType, String env) {
        List<String> responseList = new ArrayList<>();
        if (productType.equalsIgnoreCase(DEVICE)) {
            return retrieveRedisData(sorId, productType, env, EMPTY_STRING)
                    .flatMap(response -> {
                        responseList.addAll(response);
                        try {
                            return Mono.just(mapToDeviceRedisDTO(populateResponseMapIntoOne(responseList)));
                        } catch (JsonProcessingException e) {
                            return Mono.error(errorBuilder.buildApplicationException(e));
                        }
                    });
        } else if (productType.equalsIgnoreCase(ACCESSORY)) {
            return retrieveRedisData(sorId, productType, env, EMPTY_STRING)
                    .flatMap(response -> {
                        responseList.addAll(response);
                        try {
                            return Mono.just(mapToAccessoryRedisDTO(populateResponseMapIntoOne(responseList)));
                        } catch (JsonProcessingException e) {
                            return Mono.error(errorBuilder.buildApplicationException(e));
                        }
                    });
        }
        return Mono.empty();
    }

    private Map<String, String> populateResponseMapIntoOne(List<String> responseList) {
        List<Map<String, String>> responseMapList = new ArrayList<>();
        Map<String, String> responseMap = new HashMap<>();
        responseMap.put(DATA, responseList.get(ZERO));
        responseMap.put(RESPONSE, responseList.get(ONE));
        responseMapList.add(responseMap);
        return concatenateMapsIntoOne(responseMapList);
    }

    private Mono<List<String>> retrieveRedisData(String id, String productType, String env, String data) {
        List<String> responseList = new ArrayList<>();
        String productData;
        RedisModel redismodel;
        if (productType.equalsIgnoreCase(DEVICE)) {
            productType = DEVICE_CATALOG;
        }
        if (productType.equalsIgnoreCase(ACCESSORY)) {
            productType = ACCESSORY_CATALOG;
        }
        redismodel = loadRedisData(env, productType, id);
        for (Object secKey : redismodel.getHashKeyList()) {
            if (secKey.toString().contains(SKU) && !secKey.toString().contains(SAP_PRICE)) {
                redismodel = fetchRedisDataForID(productType, id, env, secKey.toString());
                data = redismodel.getData();
            } else {
                redismodel.setErrorMsg(FETCH_DATA_FAILED);
            }
        }
        String productId = fetchID(data, productType);
        if (id != null && !id.isEmpty()) {
            if (productType.equalsIgnoreCase(DEVICE_CATALOG)) {
                productType = DEVICE_PRODUCT_CATALOG;
            }
            if (productType.equalsIgnoreCase(ACCESSORY_CATALOG)) {
                productType = ACCESSORY_PRODUCT_CATALOG;
            }
            RedisModel redisIdModel = loadRedisData(env, productType, productId);
            productData = redisIdModel.getData();
            responseList.add(productData);
        }
        responseList.add(data);
        return Mono.just(responseList);
    }


    public Mono<Map<String, String>> getRedisMappedJson(String sorId, String productType,String env) throws JsonProcessingException {
        return getRedisDeviceDetails(sorId, productType,env).flatMap(redisDevDet -> Mono.just(getRedisMappedJson(redisDevDet,productType)));
    }

    public Mono<Map<String, String>> getRedisAccessoryMappedJson(String sorId, String productType,String env) throws JsonProcessingException {
        return getRedisAccessoryDetails(sorId, productType,env).flatMap(redisAccDet -> Mono.just(getRedisAccessoryMappedJson(redisAccDet,productType)));
    }

    public Mono<RedisDeviceDto> getRedisDeviceDetails(String sorId, String productType, String env) throws JsonProcessingException {
        log.info("getRedisDeviceDetails API called");
        return fetchRedisData(sorId, productType, env).flatMap(response -> {
            ObjectMapper mapper = new ObjectMapper();
            log.info("The fetch call response : {}", response);
            return Mono.just(mapper.convertValue(response, RedisDeviceDto.class));
        });
    }

    private HashMap<String, String> getRedisMappedJson(RedisDeviceDto redisDto,String productType) {
        HashMap<String, String> cacheMapJson = new HashMap<>();
        try {
            HashMap<String, String> dtoCachePropertyMap = CommonUtil.getPropertiesMap(redisDto);
            HashMap<String, String> cacheMap = runTimeMapInitializer.getCacheMap(productType);
            for (Map.Entry<String, String> e : cacheMap.entrySet()) {
                String value = dtoCachePropertyMap.get(e.getValue());
                cacheMapJson.put(e.getKey(), value);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return cacheMapJson;
    }

    public Mono<RedisAccessoryDto> getRedisAccessoryDetails(String sorId, String productType, String env) throws JsonProcessingException {
        log.info("getRedisAccessoryDetails API called");
        return fetchRedisData(sorId, productType, env).flatMap(response -> {
            ObjectMapper mapper = new ObjectMapper();
            log.info("The Accessory call response : {}", response);
            return Mono.just(mapper.convertValue(response, RedisAccessoryDto.class));
        });
    }

    private HashMap<String, String> getRedisAccessoryMappedJson(RedisAccessoryDto redisAccessoryDto,String productType) {
        HashMap<String, String> cacheMapJson = new HashMap<>();
        try {
            HashMap<String, String> dtoCachePropertyMap = CommonUtil.getPropertiesMap(redisAccessoryDto);
            HashMap<String, String> cacheMap = runTimeMapInitializer.getCacheMap(productType);
            for (Map.Entry<String, String> e : cacheMap.entrySet()) {
                String value = dtoCachePropertyMap.get(e.getValue());
                cacheMapJson.put(e.getKey(), value);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return cacheMapJson;
    }

    public Map<String,String> concatenateMapsIntoOne(List<Map<String,String>> responseMapList){
        Map<String,String> result = new HashMap<>();
        for(Map<String,String> map : responseMapList){
            result.putAll(map);
        }
        return result;
    }

    public static RedisDeviceDto mapToDeviceRedisDTO(Map<String, String> concatenatedMap) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        RedisDeviceDto deviceRedisDTO = new RedisDeviceDto();
        if(null != concatenatedMap.get(DATA) && null != concatenatedMap.get(RESPONSE)){
            JsonNode skuData = mapper.readValue(concatenatedMap.get(DATA), JsonNode.class);
            JsonNode productData = mapper.readValue(concatenatedMap.get(RESPONSE), JsonNode.class);
            Iterator<Map.Entry<String, JsonNode>> fields = skuData.fields();
            Iterator<Map.Entry<String, JsonNode>> responseFields = productData.fields();
            Iterator<Map.Entry<String, JsonNode>> priceFields = productData.get(PRICE).fields();
            Iterator<Map.Entry<String, JsonNode>> imageField = productData.get(IMAGE_URL_MAP).fields();
            List<String> imageUrlList = new ArrayList<>();
            while (imageField.hasNext()) {
                Map.Entry<String, JsonNode> image = imageField.next();
                imageUrlList.add(image.getValue().asText());
            }
            populateRedisDto(deviceRedisDTO,responseFields);
            populateRedisDto(deviceRedisDTO,priceFields);
            populateRedisDto(deviceRedisDTO,fields);
            deviceRedisDTO.setImageUrlMap(imageUrlList.get(0));
        }
        return deviceRedisDTO;
    }

    public static RedisAccessoryDto mapToAccessoryRedisDTO(Map<String, String> concatenatedMap) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        RedisAccessoryDto accessoryRedisDTO = new RedisAccessoryDto();
        if(null != concatenatedMap.get(DATA) && null != concatenatedMap.get(RESPONSE)){
            JsonNode skuData = mapper.readValue(concatenatedMap.get(DATA), JsonNode.class);
            JsonNode productData = mapper.readValue(concatenatedMap.get(RESPONSE), JsonNode.class);
            Iterator<Map.Entry<String, JsonNode>> fields = skuData.fields();
            Iterator<Map.Entry<String, JsonNode>> responseFields = productData.fields();
            Iterator<Map.Entry<String, JsonNode>> priceFields = productData.get(PRICE).fields();
            Iterator<Map.Entry<String, JsonNode>> imageField = productData.get(IMAGE_URL_MAP).fields();
            List<String> imageUrlList = new ArrayList<>();
            while (imageField.hasNext()) {
                Map.Entry<String, JsonNode> image = imageField.next();
                imageUrlList.add(image.getValue().asText());
            }
            populateRedisAccessoryDto(accessoryRedisDTO,responseFields);
            populateRedisAccessoryDto(accessoryRedisDTO,fields);
            populateRedisAccessoryDto(accessoryRedisDTO,priceFields);
            accessoryRedisDTO.setImageUrlMap(imageUrlList.get(0));
        }
        return accessoryRedisDTO;
    }

    private static void populateRedisDto(RedisDeviceDto deviceRedisDTO, Iterator<Map.Entry<String, JsonNode>> fields) {
        while (fields.hasNext()) {
            Map.Entry<String, JsonNode> field = fields.next();
            String fieldName = field.getKey();
            JsonNode fieldValue = field.getValue();
            try {
                Field classField = deviceRedisDTO.getClass().getDeclaredField(fieldName);
                classField.setAccessible(true);
                switch (classField.getType().getSimpleName()) {
                    case STRING:
                        classField.set(deviceRedisDTO, fieldValue.asText());
                        break;
                    case INTEGER:
                        classField.set(deviceRedisDTO, fieldValue.asInt());
                        break;
                    case BOOLEAN:
                        classField.set(deviceRedisDTO, fieldValue.asBoolean());
                        break;
                    case DOUBLE:
                        classField.set(deviceRedisDTO, fieldValue.asDouble());
                        break;
                    case LONG:
                        classField.set(deviceRedisDTO, fieldValue.asLong());
                        break;
                    case LIST:
                        if (fieldValue.isArray()) {
                            List<String> listValue = new ArrayList<>();
                            for (JsonNode item : fieldValue) {
                                listValue.add(item.asText());
                            }
                            classField.set(deviceRedisDTO, listValue);
                        }
                        break;
                }
            } catch (NoSuchFieldException | SecurityException | IllegalAccessException ignored) {
            }
        }
    }

    private static void populateRedisAccessoryDto(RedisAccessoryDto accessoryRedisDTO, Iterator<Map.Entry<String, JsonNode>> fields) {
        while (fields.hasNext()) {
            Map.Entry<String, JsonNode> field = fields.next();
            String fieldName = field.getKey();
            JsonNode fieldValue = field.getValue();
            try {
                Field classField = accessoryRedisDTO.getClass().getDeclaredField(fieldName);
                classField.setAccessible(true);
                switch (classField.getType().getSimpleName()) {
                    case STRING:
                        classField.set(accessoryRedisDTO, fieldValue.asText());
                        break;
                    case INTEGER:
                        classField.set(accessoryRedisDTO, fieldValue.asInt());
                        break;
                    case BOOLEAN:
                        classField.set(accessoryRedisDTO, fieldValue.asBoolean());
                        break;
                    case DOUBLE:
                        classField.set(accessoryRedisDTO, fieldValue.asDouble());
                        break;
                    case LONG:
                        classField.set(accessoryRedisDTO, fieldValue.asLong());
                        break;
                    case LIST:
                        if (fieldValue.isArray()) {
                            List<String> listValue = new ArrayList<>();
                            for (JsonNode item : fieldValue) {
                                listValue.add(item.asText());
                            }
                            classField.set(accessoryRedisDTO, listValue);
                        }
                        break;
                }
            }
            catch (NoSuchFieldException | SecurityException | IllegalAccessException ignored){
              }
            }
    }
}