package com.vzw.tools.compare.constant;

import java.util.Arrays;
import java.util.List;

public class ComparatorConstant {
    public static final List<String> dateFormatFields = Arrays.asList("prepayRestrictStartDate","postpaidRestrictStartDate");

    public static final List<String> booleanFieldsFederated = Arrays.asList("buddyUpgrdEligInd","cdmaCapableInd","backupAssistCapable","gsmCapableInd"
    ,"ispuEligible","smsCapable","nfcCapable","hdVoice","wifiCalling","edgeEligibleInd","v4b","restrictToFamilyInd","nfcCompatibleFlag","numberShareCapable"
            ,"instantCredit","prepaySkuInd","e911AddrInd","dsds","btaEligiblity","globalPhone","esimOnlyInd","euiccCapable","universalFlag","billToAccountEligibleFlag"
    ,"instorepickupflag","sorPIBIndicator");

    private ComparatorConstant() {
    }
}
