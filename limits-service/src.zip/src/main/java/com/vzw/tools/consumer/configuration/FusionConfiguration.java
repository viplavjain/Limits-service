package com.vzw.tools.consumer.configuration;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;


@Data
@Configuration
@ConfigurationProperties(prefix = "spring.fusion")
public class FusionConfiguration {
    private Host host;
    private Username userName;
    private Password password;

    @Value("${spring.fusion.host.SearchBySORId}")
    private String Search_By_SOR_API_URL;

    @Data
    public static class Host {
        private String SearchBySORId;
        private String qa1;
        private String qa2;
        private String qa3;
    }

    @Data
    public static class Username {
        private String qa1;
        private String qa2;
        private String qa3;
    }

    @Data
    public static class Password {
        private String qa1;
        private String qa2;
        private String qa3;
    }


    public String getHost(String env) {
        if (env.equalsIgnoreCase("QA1")) {
            return host.getQa1();
        } else if (env.equalsIgnoreCase("QA2")) {
            return host.getQa2();
        } else if (env.equalsIgnoreCase("QA3")) {
            return host.getQa3();
        } else {
            return "";
        }
    }

    public String getUsername(String env) {
        if (env.equalsIgnoreCase("QA1")) {
            return userName.getQa1();
        } else if (env.equalsIgnoreCase("QA2")) {
            return userName.getQa2();
        } else if (env.equalsIgnoreCase("QA3")) {
            return userName.getQa3();
        } else {
            return "";
        }
    }

    public String getPassword(String env) {
        if (env.equalsIgnoreCase("QA1")) {
            return password.getQa1();
        } else if (env.equalsIgnoreCase("QA2")) {
            return password.getQa2();
        } else if (env.equalsIgnoreCase("QA3")) {
            return password.getQa3();
        } else {
            return "";
        }
    }

}
