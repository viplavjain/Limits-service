package com.vzw.tools.cache.properties;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import java.util.List;

@Data
@Configuration
@Component
public class RedisProperties {

    @Value("${spring.redis.envdisplaynames}")
    public List<String> redisEnvDisplayNames;

}
