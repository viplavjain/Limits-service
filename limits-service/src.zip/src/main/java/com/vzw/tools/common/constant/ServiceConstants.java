package com.vzw.tools.common.constant;

public class ServiceConstants {

    public static final String CASSENDRA = "Cassandra";
    public static final String ELASTIC = "elastic";
    public static final String FUSION = "fusion";
    public static final String REDIS = "redis";
    public static final String EPC = "epc";


}
