package com.vzw.tools.source.constant;

public class DeviceConstants {

    public static final String SKU = "sku";
    public static final String ONE_YEAR_PRICE = "oneYearPrice";
    public static final String TWO_YEAR_PRICE = "twoYearPrice";
    public static final String PREPAY_PRICE = "prepayPrice";
    public static final String FULL_RETAIL_PRICE = "fullRetailPrice";
    public static final String EDGE_FULL_RETAIL_PRICE = "edgeFullRetailPrice";
    public static final String IM_ACCESSORY_LIST = "imAccessoryList";
}
