package com.vzw.tools.common.constant;

public class CommonConstants {

    public static final String EPC_DEVICE_QUERY = "Select po.id as id,po.atg_product_id as atg_product_id , po.atg_sku_id as atg_sku_id ,po.sor_id as sor_id ,po.display_name as display_name ,psdevice.image_name as image_name , " +
            " podevice.preferred_term as preferred_term ,podevice.early_termination_text as early_termination_text , " +
            " psdevice.sor_product_family as sor_product_family,psdevice.prod_code_1 as prod_code_1,psdevice.prod_code_2 as PROD_CODE_2,psdevice.prod_code_3 as PROD_CODE_3,psdevice.prod_code_4 as PROD_CODE_4,psdevice.prod_code_5 as PROD_CODE_5,psprd.dacc_id as dacc_id from " +
            " VZW_EPC_PO po left outer join VZW_EPC_PS_DEVICE psdevice on po.id=psdevice.id left outer join VZW_EPC_PO_DEVICE podevice on po.id=podevice.ID " +
            " left outer join vzw_epc_device_psprd psprd on psprd.id=po.id  where po.SOR_ID =:sorid";

    public static final String DPI_PKG = "SAP_PKG_GEN_OMNI_FEED_BKUP";

    public static final String DPI_SP_DEVICE = "sp_get_dpi_feed";

    public static final String DPI_SP_ACCESSORY = "sp_get_acc_feed";

    public static final String DMD_PKG = "DMD_PKG_GEN_OMNI_FEED";

    public static final String OMP_SCHEMA = "CODE";

    public static final String SP_ACCESSORY = "sp_get_acc_info";

    public static final String SP_DEVICE = "sp_get_dev_info";

    public static final String SP_PROMOTIONS_OMP = "SP_FEDCAT_ATG_PROMOTION";

    public static final String SP_DEVICE_FAMILY = "sp_get_dev_fml_info";

    public static final String ACCESSORY_INFO = "ACCESSORY_INFO";

    public static final String DEVICE_INFO = "DEVICE_INFO";

    public static final String PROMOTIONS_INFO = "PROMOTIONS_INFO";

    public static final String ACC_SKU_LIST = "p_acc_sku_list";

    public static final String DEV_SKU_LIST = "p_device_sku_list";

    public static final String P_OFFER_ID= "P_OFFER_ID";

    public static final String P_SUB_ID= "SUB_ID";

    public static final String DATE = "p_eff_beg_dt";

    public static final String ACC_RESULT_SET = "{P_RESULT_SET=[{ACCESSORYINFO=";

    public static final String DEV_RESULT_SET = "{P_RESULT_SET=[{DEVICEINFOLIST=";

    public static final String DEV_FAMILY_RESULT_SET = "{P_RESULT_SET=[{DEVICEFAMILYINFO=";

    public static final String DPI_DEV_RESULT_SET = "{P_RESULT_SET=[";

    public static final String DPI_BRACE = "]}";

    public static final String BRACE = "}]}";

    public static final String BRACKET = "[{}]";

    public static final String COMMA = ", ";

    public static final String EQUAL = "=";

    public static final int ZERO = 0;

    public static final int ONE = 1;

    public static final int TWO = 2;

    public static final String CONTENT_TYPE = "Content-Type";

    public static final String APPLICATION_JSON = "application/json";

    public static final String P_RESULT_SET = "P_RESULT_SET";

    public static final String SKU = "SKU";
    public static final String SKU_TYPE = "SKU_TYPE";
    public static final String LOCATION_CODE = "LOCATION_CODE";
    public static final String FULL_RETAIL_PRICE = "FULL_RETAIL_PRICE";
    public static final String ONE_YEAR_PRICE = "ONE_YEAR_PRICE";
    public static final String TWO_YEAR_PRICE = "TWO_YEAR_PRICE";
    public static final String PREPAY_PRICE = "PREPAY_PRICE";
    public static final String EDGE_SKU = "EDGE_SKU";
    public static final String EDGE_FULL_RETAIL_PRICE = "EDGE_FULL_RETAIL_PRICE";
    public static final String FEDCATALOG_SP_DEVICE = "SP_FEDCATALOG_DEVICE";
    public static final String FEDCATALOG_SP_ACCESSORY = "SP_FEDCATALOG_ACCESSORY";
    public static final String FEDCATALOG_SP_PROMOTION = "SP_FEDCATALOG_PROMOTION";
    public static final String DEVICE_CONFIG_JSON = "deviceConfig.json";
    public static final String ITEMS_DEVICE = "/items/device";
    public static final String GENERIC_KEY = "genericKey";
    public static final String ITEMS_AUTHORIZATION = "/details/Authorization";
    public static final String KEY = "key";

    public static final String AUTHORIZATION_JSON_PATH = "/details/Authorization";
    public static final String SOURCE_JSON_PATH = "/details/source";
    public static final String AUTHORIZATION = "authorization";
    public static final String SOURCE = "source";
    public static final String CONFIG_JSON = "deviceConfig.json";
    public static final String BEARER = "Bearer ";
    public static final String COLON = ":";
    public static final String PROD_TYPE_DEVICE = "Device";
    public static final String PROD_TYPE_ACCESSORY = "Accessory";
    public static final String PROD_TYPE_PROMOTION ="Promotion";
    public static final String DATE_FORMAT = "MM/dd/yyyy";
    public static final String UTC = "UTC";
    public static final String TRUE = "true";
    public static final String FALSE = "false";
    public static final String Y = "Y";
    public static final String N = "N";
    public static final String EPCREP_SCHEMA = "EPCREP";
    public static final String P_SOR_ID = "p_sor_id";
    public static final String STRING_DOT = ".";
    public static final String EMPTY_STRING = "";
    public static final double MEMORY_THRESHOLD_PERCENT= 0.9;
    public static final String ENCRYPTIONINTVEC =  "encryptionIntVec";
    public static final String AESENCRYTIONKEY = "aesEncryptionKey";
    public static final String CIPHER_INSTANCE = "AES/CBC/PKCS5PADDING";
    public static final String REDIS = "Redis";
    public static final String PERSISTENCE_JSON_PATH = "/details/Persistence";

    public static final String ELASTICSEARCH_JSON_PATH = "/details/Cache";
    public static final String ELASTICSEARCH = "ElasticSearch";

    public static final String CONSUMER_JSON_PATH = "/details/Consumer";

    public static final String CACHE_JSON_PATH = "/details/Cache";
    public static final String PERSISTENCE = "Persistence";
    public static final String FEDERATEDCATALOG = "FederatedDB";
    public static final String CACHE = "Cache";
    public static final String DMD = "DMD";
    public static final String DPI = "DPI";
    public static final String EPC = "EPC";
    public static final String CASSANDRA = "Cassandra";
    public static final String FEDERATED = "Federated";
    public static final String FUSION = "Fusion";
    public static final String CXP_CATALOG = "CXPCatalogDomain";
    public static final String SYSTEM = "system";
    public static final String ERROR_MESSAGE = "errorMessage";
    public static final String ACCESSORIES_JSON = "accessoriesConfig.json";
    public static final String AUTHORIZATION_ACCS = "authorization_accs";
    public static final String SOURCE_ACCS = "source_accs";
    public static final String PERSISTENCE_ACCS = "Persistence_accs";
    public static final String CACHE_ACCS = "Cache_accs";
    public static final String FEDERATEDCATALOG_ACCS = "federatedCatalog_accs";
    public static final String FUSION_ACCS = "Fusion_accs";
    public static final String CXP_CATALOG_ACCS = "CXP_Catalog_accs";
    public static final String ACCESSORIES_DEVICE = "/items/accessories";
    public static final String PRODUCT_UNIVERSAL_ACCESSORIES = "productUniversalAccessories";
    public static final String CARRIER = "carrier";
    public static final String MANUFACTURER = "manufacturer";
    public static final String OPERATING_SYSTEM = "operatingSystem";
    public static final String DISPLAY_NAME = "displayName";
    public static final String DATA = "data";
    public static final String VALUE = "value";
    public static final String NAME = "name";
    public static final String ELASTICSEARCH_ACCS = "ElasticSearch_accs";
    public static final String API_TIME_OUT = "API timed out";

    public static final String FED_CATALOG_JDBC_TEMPLATE = "fedCatalogJdbcTemplate";
    public static final String SORID = "sorid";
    public static final String EXTERNAL_ID = "externalId";
    public static final String OWNER = "owner";
    public static final String TYPE = "type";
    public static final String ID = "id";
    public static final String DESCRIPTION = "description";
    public static final String DOCUMENT = "document";
    public static final String PARAMETER = "parameter";
    public static final String DUTY_FREE_AMOUNT = "dutyFreeAmount";
    public static final String PRODUCT_OFFER_PRICE = "productOfferPrice";
    public static final String VZ_PRICE_TYPE = "vz_price_type";
    public static final String CHARACTERISTICS = "characteristics";

    public static final String PRODUCT_DISPLAY_NAME = "productDisplayName";
    public static final String PRODUCT_OFFER = "productOffer";
    public static final String PRODUCT_OFFER_GROUP = "productOfferGroup";
    public static final String DOCUMENTS_0 = "documents0";
    public static final String POLICY = "policy";
    public static final String PRODUCT_OFFER_GROUP_NAME = PRODUCT_OFFER_GROUP + STRING_DOT + DOCUMENTS_0 + STRING_DOT + DOCUMENT + NAME;
    public static final String PRODUCT_OFFER_GROUP_POLICY = PRODUCT_OFFER_GROUP + STRING_DOT + DOCUMENTS_0 + STRING_DOT + DOCUMENT + POLICY;
    public static final String PRODUCT_SPECIFICATION_SKU = "productSpecificationSku";
    public static final String PRODUCT_SPEC_CHARACTERISTIC = "productSpecCharacteristic";
    public static final String LOCALIZED_VALUE_0 = "localizedValue0";
    public static final String PROD_SPEC_CHAR_VALUE_0 = "productSpecCharacteristicValue0";
    public static final String PRODUCT_SPEC_CHAR_LOCAL_VALUE = PROD_SPEC_CHAR_VALUE_0 + STRING_DOT + LOCALIZED_VALUE_0 + STRING_DOT + VALUE;

    public static final String CHARACTERISTIC_VALUE_0 = "characteristicValue0";
    public static final String CHARACTERISTIC_LOCAL_VALUE = CHARACTERISTIC_VALUE_0 + STRING_DOT + LOCALIZED_VALUE_0 + STRING_DOT + VALUE;

    public static final String SKU_DISPLAY_NAME = "skuDisplayName";
    public static final String DOCUMENT_NAME = "documentName";
    public static final String DEVICE_SKU = "deviceSku";
    public static final String DEVICE_SKU_LIST = "deviceSkuList";
    public static final String DEVICE_SKU_INFO = "deviceSkuInfo";
    public static final String MARKETING_COMPATIBLES_IM_SKU_LIST = "marketingCompatibleSimSkuList";
    public static final String UNIVERSAL_PROP_CD_LIST = "universalPropCdList";
    public static final String UNIVERSAL_PROP_CD = "universalPropCd";


    private CommonConstants() {
    }
}



