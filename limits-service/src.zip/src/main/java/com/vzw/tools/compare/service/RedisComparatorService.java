package com.vzw.tools.compare.service;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.vzw.tools.cache.properties.RedisProperties;
import com.vzw.tools.cache.service.RedisService;
import com.vzw.tools.common.constant.CommonConstants;
import com.vzw.tools.common.entity.*;
import com.vzw.tools.common.exception.*;
import com.vzw.tools.common.util.CommonUtil;
import com.vzw.tools.persistence.service.CassandraService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.*;

import static com.vzw.tools.cache.constant.RedisConstants.DEVICE;
import static com.vzw.tools.common.util.CommonUtil.isMatchedObjects;

@Slf4j
@Service
public class RedisComparatorService {

    private final CassandraService cassandraService;
    private final RedisService redisService;

    private final ErrorBuilder errorBuilder;

    private final RedisProperties redisProperties;

    @Autowired
    RedisComparatorService(CassandraService cassandraService, RedisService redisService, ErrorBuilder errorBuilder, RedisProperties redisProperties) {
        this.cassandraService = cassandraService;
        this.redisService = redisService;
        this.errorBuilder = errorBuilder;
        this.redisProperties = redisProperties;
    }

    public Mono<Map<String, String>> getCacheMappedJson(String sorId, String productType, String env) {

        if(productType.equalsIgnoreCase(DEVICE)){
            try {
                return redisService.getRedisMappedJson(sorId, productType, env)
                        .flatMap(cacheBaseMap -> Mono.just(CommonUtil.getFormattedMap(cacheBaseMap)));
            } catch (JsonProcessingException e) {
                return Mono.error(errorBuilder.buildApplicationException(e));
            }
        } else {
            try {
                return redisService.getRedisAccessoryMappedJson(sorId, productType, env)
                        .flatMap(cacheBaseMap -> Mono.just(CommonUtil.getFormattedMap(cacheBaseMap)));
            } catch (JsonProcessingException e) {
                return Mono.error(errorBuilder.buildApplicationException(e));
            }
        }
    }

    private EntityDetails getEntityDetails(Map<String, String> persistenceMap, List<Map<String, String>> cacheMapList) {
        if (isErrorMap(persistenceMap))
            return new EntityDetails();
        EntityDetails entityDetails = new EntityDetails();
        List<EntityRowDetails> entityRowDetails = new LinkedList<>();
        for (String key : persistenceMap.keySet()) {
            Map<String, String> details = new LinkedHashMap<>();
            String persistenceVal = persistenceMap.get(key);
            Object[] compareVals = new Object[cacheMapList.size() + 1];
            compareVals[0] = persistenceVal;
            details.put(CommonConstants.CASSANDRA, persistenceVal);
            for (int i = 0; i < cacheMapList.size(); i++) {
                compareVals[i + 1] = cacheMapList.get(i).get(key);
                details.put(redisProperties.getRedisEnvDisplayNames().get(i), cacheMapList.get(i).get(key));
            }
            boolean isMatched = isMatchedObjects(compareVals);
            EntityRowDetails entityRowDetail = new EntityRowDetails();
            entityRowDetail.setIsMatch(isMatched);
            entityRowDetail.setField(key);
            entityRowDetail.setDetails(details);
            entityRowDetails.add(entityRowDetail);
        }

        entityDetails.setEntityRowDetails(entityRowDetails);
        return entityDetails;
    }

    private CompareSummary getCompareSummary(Map<String, String> persistenceMap, List<Map<String, String>> cacheMap) {
        CompareSummary compareSummaryObj = new CompareSummary();
        List<String> env = redisProperties.getRedisEnvDisplayNames();
        Deque<String> queue = new ArrayDeque<>(env);
        List<CompareDetails> compareSummary = new ArrayList<>();
        for(Map<String, String> map : cacheMap){
            compareSummary.add(getCompareDetails(CommonConstants.CASSANDRA, queue.pop(), persistenceMap, map));
        }
        compareSummaryObj.setCompares(compareSummary);
        return compareSummaryObj;
    }

    private CompareDetails getCompareDetails(String source, String target, Map<String, String> sourceMap, Map<String, String> targetMap, Class<?>... classes) {
        CompareDetails compareEPCItem = new CompareDetails();
        compareEPCItem.setSource(source);
        compareEPCItem.setTarget(target);
        if(isErrorMap(sourceMap) || isErrorMap(targetMap)){
            compareEPCItem.setIsMatch(Boolean.FALSE);
            return compareEPCItem;

        }
        compareEPCItem.setIsMatch(CommonUtil.isMapMatched(sourceMap, targetMap, classes));
        return compareEPCItem;
    }

    private boolean isErrorMap(Map<String, String> map){
        return map.containsKey(CommonConstants.ERROR_MESSAGE);
    }

    public Mono<Map<String, String>> getPersistenceMappedJson1(String sorId, String productType, String env){

        return cassandraService.getCassandraMap(sorId, productType, env).
                flatMap(persistentBaseMap -> Mono.just(CommonUtil.getFormattedMap(persistentBaseMap)));

    }

    public Mono<EntityResponse> compare(String sorId, String productType, String env) {
       Mono<Map<String, String>> persistMono = handleException(getPersistenceMappedJson1(sorId, productType, env), CommonConstants.PERSISTENCE);
       List<String> cacheEnvList = redisProperties.getRedisEnvDisplayNames();
       Flux<Map<String, String>> cacheMapList = Flux.empty();
       for(String environment : cacheEnvList){
           cacheMapList = Flux.concat(cacheMapList, handleException(getCacheMappedJson(sorId, productType, environment), CommonConstants.CACHE));
       }
        return Mono.zip(persistMono, cacheMapList.collectList()).flatMap(result -> {
            EntityResponse entityResponse = new EntityResponse();
            DataFlow dataFlow = new DataFlow();
            entityResponse.setFlow(dataFlow);
            entityResponse.setCompareSummary(getCompareSummary(result.getT1(), result.getT2()));
            entityResponse.setEntityDetails(getEntityDetails(result.getT1(), result.getT2()));
            entityResponse.setErrorDetails(getErrorDetails(result.getT1(), result.getT2()));
            return Mono.just(entityResponse);
        });
    }

    private Mono<Map<String, String>> handleException(Mono<Map<String, String>> resultMono, String system){
        return resultMono.onErrorResume(err -> {
            Map<String, String> resp = new HashMap<>();
            if (err instanceof FCToolsMSException fcToolsMSException)
                resp.put(CommonConstants.ERROR_MESSAGE, fcToolsMSException.getErrorResponse().getMessage());
            else
                resp.put(CommonConstants.ERROR_MESSAGE, err.getMessage());
            resp.put(CommonConstants.SYSTEM, system);
            return Mono.just(resp);
        });
    }

    private List<ErrorDetails> getErrorDetails(Map<String, String> persistenceMap, List<Map<String, String>> cacheMap) {
        List<ErrorDetails> errorDetailsList = new ArrayList<>();
        if(persistenceMap.containsKey(CommonConstants.ERROR_MESSAGE)) {
            errorDetailsList.add(new ErrorDetails(CommonConstants.PERSISTENCE, persistenceMap.get(CommonConstants.ERROR_MESSAGE)));
        }
        for(Map<String, String> map : cacheMap){
            if(map.containsKey(CommonConstants.ERROR_MESSAGE)){
                errorDetailsList.add(new ErrorDetails(CommonConstants.CACHE, map.get(CommonConstants.ERROR_MESSAGE)));
         }
        }
        return errorDetailsList;
    }

}