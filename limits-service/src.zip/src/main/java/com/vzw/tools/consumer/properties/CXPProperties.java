package com.vzw.tools.consumer.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

@Configuration
@ConfigurationProperties(prefix = "spring.cxp")
@Data
public class CXPProperties {

    private Map<String,String> apiUrl;
    private String apiKey;
}
