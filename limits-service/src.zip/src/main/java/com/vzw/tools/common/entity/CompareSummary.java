package com.vzw.tools.common.entity;

import lombok.Data;

import java.util.List;

@Data
public class CompareSummary {

    private List<CompareDetails> compares;
}
