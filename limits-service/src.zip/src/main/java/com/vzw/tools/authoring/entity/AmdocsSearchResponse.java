package com.vzw.tools.authoring.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class AmdocsSearchResponse {
    private String type;
    private List<Document> documents;
    private Count count;
    private Object paths; // Can be null or a specific type based on actual data

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<Document> getDocuments() {
        return documents;
    }

    public void setDocuments(List<Document> documents) {
        this.documents = documents;
    }

    public Count getCount() {
        return count;
    }

    public void setCount(Count count) {
        this.count = count;
    }

    public Object getPaths() {
        return paths;
    }

    public void setPaths(Object paths) {
        this.paths = paths;
    }

    @Getter
    @Setter
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Document {
        private String entityType;
        private DocumentMetaData documentMetaData;
        private boolean deleted;

        @Getter
        @Setter
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class DocumentMetaData {
            private LocalDateTime lastModifiedDateTime;
            private String lastModifiedUser;
            private String documentID;
            private String documentLevel;
            private List<String> documentName;
            private String sharedStatus;
            private String publishedStatus;
            private String productionStatus;
            private String coreStatus;
            private String businessEntityType;
            private String originalEntityType;
            private String customEntityType;
            private String baseBusinessRequestID;
            private String mergeBusinessRequestID;
            private String rootID;
            private String rootEntityType;
            private String rootIndexType;
            private String baseStatus;
            private String code;
        }
    }

    @Getter
    @Setter
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Count {
        private int total;
        private int productoffering;
    }

    @Override
    public String toString() {
        return "AmdocsSearchResponse{" +
                "type='" + type + '\'' +
                ", documents=" + documents +
                ", count=" + count +
                ", paths=" + paths +
                '}';
    }
}
