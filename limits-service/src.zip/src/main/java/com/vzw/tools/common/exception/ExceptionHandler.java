package com.vzw.tools.common.exception;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;

@Slf4j
public class ExceptionHandler {

    private ExceptionHandler() {
    }

    public static ResponseEntity<String> handleDataNotFoundException(Exception ex) {
        log.error("Data is not found", ex);
        return ResponseEntity.status(404).body(ex.getMessage());
    }

    public static ResponseEntity<String> handleIdNotException(Exception ex) {
        log.error("Id is not found", ex);
        return ResponseEntity.status(404).body(ex.getMessage());
    }

    public static ResponseEntity<String> handleException(String ex) {
        log.error(ex);
        return ResponseEntity.status(500).body(ex);
    }

    public static String handleIdNotFoundException(Exception ex) {
        log.error("Id is not found", ex);
        return ex.getMessage();
    }

    public static String jsonException(Exception ex) {
        log.error("Json Exception", ex);
        return ex.getMessage();
    }

    public static String nullValueException() {
        log.error("Sor Id is not found");
        return "Sor Id is not found";
    }
}
