package com.vzw.tools.common;

import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.util.FileCopyUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.zip.GZIPInputStream;

import static com.vzw.tools.cache.constant.RedisConstants.THIRTY_ONE;
import static com.vzw.tools.cache.constant.RedisConstants.ZERO;

@Slf4j
public class GzipStringRedisSerializer extends StringRedisSerializer {

    private final boolean gzipEnabled;

    public GzipStringRedisSerializer(boolean gzipEnabled) {
        super();
        this.gzipEnabled = gzipEnabled;
    }

    /*
     * Method currently checks for the gzip header value 31. Alternatively we could allow it to attempt to decompress
     * and handle the ZipException.
     */
    @Override
    public String deserialize(byte[] bytes) {
        try {
            if (bytes != null && bytes.length > ZERO && bytes[ZERO] == THIRTY_ONE) {
                bytes = decompressBytes(bytes);
            }
            return super.deserialize(bytes);
        } catch (IOException e) {
            return null;
        }
    }

    /**
     * Method to decompress byte array from gzip.
     */
    private byte[] decompressBytes(byte[] bytes) throws IOException {
        try (ByteArrayInputStream bais = new ByteArrayInputStream(bytes)) {
            try (GZIPInputStream gis = new GZIPInputStream(bais)) {
                return FileCopyUtils.copyToByteArray(gis);
            }
        }
    }
}