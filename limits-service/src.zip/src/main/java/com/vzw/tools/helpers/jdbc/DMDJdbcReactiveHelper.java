package com.vzw.tools.helpers.jdbc;

import com.vzw.tools.common.exception.ErrorBuilder;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.internal.OracleTypes;
import org.elasticsearch.common.inject.Inject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import static com.vzw.tools.common.constant.CommonConstants.*;

@Component
@Slf4j
public class DMDJdbcReactiveHelper {

    private ReactiveStoredProcHelper reactiveStoredProcHelper;

    @Inject
    public DMDJdbcReactiveHelper(@Qualifier("dmdJdbcTemplate")JdbcTemplate jdbcTemplate) {
        super();
        this.reactiveStoredProcHelper = new ReactiveStoredProcHelper(jdbcTemplate);
    }
    @Autowired
    ErrorBuilder errorBuilder;

    @PostConstruct
    private void init() {
        log.trace("Entering into InstallmentLoanProcedure init()");
        List<SqlOutParameter> parameters = new ArrayList<>();
        parameters.add(new SqlOutParameter("P_RESULT_SET", OracleTypes.REF_CURSOR, (resultSet, i) -> setResultSet(resultSet)));
        reactiveStoredProcHelper.initialize(DMD_PKG, SP_DEVICE, parameters);
        log.trace("Exiting from InstallmentLoanProcedure init()");
    }

    private String setResultSet(ResultSet resultSet) throws SQLException {
        String dmsRes = resultSet.getString("DEVICEINFOLIST");
        return dmsRes;
    }
    //@LogExecutionTime
    public Mono<String> retrieveDMDResponse(String sorId) {
        Map<String, Object> arguments = new HashMap<>();
        arguments.put(DEV_SKU_LIST, sorId);
        arguments.put(DATE, null);
        Mono<Map<String, Object>> monoResponse = reactiveStoredProcHelper
                .execute(DMD_PKG,SP_DEVICE, arguments)
                .subscribeOn(Schedulers.boundedElastic())
                .onErrorMap(e -> errorBuilder.buildApplicationException(e));
        return monoResponse.flatMap(data -> {
            log.trace("Exiting from InstallmentLoanProcedure  retrieveAvailableMtns() - custid :{}, "
                    + "acctNo : {}, mtn : {}", sorId);
            List<?> result = (List<?>) data.get("P_RESULT_SET");
            Optional<String> dmdXmlResponse = result.stream().map(String.class::cast).findFirst();
            if(dmdXmlResponse.isPresent())
                return Mono.just(dmdXmlResponse.get());

            return Mono.just(EMPTY_STRING);
        });

    }


}
