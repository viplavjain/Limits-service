//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.vzw.tools.common.exception;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;

public class StackTraceUtils {
    public StackTraceUtils() {
    }

    public static String stackTraceAsString(Throwable t) {
        return ExceptionUtils.getStackTrace(t);
    }

    public static String stackTraceAsString(Throwable t, int depth) {
        String[] frames = ExceptionUtils.getStackFrames(t);
        if (frames.length > depth) {
            frames = (String[])Arrays.copyOf(frames, depth);
        }

        return asString(frames);
    }

    public static String stackTraceAsString(Throwable t, String findPackage) {
        String[] frames = ExceptionUtils.getStackFrames(t);
        int indexOfPackage = 0;

        for(int i = 0; i < frames.length; ++i) {
            String s = frames[i];
            ++indexOfPackage;
            if (s.trim().indexOf(findPackage) != -1) {
                break;
            }
        }

        String[] result = (String[])Arrays.copyOf(frames, indexOfPackage + 4);
        return asString(result);
    }

    public static String getPackageSpecificStackTrace(Error error, String packageToSearch) {
        List<String> frames = (List)Arrays.stream(ExceptionUtils.getStackFrames(error)).filter((str) -> {
            return str != null && str.contains(packageToSearch);
        }).map((s) -> {
            if (s == null) {
                return s;
            } else {
                String[] frame = s.split(" ");
                return ArrayUtils.isNotEmpty(frame) && frame.length > 1 ? frame[1] : s;
            }
        }).collect(Collectors.toList());
        return frames != null && !frames.isEmpty() ? (frames.size() > 1 ? (String)frames.get(1) : (String)frames.get(0)) : packageToSearch + " not available for metering.";
    }

    private static String asString(String[] frames) {
        StringBuilder sb = new StringBuilder();

        for(int i = 0; i < frames.length; ++i) {
            sb.append(frames[i] + System.lineSeparator());
        }

        return sb.toString();
    }
}
