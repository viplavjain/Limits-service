package com.vzw.tools.common.exception;

public class XmlConversionException extends Exception {

    public XmlConversionException(String message, Throwable cause) {
        super(message, cause);
    }

    public XmlConversionException(String message) {
        super(message);
    }
}

