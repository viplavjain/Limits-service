package com.vzw.tools.helpers.logging.vo;

import java.util.HashMap;
import java.util.Map;

public class TraceInfo {
    private String correlationId;
    private String sessionId;
    private String e2eRequestId;
    private String domainCorrelationId;
    private String user;
    private boolean canaryRequest;
    private String httpMethod;
    private String requestUri;
    private String requestPath;
    private String queryParams;
    private String domainName;
    private String routeType;
    private String requestHeaders;
    private String responseHeaders;
    private String request;
    private Map<String, String> customLogData;
    private Map<String, String> customHeaders;
    private boolean logPayload;
    private AppInfo appInfo;
    private String clientId;
    private String customLogLevel;
    private String secureToken;

    public Map<String, String> asMap() {
        Map<String, String> map = new HashMap();
        map.put("CORRELATION_ID", this.correlationId);
        map.put("E2EREQUESTID", this.e2eRequestId);
        map.put("SESSION_ID", this.sessionId);
        map.put("DS_CORRELATION_ID", this.domainCorrelationId);
        map.put("X-CANARY", this.canaryRequest ? "Y" : "N");
        map.put("USER", this.user);
        map.put("HTTP_METHOD", this.httpMethod);
        map.put("REQUEST_URI", this.requestUri);
        map.put("REQUEST_PATH", this.requestPath);
        map.put("QUERY_PARMAS", this.queryParams);
        map.put("DOMAIN_NAME", this.domainName);
        map.put("ROUTE_TYPE", this.routeType);
        map.put("CLIENT_ID", this.clientId);
        map.put("SSO_JWT", this.secureToken);
        return map;
    }

    public TraceInfo() {
    }

    public String getCorrelationId() {
        return this.correlationId;
    }

    public String getSessionId() {
        return this.sessionId;
    }

    public String getE2eRequestId() {
        return this.e2eRequestId;
    }

    public String getDomainCorrelationId() {
        return this.domainCorrelationId;
    }

    public String getUser() {
        return this.user;
    }

    public boolean isCanaryRequest() {
        return this.canaryRequest;
    }

    public String getHttpMethod() {
        return this.httpMethod;
    }

    public String getRequestUri() {
        return this.requestUri;
    }

    public String getRequestPath() {
        return this.requestPath;
    }

    public String getQueryParams() {
        return this.queryParams;
    }

    public String getDomainName() {
        return this.domainName;
    }

    public String getRouteType() {
        return this.routeType;
    }

    public String getRequestHeaders() {
        return this.requestHeaders;
    }

    public String getResponseHeaders() {
        return this.responseHeaders;
    }

    public String getRequest() {
        return this.request;
    }

    public Map<String, String> getCustomLogData() {
        return this.customLogData;
    }

    public Map<String, String> getCustomHeaders() {
        return this.customHeaders;
    }

    public boolean isLogPayload() {
        return this.logPayload;
    }

    public AppInfo getAppInfo() {
        return this.appInfo;
    }

    public String getClientId() {
        return this.clientId;
    }

    public String getCustomLogLevel() {
        return this.customLogLevel;
    }

    public String getSecureToken() {
        return this.secureToken;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public void setE2eRequestId(String e2eRequestId) {
        this.e2eRequestId = e2eRequestId;
    }

    public void setDomainCorrelationId(String domainCorrelationId) {
        this.domainCorrelationId = domainCorrelationId;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setCanaryRequest(boolean canaryRequest) {
        this.canaryRequest = canaryRequest;
    }

    public void setHttpMethod(String httpMethod) {
        this.httpMethod = httpMethod;
    }

    public void setRequestUri(String requestUri) {
        this.requestUri = requestUri;
    }

    public void setRequestPath(String requestPath) {
        this.requestPath = requestPath;
    }

    public void setQueryParams(String queryParams) {
        this.queryParams = queryParams;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    public void setRouteType(String routeType) {
        this.routeType = routeType;
    }

    public void setRequestHeaders(String requestHeaders) {
        this.requestHeaders = requestHeaders;
    }

    public void setResponseHeaders(String responseHeaders) {
        this.responseHeaders = responseHeaders;
    }

    public void setRequest(String request) {
        this.request = request;
    }

    public void setCustomLogData(Map<String, String> customLogData) {
        this.customLogData = customLogData;
    }

    public void setCustomHeaders(Map<String, String> customHeaders) {
        this.customHeaders = customHeaders;
    }

    public void setLogPayload(boolean logPayload) {
        this.logPayload = logPayload;
    }

    public void setAppInfo(AppInfo appInfo) {
        this.appInfo = appInfo;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public void setCustomLogLevel(String customLogLevel) {
        this.customLogLevel = customLogLevel;
    }

    public void setSecureToken(String secureToken) {
        this.secureToken = secureToken;
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        } else if (!(o instanceof TraceInfo)) {
            return false;
        } else {
            TraceInfo other = (TraceInfo)o;
            if (!other.canEqual(this)) {
                return false;
            } else if (this.isCanaryRequest() != other.isCanaryRequest()) {
                return false;
            } else if (this.isLogPayload() != other.isLogPayload()) {
                return false;
            } else {
                label256: {
                    Object this$correlationId = this.getCorrelationId();
                    Object other$correlationId = other.getCorrelationId();
                    if (this$correlationId == null) {
                        if (other$correlationId == null) {
                            break label256;
                        }
                    } else if (this$correlationId.equals(other$correlationId)) {
                        break label256;
                    }

                    return false;
                }

                label249: {
                    Object this$sessionId = this.getSessionId();
                    Object other$sessionId = other.getSessionId();
                    if (this$sessionId == null) {
                        if (other$sessionId == null) {
                            break label249;
                        }
                    } else if (this$sessionId.equals(other$sessionId)) {
                        break label249;
                    }

                    return false;
                }

                Object this$e2eRequestId = this.getE2eRequestId();
                Object other$e2eRequestId = other.getE2eRequestId();
                if (this$e2eRequestId == null) {
                    if (other$e2eRequestId != null) {
                        return false;
                    }
                } else if (!this$e2eRequestId.equals(other$e2eRequestId)) {
                    return false;
                }

                label235: {
                    Object this$domainCorrelationId = this.getDomainCorrelationId();
                    Object other$domainCorrelationId = other.getDomainCorrelationId();
                    if (this$domainCorrelationId == null) {
                        if (other$domainCorrelationId == null) {
                            break label235;
                        }
                    } else if (this$domainCorrelationId.equals(other$domainCorrelationId)) {
                        break label235;
                    }

                    return false;
                }

                Object this$user = this.getUser();
                Object other$user = other.getUser();
                if (this$user == null) {
                    if (other$user != null) {
                        return false;
                    }
                } else if (!this$user.equals(other$user)) {
                    return false;
                }

                label221: {
                    Object this$httpMethod = this.getHttpMethod();
                    Object other$httpMethod = other.getHttpMethod();
                    if (this$httpMethod == null) {
                        if (other$httpMethod == null) {
                            break label221;
                        }
                    } else if (this$httpMethod.equals(other$httpMethod)) {
                        break label221;
                    }

                    return false;
                }

                label214: {
                    Object this$requestUri = this.getRequestUri();
                    Object other$requestUri = other.getRequestUri();
                    if (this$requestUri == null) {
                        if (other$requestUri == null) {
                            break label214;
                        }
                    } else if (this$requestUri.equals(other$requestUri)) {
                        break label214;
                    }

                    return false;
                }

                Object this$requestPath = this.getRequestPath();
                Object other$requestPath = other.getRequestPath();
                if (this$requestPath == null) {
                    if (other$requestPath != null) {
                        return false;
                    }
                } else if (!this$requestPath.equals(other$requestPath)) {
                    return false;
                }

                label200: {
                    Object this$queryParams = this.getQueryParams();
                    Object other$queryParams = other.getQueryParams();
                    if (this$queryParams == null) {
                        if (other$queryParams == null) {
                            break label200;
                        }
                    } else if (this$queryParams.equals(other$queryParams)) {
                        break label200;
                    }

                    return false;
                }

                label193: {
                    Object this$domainName = this.getDomainName();
                    Object other$domainName = other.getDomainName();
                    if (this$domainName == null) {
                        if (other$domainName == null) {
                            break label193;
                        }
                    } else if (this$domainName.equals(other$domainName)) {
                        break label193;
                    }

                    return false;
                }

                Object this$routeType = this.getRouteType();
                Object other$routeType = other.getRouteType();
                if (this$routeType == null) {
                    if (other$routeType != null) {
                        return false;
                    }
                } else if (!this$routeType.equals(other$routeType)) {
                    return false;
                }

                Object this$requestHeaders = this.getRequestHeaders();
                Object other$requestHeaders = other.getRequestHeaders();
                if (this$requestHeaders == null) {
                    if (other$requestHeaders != null) {
                        return false;
                    }
                } else if (!this$requestHeaders.equals(other$requestHeaders)) {
                    return false;
                }

                label172: {
                    Object this$responseHeaders = this.getResponseHeaders();
                    Object other$responseHeaders = other.getResponseHeaders();
                    if (this$responseHeaders == null) {
                        if (other$responseHeaders == null) {
                            break label172;
                        }
                    } else if (this$responseHeaders.equals(other$responseHeaders)) {
                        break label172;
                    }

                    return false;
                }

                Object this$request = this.getRequest();
                Object other$request = other.getRequest();
                if (this$request == null) {
                    if (other$request != null) {
                        return false;
                    }
                } else if (!this$request.equals(other$request)) {
                    return false;
                }

                Object this$customLogData = this.getCustomLogData();
                Object other$customLogData = other.getCustomLogData();
                if (this$customLogData == null) {
                    if (other$customLogData != null) {
                        return false;
                    }
                } else if (!this$customLogData.equals(other$customLogData)) {
                    return false;
                }

                label151: {
                    Object this$customHeaders = this.getCustomHeaders();
                    Object other$customHeaders = other.getCustomHeaders();
                    if (this$customHeaders == null) {
                        if (other$customHeaders == null) {
                            break label151;
                        }
                    } else if (this$customHeaders.equals(other$customHeaders)) {
                        break label151;
                    }

                    return false;
                }

                label144: {
                    Object this$appInfo = this.getAppInfo();
                    Object other$appInfo = other.getAppInfo();
                    if (this$appInfo == null) {
                        if (other$appInfo == null) {
                            break label144;
                        }
                    } else if (this$appInfo.equals(other$appInfo)) {
                        break label144;
                    }

                    return false;
                }

                label137: {
                    Object this$clientId = this.getClientId();
                    Object other$clientId = other.getClientId();
                    if (this$clientId == null) {
                        if (other$clientId == null) {
                            break label137;
                        }
                    } else if (this$clientId.equals(other$clientId)) {
                        break label137;
                    }

                    return false;
                }

                Object this$customLogLevel = this.getCustomLogLevel();
                Object other$customLogLevel = other.getCustomLogLevel();
                if (this$customLogLevel == null) {
                    if (other$customLogLevel != null) {
                        return false;
                    }
                } else if (!this$customLogLevel.equals(other$customLogLevel)) {
                    return false;
                }

                Object this$secureToken = this.getSecureToken();
                Object other$secureToken = other.getSecureToken();
                if (this$secureToken == null) {
                    if (other$secureToken != null) {
                        return false;
                    }
                } else if (!this$secureToken.equals(other$secureToken)) {
                    return false;
                }

                return true;
            }
        }
    }

    protected boolean canEqual(Object other) {
        return other instanceof TraceInfo;
    }

    public int hashCode() {
        int result = 1;
        result = result * 59 + (this.isCanaryRequest() ? 79 : 97);
        result = result * 59 + (this.isLogPayload() ? 79 : 97);
        Object $correlationId = this.getCorrelationId();
        result = result * 59 + ($correlationId == null ? 43 : $correlationId.hashCode());
        Object $sessionId = this.getSessionId();
        result = result * 59 + ($sessionId == null ? 43 : $sessionId.hashCode());
        Object $e2eRequestId = this.getE2eRequestId();
        result = result * 59 + ($e2eRequestId == null ? 43 : $e2eRequestId.hashCode());
        Object $domainCorrelationId = this.getDomainCorrelationId();
        result = result * 59 + ($domainCorrelationId == null ? 43 : $domainCorrelationId.hashCode());
        Object $user = this.getUser();
        result = result * 59 + ($user == null ? 43 : $user.hashCode());
        Object $httpMethod = this.getHttpMethod();
        result = result * 59 + ($httpMethod == null ? 43 : $httpMethod.hashCode());
        Object $requestUri = this.getRequestUri();
        result = result * 59 + ($requestUri == null ? 43 : $requestUri.hashCode());
        Object $requestPath = this.getRequestPath();
        result = result * 59 + ($requestPath == null ? 43 : $requestPath.hashCode());
        Object $queryParams = this.getQueryParams();
        result = result * 59 + ($queryParams == null ? 43 : $queryParams.hashCode());
        Object $domainName = this.getDomainName();
        result = result * 59 + ($domainName == null ? 43 : $domainName.hashCode());
        Object $routeType = this.getRouteType();
        result = result * 59 + ($routeType == null ? 43 : $routeType.hashCode());
        Object $requestHeaders = this.getRequestHeaders();
        result = result * 59 + ($requestHeaders == null ? 43 : $requestHeaders.hashCode());
        Object $responseHeaders = this.getResponseHeaders();
        result = result * 59 + ($responseHeaders == null ? 43 : $responseHeaders.hashCode());
        Object $request = this.getRequest();
        result = result * 59 + ($request == null ? 43 : $request.hashCode());
        Object $customLogData = this.getCustomLogData();
        result = result * 59 + ($customLogData == null ? 43 : $customLogData.hashCode());
        Object $customHeaders = this.getCustomHeaders();
        result = result * 59 + ($customHeaders == null ? 43 : $customHeaders.hashCode());
        Object $appInfo = this.getAppInfo();
        result = result * 59 + ($appInfo == null ? 43 : $appInfo.hashCode());
        Object $clientId = this.getClientId();
        result = result * 59 + ($clientId == null ? 43 : $clientId.hashCode());
        Object $customLogLevel = this.getCustomLogLevel();
        result = result * 59 + ($customLogLevel == null ? 43 : $customLogLevel.hashCode());
        Object $secureToken = this.getSecureToken();
        result = result * 59 + ($secureToken == null ? 43 : $secureToken.hashCode());
        return result;
    }

    public String toString() {
        String var10000 = this.getCorrelationId();
        return "TraceInfo(correlationId=" + var10000 + ", sessionId=" + this.getSessionId() + ", e2eRequestId=" + this.getE2eRequestId() + ", domainCorrelationId=" + this.getDomainCorrelationId() + ", user=" + this.getUser() + ", canaryRequest=" + this.isCanaryRequest() + ", httpMethod=" + this.getHttpMethod() + ", requestUri=" + this.getRequestUri() + ", requestPath=" + this.getRequestPath() + ", queryParams=" + this.getQueryParams() + ", domainName=" + this.getDomainName() + ", routeType=" + this.getRouteType() + ", requestHeaders=" + this.getRequestHeaders() + ", responseHeaders=" + this.getResponseHeaders() + ", request=" + this.getRequest() + ", customLogData=" + this.getCustomLogData() + ", customHeaders=" + this.getCustomHeaders() + ", logPayload=" + this.isLogPayload() + ", appInfo=" + this.getAppInfo() + ", clientId=" + this.getClientId() + ", customLogLevel=" + this.getCustomLogLevel() + ", secureToken=" + this.getSecureToken() + ")";
    }
}
