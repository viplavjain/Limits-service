package com.vzw.tools.common.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JsonToMapUtil {

    private JsonToMapUtil() {
    }

    public static boolean canSafeCastObjectToMap(Object object) {
        return object instanceof Map;
    }

    public static boolean canSafeCastObjectToList(Object object) {
        return object instanceof List;
    }

    public static Map<String, Object> safeCastObjectToMap(Object object) {
        Map<String, Object> result = null;
        if (canSafeCastObjectToMap(object)) {
            result = (Map<String, Object>) object;
        }
        return result;
    }

    public static List<Object> safeCastObjectToList(Object object) {
        List<Object> result = null;
        if (canSafeCastObjectToList(object)) {
            result = (List<Object>) object;
        }
        return result;
    }


    public static List<Object> getListValueFromMapObject(String property, Object source) {
        return safeCastObjectToList(getValueFromMapObject(property, source));
    }

    public static String getStringValueFromMapObject(String property, Object source) {
        return getStringValueFromMap(property, safeCastObjectToMap(source));
    }

    public static Object getValueFromMapObject(String property, Object source) {
        return getValueFromMap(property, safeCastObjectToMap(source));
    }

    public static String getStringValueFromMap(String property, Map<String, Object> source) {
        Object result = getValueFromMap(property, source);
        if (result != null) {
            return String.valueOf(result);
        }
        return null;
    }

    public static Object getValueFromMap(String property, Map<String, Object> source) {
        Object result = null;
        if (source != null) {
            Map<String, String> headTailMap = getHeadTailOfPath(property);
            String headProperty = headTailMap.get("head");
            if (headTailMap.containsKey("tail")) {
                String tailProperty = headTailMap.get("tail");
                Object currentDepthObj = source.get(headProperty);
                return getValueFromMap(tailProperty, safeCastObjectToMap(currentDepthObj));
            } else {
                result = source.get(headProperty);
            }
        }
        return result;
    }

    private static Map<String, String> getHeadTailOfPath(String path) {
        Map<String, String> result = new HashMap<>();
        StringBuilder headToken = new StringBuilder();
        String tailToken;
        boolean priorWasEscape = false;
        boolean completedHead = false;
        StringBuilder tailTokenBuilder = new StringBuilder();
        for (int i = 0; i < path.length(); i++) {
            char c = path.charAt(i);
            if (!completedHead) {
                if (c == '.' && !priorWasEscape) completedHead = true;
                else if (c == '\\') priorWasEscape = true;
                else if (priorWasEscape) {
                    priorWasEscape = false;
                    headToken.append(c);
                } else headToken.append(c);
            } else tailTokenBuilder.append(c);
        }
        tailToken = tailTokenBuilder.toString();
        result.put("head", headToken.toString());
        if (!tailToken.isEmpty()) {
            result.put("tail", tailToken);
        }
        return result;
    }

}
