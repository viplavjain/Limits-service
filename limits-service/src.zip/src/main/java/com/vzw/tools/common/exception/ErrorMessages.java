package com.vzw.tools.common.exception;

public class ErrorMessages {

    public static final String XML_To_JSON_CONVERSION_ERROR = "Error converting XML to JSON";
}

