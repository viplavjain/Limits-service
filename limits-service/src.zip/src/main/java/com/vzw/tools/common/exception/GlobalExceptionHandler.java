package com.vzw.tools.common.exception;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    private static final Logger logger = LogManager.getLogger(GlobalExceptionHandler.class);
    // Handle custom application exceptions
    @ExceptionHandler(DeviceException.class)
    public ResponseEntity<Map<String, Object>> handleAppException(DeviceException ex) {
        Map<String, Object> response = new HashMap<>();
        response.put("error", ex.getMessage());
        response.put("details", ex.getDetails());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
    }

    // Handle generic exceptions
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleFCRuntimeException(Exception ex) {
        if(ex instanceof FCToolsMSException) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(((FCToolsMSException) ex).getErrorResponse());
        }
        logger.error("Error while executing the request {}", ExceptionUtils.getStackTrace(ex));
        ErrorResponse errResponse = new ErrorResponse();
        errResponse.setNamespace("Fc Tools Namespace");
        errResponse.setName("fc-tools-ms");
        errResponse.setCode("500");
        errResponse.setId("500");
        errResponse.setMessage(ex.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errResponse);
    }
}
