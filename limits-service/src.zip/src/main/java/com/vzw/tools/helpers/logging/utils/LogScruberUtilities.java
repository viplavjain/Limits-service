package com.vzw.tools.helpers.logging.utils;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LogScruberUtilities {
    private static final Map<String, List<ReplacementPattern>> JSON_ELEMENT_PARSE_MAP = new HashMap();
    private static final String JSON_REPLACE_UNFORMATTED_PATTERN = "(\"?%1$s\"?)([.*:|=.*])(\"?[^,}]+\"?)";
    private static final String JSON_SEARCH_UNFORMATTED_PATTERN = "\"%1$s\":";
    private static final String JSON_SEARCH_UNFORMATTED_PATTERN2 = "%1$s=";
    private static final String JSON_SEARCH_UNFORMATTED_PATTERN3 = "%1$s:";
    private static final String JSON_XML_REPLACEMENT = "$1$2\"HIDDEN VALUE\"|$1$2HIDDEN VALUE";

    public LogScruberUtilities() {
    }

    private static void loadJsonPatterns(String elementName) {
        if (!JSON_ELEMENT_PARSE_MAP.containsKey(elementName)) {
            List<ReplacementPattern> patterns = new ArrayList(1);
            ReplacementPattern jsonReplacePattern = createJsonPattern(elementName);
            patterns.add(jsonReplacePattern);
            JSON_ELEMENT_PARSE_MAP.put(elementName, patterns);
        }

    }

    private static ReplacementPattern createJsonPattern(String elementName) {
        String jsonRegexp = String.format("(\"?%1$s\"?)([.*:|=.*])(\"?[^,}]+\"?)", elementName);
        Pattern jsonPattern = Pattern.compile(jsonRegexp);
        String jsonSearch = String.format("\"%1$s\":", elementName);
        String mapFieldSearch = String.format("%1$s=", elementName);
        String headerFieldSearch = String.format("%1$s:", elementName);
        ReplacementPattern jsonReplacePattern = new ReplacementPattern(jsonSearch, mapFieldSearch, headerFieldSearch, jsonPattern, "$1$2\"HIDDEN VALUE\"|$1$2HIDDEN VALUE");
        return jsonReplacePattern;
    }

    public static String removeJSONValue(String elementName, String json) {
        String retVal = json;
        if (retVal.contains(elementName)) {
            List<ReplacementPattern> patterns = getJSONPatterns(elementName);
            Iterator var4 = patterns.iterator();

            while(var4.hasNext()) {
                ReplacementPattern pattern = (ReplacementPattern)var4.next();
                if (pattern.supports(retVal)) {
                    Matcher matcher = pattern.getReplacePattern().matcher(retVal);
                    if (matcher.find()) {
                        String replacement = matcher.group(3).contains("\"") ? "$1$2\"HIDDEN VALUE\"" : "$1$2HIDDEN VALUE";
                        retVal = matcher.replaceAll(replacement);
                    }
                }
            }
        }

        return retVal;
    }

    private static List<ReplacementPattern> getJSONPatterns(String elementName) {
        if (!JSON_ELEMENT_PARSE_MAP.containsKey(elementName)) {
            loadJsonPatterns(elementName);
        }

        List<ReplacementPattern> retVal = (List)JSON_ELEMENT_PARSE_MAP.get(elementName);
        return retVal;
    }

    private static class ReplacementPattern {
        private final String searchPattern;
        private final String searchPattern2;
        private final String searchPattern3;
        private final Pattern replacePattern;
        private final String replacement;

        public ReplacementPattern(String searchPattern, String searchPattern2, String searchPattern3, Pattern replacePattern, String replacement) {
            this.searchPattern = searchPattern;
            this.searchPattern2 = searchPattern2;
            this.searchPattern3 = searchPattern3;
            this.replacePattern = replacePattern;
            this.replacement = replacement;
        }

        public Pattern getReplacePattern() {
            return this.replacePattern;
        }

        public boolean supports(String payload) {
            return payload.contains(this.searchPattern) || payload.contains(this.searchPattern2) || payload.contains(this.searchPattern3);
        }

        public String getReplacement() {
            return this.replacement;
        }
    }
}
