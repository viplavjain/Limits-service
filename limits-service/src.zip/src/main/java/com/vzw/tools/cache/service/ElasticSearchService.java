package com.vzw.tools.cache.service;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import com.vzw.tools.cache.configuration.ElasticSearchConfigurations;
import com.vzw.tools.cache.properties.ElasticSearchProperties;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.tools.cache.model.ElasticSearchConfigModel;
import com.vzw.tools.cache.model.ElasticSearchModel;
import com.vzw.tools.common.exception.CustomException;
import com.vzw.tools.common.exception.ExceptionHandler;
import com.vzw.tools.common.util.JsonToMapUtil;
import com.vzw.tools.source.configuration.RunTimeMapInitializer;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import static com.vzw.tools.cache.constant.ElasticServiceConstants.*;
import static com.vzw.tools.cache.constant.ElasticServiceConstants.BYTES;

@Slf4j
@Service
public class ElasticSearchService {

    private final ElasticSearchProperties elasticSearchProperties;

    private final Environment environment;

    private final RunTimeMapInitializer runTimeMapInitializer;

    private final ElasticSearchConfigurations esConfiguration;
    @Autowired
    private RestTemplate restTemplate;

    public ElasticSearchService(ElasticSearchProperties elasticSearchProperties, Environment environment, RunTimeMapInitializer runTimeMapInitializer, ElasticSearchProperties esProperties, ElasticSearchConfigurations esConfiguration) {
        this.elasticSearchProperties = elasticSearchProperties;
        this.environment = environment;
        this.runTimeMapInitializer = runTimeMapInitializer;
        this.esConfiguration = esConfiguration;
    }
    public WebClient getWebClient() {
        int byteCount = elasticSearchProperties.getBufferSize() * BYTES * BYTES;
        return WebClient.builder().
                exchangeStrategies(ExchangeStrategies.builder().codecs(
                        configure -> configure.defaultCodecs()
                                .maxInMemorySize(byteCount)).build()).build();
    }
    //Refactored Code
    public Mono<Object> elasticSearchData1(String sorId, String productType, String env) {
        if (sorId.trim().isEmpty()) {
            return Mono.error(new CustomException("Empty sorId", "400"));
        }
        List<JsonNode> responseList = new ArrayList<>();
        ElasticSearchModel esModel = new ElasticSearchModel();
        esModel.setInstance(env);
        esModel.setIndex(productType);
        esModel.setId(sorId.trim());
        String priceSorId = sorId;
        if(esModel.getIndex().equalsIgnoreCase(DEVICE)||esModel.getIndex().equalsIgnoreCase(ACCESSORY)) {
            try {
                sorId = sorId + SAP_ID;
                productType = getProductTypeForEnvironment1(esModel.getIndex());
                JsonNode jsonNode = searchESData1(env, productType, sorId);

                String dataId = getEsId1(String.valueOf(jsonNode), esModel.getIndex());
                productType = getProductType1(productType);
                if (!StringUtils.isEmpty(dataId)) {
                    JsonNode esData = searchESData1(env, productType, dataId);
                    responseList.add(esData);
                }
                if (productType.equalsIgnoreCase(DEVICE_QA)) {
                    productType = getProductType2(productType);
                    if (!StringUtils.isEmpty(dataId)) {
                        JsonNode esData = searchESData1(env, productType, dataId);
                        responseList.add(esData);
                        productType = DEVICE_QA;
                    }
                }
                if (productType.equalsIgnoreCase(DEVICE_QA)) {
                    productType = getProductType3(productType);
                    if (!StringUtils.isEmpty(priceSorId)) {
                        JsonNode esData = searchESData1(env, productType, priceSorId);
                        responseList.add(esData);
                    }
                } else if (productType.equalsIgnoreCase(ACCESSORY_QA)) {
                    productType = getProductType3(productType);
                    if (!StringUtils.isEmpty(priceSorId)) {
                        JsonNode esData = searchESData1(env, productType, priceSorId);
                        responseList.add(esData);
                    }
                }
                return Mono.just(responseList);
            } catch (CustomException ex) {
                log.error(ex.getErrorMessage());
                return Mono.error(new CustomException("Empty dataId", "500"));
            }
        }
        return Mono.empty();
    }

    public Mono<JsonNode> elasticSearchPromotionData(String offerId) throws IOException {

        String apiUrl = elasticSearchProperties.getApiUrl();
        String content;
        try (InputStream inputStream = RunTimeMapInitializer.class.getClassLoader().getResourceAsStream(REQUEST_BODY)) {
            if (inputStream == null) {
                throw new RuntimeException("File espromotion_request.json not found in resources folder");
            }

            content = new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);
        }

        Mono<JsonNode> esResponse =
                getWebClient().post()
                        .uri(apiUrl)
                        .headers(h -> h.addAll(esConfiguration.getHeader()))
                        .bodyValue(content.replace(OFFER_ID, offerId))
                        .retrieve()
                        .bodyToMono(JsonNode.class)
                        .doOnSubscribe(subscription -> log.info("Request initiated for URL in promotion flow: {}", apiUrl))
                        .doOnNext(response -> log.info("Received response in promotion flow: {}", response))
                        .doOnError(error -> log.error("Error occurred while fetching promotion details: {}", error.getMessage(), error));
        return esResponse.flatMap(Mono::just);
    }
    private String getProductTypeForEnvironment1(String index) {
        if ((DEVICE.equalsIgnoreCase(index))) {
            return INVENTORY_DEVICE_QA;
        } else if (ACCESSORY.equalsIgnoreCase(index)) {
            return INVENTORY_ACCESSORY_QA;
        }
        throw new CustomException(INVALID_PRODUCT_TYPE + index, "400");
    }

    private String getProductType1(String productType) {
        if (INVENTORY_DEVICE_QA.equalsIgnoreCase(productType)) {
            return DEVICE_QA;
        } else if (INVENTORY_ACCESSORY_QA.equalsIgnoreCase(productType)) {
            return ACCESSORY_QA;
        }
        throw new CustomException(INVALID_PRODUCT_TYPE + productType, "400");
    }

    private String getProductType2(String productType) {
        if (DEVICE_QA.equalsIgnoreCase(productType)) {
            return SMART_IMEI_DEVICES_QA;
        }
        throw new CustomException(INVALID_PRODUCT_TYPE + productType, "400");
    }
    private String getProductType3(String productType) {
        if (DEVICE_QA.equalsIgnoreCase(productType)) {
            return PRICE_DEVICE_COMPOSITE;
        } else if (ACCESSORY_QA.equalsIgnoreCase(productType)) {
            return PRICE_ACCESSORY_COMPOSITE;
        }
        throw new CustomException(INVALID_PRODUCT_TYPE + productType, "400");
    }

    public String getEsId1(String data, String index) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            Map<String, Object> responseData = objectMapper.readValue(data, new TypeReference<>() {
            });
            if (responseData == null || responseData.isEmpty()) {
                return ExceptionHandler.nullValueException();
            }
            if (index.equalsIgnoreCase(DEVICE)) {
                if (responseData.containsKey(DEVICE_ID)) {
                    List<String> devProdList = (List<String>) responseData.get(DEVICE_ID);
                    if (devProdList != null) return devProdList.get(devProdList.size() - 1);
                }
            } else if (responseData.containsKey(ACCESSORY_ID)) {
                List<String> accProdList = (List<String>) responseData.get(ACCESSORY_ID);
                if (accProdList != null) return accProdList.get(accProdList.size() - 1);
            }
        } catch (CustomException ex) {
            return ExceptionHandler.handleIdNotFoundException(ex);
        } catch (JsonProcessingException ex) {
            return ExceptionHandler.jsonException(ex);
        }
        return null;
    }

	public Mono<Map<String, String>> getElasticSearchDataMap(String sorId, String productType, String env) {
		return elasticSearchData1(sorId, productType, env).flatMap(res -> {
			Map<String, String> elasticMapJson = new HashMap<>();
			List<JsonNode> responseList = (List<JsonNode>) res;
			Map<String, String> estMap = getElasticSearchMap(sorId, responseList);
			Map<String, String> elasticSearchMap = runTimeMapInitializer.getElasticSearchMap(productType);
			elasticSearchMap.forEach((key, value) -> {
				String retrievedValue = estMap.get(value);
				elasticMapJson.put(key, retrievedValue);
			});
			return Mono.just(elasticMapJson);
		});
	}
	
	private Map<String, String> getElasticSearchMap(String sorId, List<JsonNode> responseList) {
		Map<String, String> elasticMapJson = new HashMap<>();
		ObjectMapper objectMapper = new ObjectMapper();
		responseList
				.forEach(jsonNode -> objectMapper.convertValue(jsonNode, new TypeReference<Map<String, Object>>() {
				}).forEach((key, value) -> getElasticSearchMap(sorId, elasticMapJson, key, value)));
		return elasticMapJson;
	}

	private void getElasticSearchMap(String sorId, Map<String, String> elasticMapJson, String key, Object value) {
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			if (value instanceof Map) {
                if (!key.equalsIgnoreCase("preferred_soft_sim") && !key.equalsIgnoreCase("preferred_sim")) {
                    ((Map<String, Object>) value).forEach(
                            (nestedKey, nestedValue) -> elasticMapJson.put(nestedKey, String.valueOf(nestedValue)));
                }
			} else if (value instanceof List) {
				elasticMapJson.put(key, String.valueOf(value));
				if (key.equalsIgnoreCase("child_skus") || key.equalsIgnoreCase("skus")
						|| key.equalsIgnoreCase("price")) {
					String jsonString = objectMapper.writeValueAsString(value);
					List<Map<String, Object>> listOfMaps = objectMapper.readValue(jsonString, new TypeReference<>() {
					});
					if (key.equalsIgnoreCase("price")) {
						listOfMaps.stream().forEach(map -> {
							map.forEach((key1, value1) -> elasticMapJson.put(String.valueOf(map.get("price_list")),
									String.valueOf(map.get(LIST_PRICE))));
						});
					} else {
						Optional<Map<String, Object>> filterMap = listOfMaps.stream()
								.filter(map -> map.containsValue(sorId)).findFirst();
						filterMap.ifPresent(stringObjectMap -> stringObjectMap
								.forEach((key1, value1) -> elasticMapJson.put(key1, String.valueOf(value1))));
					}
				}
                if (key.equalsIgnoreCase(PRICE)) {
                    String jsonString = objectMapper.writeValueAsString(value);
                    JsonNode jsonNode = objectMapper.readTree(jsonString);
                    JsonNode priceList = jsonNode.get(0).get(PRICE_LIST);
                    if (priceList.asText().equalsIgnoreCase(FULL_RETAIL_PRICE_LIST)) {
                        JsonNode listPrice = jsonNode.get(0).get(LIST_PRICE);
                        elasticMapJson.put(LIST_PRICE, listPrice.asText());
                    }
                }
			} else {
				elasticMapJson.put(key, String.valueOf(value));
			}
		} catch (Exception e) {
			log.error("Error while updating elasticSearchMap : " + e.getMessage());
		}
	}
	
    public JsonNode searchESData1(String instance, String index, String id) {
        String idValue = id.trim();
        ElasticSearchConfigModel config = getElasticSearchConfig(instance);
        String urlBuilder = buildUrl(config, index, idValue);
        HttpEntity<?> request = createRequest(config);
        ResponseEntity<Object> response = makeHttpRequest(urlBuilder, request);
        Object hits = JsonToMapUtil.getValueFromMapObject("hits", response.getBody());
        List<Object> hitsList = JsonToMapUtil.getListValueFromMapObject("hits", hits);
        if (hitsList != null && !hitsList.isEmpty() && hitsList.get(0) != null) {
            Object source = JsonToMapUtil.getValueFromMapObject("_source", hitsList.get(0));
            String retrievedIndexName = JsonToMapUtil.getStringValueFromMapObject("_index", hitsList.get(0));
            log.info("Retrieved data for index {}", retrievedIndexName);
            ObjectMapper mapper = new ObjectMapper();
            return mapper.convertValue(source, JsonNode.class);
        }
        return null;
    }

    private ElasticSearchConfigModel getElasticSearchConfig(String instance) {
        for (String environmentValue : elasticSearchProperties.getEnvironmentNames()) {
            if (instance.equalsIgnoreCase(environment.getProperty(FEDERATED_CATALOG_ELASTIC_SEARCH + environmentValue + ".name"))) {
                return new ElasticSearchConfigModel(
                        environment.getProperty(FEDERATED_CATALOG_ELASTIC_SEARCH + environmentValue + ".url"),
                        Integer.parseInt(Objects.requireNonNull(environment.getProperty(FEDERATED_CATALOG_ELASTIC_SEARCH + environmentValue + ".port"))),
                        environment.getProperty(FEDERATED_CATALOG_ELASTIC_SEARCH + environmentValue + ".scheme"),
                        environment.getProperty(FEDERATED_CATALOG_ELASTIC_SEARCH + environmentValue + ".username"),
                        environment.getProperty(FEDERATED_CATALOG_ELASTIC_SEARCH + environmentValue + ".password"),
                        Boolean.parseBoolean(environment.getProperty(FEDERATED_CATALOG_ELASTIC_SEARCH + environmentValue + ".auth-enable")),
                        environment.getProperty(FEDERATED_CATALOG_ELASTIC_SEARCH + environmentValue + ".pathPrefix")
                );
            }
        }
        throw new CustomException("No ES config found", "500");
    }

    private String buildUrl(ElasticSearchConfigModel config, String index, String idValue) {
        return StringUtils.isNotEmpty(config.getPathPrefix()) ?
                config.getScheme() + "://" + config.getUrl() + ":" + config.getPort() + "/" + config.getPathPrefix() + "/" + index + "/_search?pretty&q=_id:" + "\"" + idValue + "\"" :
                config.getScheme() + "://" + config.getUrl() + "/" + index + "/_search?pretty&q=_id:" + "\"" + idValue + "\"";
    }

    private HttpEntity<?> createRequest(ElasticSearchConfigModel config) {
        if (config.isAuthEnabled()) {
            String plainCredentials = config.getUsername() + ":" + config.getPassword();
            byte[] base64CredentialsBytes = Base64.getEncoder().encode(plainCredentials.getBytes());
            String base64Credentials = new String(base64CredentialsBytes);
            HttpHeaders headers = new HttpHeaders();
            headers.add("Authorization", "Basic " + base64Credentials);
            return new HttpEntity<>(headers);
        }
        return null;
    }

    private ResponseEntity<Object> makeHttpRequest(String urlBuilder, HttpEntity<?> request) {
        try {
            URL esUrl = new URL(urlBuilder);
            return request != null ? restTemplate.exchange(esUrl.toString(), HttpMethod.GET, request, Object.class) :
                    restTemplate.getForEntity(esUrl.toString(), Object.class);
        } catch (Exception ex) {
            throw new CustomException("Failed to make connection" + ex.getMessage() , "500");
        }
    }
}
