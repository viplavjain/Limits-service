package com.vzw.tools.cache.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
public class RedisModel {
    private String id;
    private String assetName;
    private String data;
    private String env;
    private String saveStatus;
    private String primaryKey;
    private String secondaryKey;
    private boolean useSSL;
    private List<String> assetNamesList;
    private String url;
    private String portNumber;
    private String password;
    private List<Object> hashKeyList;
    private String secHash;
    private String message;
    private String timeToLive;
    private List<String> redisEnvList;
    private int countOfKeys;
    private String errorMsg;
    private String tdcData;
    private String sdcData;
    private String tampaData;
    private String tdcErrorMsg;
    private String sdcErrorMsg;
    private String tampaErrorMsg;

}
