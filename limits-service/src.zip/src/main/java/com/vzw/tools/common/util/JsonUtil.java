package com.vzw.tools.common.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.vzw.tools.common.constant.CommonConstants.*;

public class JsonUtil {
    public static List<JsonNode> objectToJsonNode(List<String> strings) {
        ObjectMapper objectMapper = new ObjectMapper();
        List<JsonNode> listJsonNodes = new ArrayList<>();
        try {
            for (String s : strings) {
                listJsonNodes.add(objectMapper.readTree(s));
            }
            return listJsonNodes;
        } catch (Exception e) {
            return null;
        }
    }

    public static HashMap<String, String> getPropertiesMap(Object o) {
        HashMap<String, String> propertiesASMap = new HashMap<>();
        try {
            Class<?> clazz = o.getClass();
            Field[] fields = clazz.getDeclaredFields();
            for (Field field : fields) {
                field.setAccessible(true);
                try {
                    Object valueType = field.get(o);
                    String value = null;
                    if (valueType instanceof List<?> list && !list.isEmpty()) {
                        value = String.join(",", (List<String>) list);
                    } else if (valueType instanceof BigDecimal) {
                        value = valueType.toString();
                    } else if (valueType instanceof String v) {
                        value = v;
                    }
                    if (value != null)
                        propertiesASMap.put(field.getName(), value);
                } catch (IllegalAccessException e) {
                    //ignore
                }
            }
            return propertiesASMap;
        } catch (Exception e) {
            return propertiesASMap;
        }

    }

    public static List<Map<String, String>> parseToJson(String xmlData) {
        List<Map<String, String>> resultList = new ArrayList<>();
        String[] pairs = xmlData.replaceAll(BRACKET, EMPTY_STRING).split(COMMA);
        Map<String, String> dataMap = new HashMap<>();
        for (String pair : pairs) {
            String[] keyValue = pair.split(EQUAL);
            if (keyValue.length == TWO)
                dataMap.put(keyValue[ZERO].trim(), keyValue[ONE].trim());
        }
        resultList.add(dataMap);
        return resultList;
    }
}