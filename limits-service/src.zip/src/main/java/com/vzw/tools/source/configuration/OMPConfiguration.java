package com.vzw.tools.source.configuration;

import com.vzw.tools.source.properties.OMPProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;

@Component
public class OMPConfiguration {

    private final OMPProperties ompProperties;

    public OMPConfiguration(OMPProperties ompProperties) {
        this.ompProperties = ompProperties;
    }

    @Bean(name = "ompDataSource")
    public DataSource ompDataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setUrl(ompProperties.getUrl());
        dataSource.setUsername(ompProperties.getUsername());
        dataSource.setPassword(ompProperties.getPassword());
        return dataSource;
    }

    @Bean(name = "ompJdbcTemplate")
    public JdbcTemplate ompJbcTemplate() {
        return new JdbcTemplate(ompDataSource());
    }
}