package com.vzw.tools.common.exception;


import java.util.Map;

public interface ExceptionTranslator {
    FCToolsMSException translate(Throwable var1);

    default boolean canTranslate(Throwable t) {
        return false;
    }

    default boolean canTranslate(int httpCode) {
        return false;
    }

    default FCToolsMSException translate(int httpCode, String httpPhrase) {
        FCToolsMSException exception = new FCToolsMSException();
        ErrorResponse errorResponse = new ErrorResponse("" + httpCode, httpPhrase);
        exception.setErrorResponse(errorResponse);
        return exception;
    }

    default Object asResponse(Throwable t, Map<String, String> headers, Map<String, Object> context) {
        return "{\"exception\":\"" + t.getMessage() + "\"}";
    }

    default int asHttpStatus(Throwable t, Map<String, String> headers, Map<String, Object> context, Object httpResponse) {
        return 500;
    }
}
