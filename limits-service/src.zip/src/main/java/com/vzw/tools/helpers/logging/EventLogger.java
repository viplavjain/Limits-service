package com.vzw.tools.helpers.logging;



public interface EventLogger {
    void logEvent(Event event);
}
