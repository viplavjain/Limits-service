package com.vzw.tools.common.exception;

public enum ErrorType {
    VALIDATION_ERROR,
    BUSINESS_ERROR;

    private ErrorType() {
    }
}