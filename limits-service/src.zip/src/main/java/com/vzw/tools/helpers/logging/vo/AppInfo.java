package com.vzw.tools.helpers.logging.vo;

public class AppInfo {
    private String name;
    private String projectApplicationVSAD;
    private int vastId;

    public AppInfo() {
    }

    public String getName() {
        return this.name;
    }

    public String getProjectApplicationVSAD() {
        return this.projectApplicationVSAD;
    }

    public int getVastId() {
        return this.vastId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setProjectApplicationVSAD(String projectApplicationVSAD) {
        this.projectApplicationVSAD = projectApplicationVSAD;
    }

    public void setVastId(int vastId) {
        this.vastId = vastId;
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        } else if (!(o instanceof AppInfo)) {
            return false;
        } else {
            AppInfo other = (AppInfo)o;
            if (!other.canEqual(this)) {
                return false;
            } else if (this.getVastId() != other.getVastId()) {
                return false;
            } else {
                Object this$name = this.getName();
                Object other$name = other.getName();
                if (this$name == null) {
                    if (other$name != null) {
                        return false;
                    }
                } else if (!this$name.equals(other$name)) {
                    return false;
                }

                Object this$projectApplicationVSAD = this.getProjectApplicationVSAD();
                Object other$projectApplicationVSAD = other.getProjectApplicationVSAD();
                if (this$projectApplicationVSAD == null) {
                    if (other$projectApplicationVSAD != null) {
                        return false;
                    }
                } else if (!this$projectApplicationVSAD.equals(other$projectApplicationVSAD)) {
                    return false;
                }

                return true;
            }
        }
    }

    protected boolean canEqual(Object other) {
        return other instanceof AppInfo;
    }

    public int hashCode() {
       // int PRIME = true;
        int result = 1;
        result = result * 59 + this.getVastId();
        Object $name = this.getName();
        result = result * 59 + ($name == null ? 43 : $name.hashCode());
        Object $projectApplicationVSAD = this.getProjectApplicationVSAD();
        result = result * 59 + ($projectApplicationVSAD == null ? 43 : $projectApplicationVSAD.hashCode());
        return result;
    }

    public String toString() {
        String var10000 = this.getName();
        return "AppInfo(name=" + var10000 + ", projectApplicationVSAD=" + this.getProjectApplicationVSAD() + ", vastId=" + this.getVastId() + ")";
    }
}
