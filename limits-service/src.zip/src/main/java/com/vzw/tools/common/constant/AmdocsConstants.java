package com.vzw.tools.common.constant;

import java.util.Arrays;
import java.util.List;

public class AmdocsConstants {

    public static final String AMDOCS_API = "https://catalogone-apigw-qa2-at-npge.ebiz.verizon.com/entitySearchServices/v1/search/related/ids";
    public static final String PRODUCT_OFFER_SEARCH = "productOfferSearch";
    public static final String PRODUCT_OFFER = "productOffer";
    public static final String PRODUCT_OFFER_GROUP = "productOfferGroup";
    public static final String PRODUCT_OFFER_GROUP_SEARCH = "productOfferGroupSearch";
    public static final String PRODUCT_OFFER_PRICE = "productOfferPrice";
    public static final String PRODUCT_SPECIFICATION_SKU = "productSpecificationSku";
    public static final String PRODUCT_SPECIFICATION_PRD = "productSpecificationPrd";
    public static final String AMDOCS_DOCUMENT_ID_FETCH_API = "https://catalogone-apigw-qa2-at-npge.ebiz.verizon.com/entitySearchServices/v1/search/combined";
    public static final String AMDOCS_DOCUMENT_SEARCH_JSON = "amdocs_searchapi_request.json";
    public static final String AMDOCS_PRODUCT_OFFER_JSON = "productoffering_request.json";
    public static final String AMDOCS_PRODUCT_OFFERGROUP_JSON = "productofferinggroup_request.json";
    public static final String AMDOCS_PRODUCT_OFFERGROUP_SEARCH_JSON = "productofferinggroup_request_search_based_on_PO_documentId.json";
    public static final String AMDOCS_PRODUCT_SPECIFICATION_JSON = "productspecification_request.json";
    public static final List<String> fieldsWithLocalizedValues =
            Arrays.asList("carrier","manufacturer", "operatingSystem", "productUniversalAccessories");

    public static final String PRODUCT_OFFERING = "productOffering";
    public static final String PRODUCT_OFFERING_GROUP = "productOfferingGroup";
    public static final String DISPLAYNAME = "displayName";
    public static final String CARRIER = "carrier";
    public static final String COMMITMENT = "Commitment";
    public static final String VZ_PRICE_TYPE = "vz_price_type";
    public static final String CP = "CP";
    public static final String DOCUMENTNAME = "documentName";
    public static final String PRICE_CODE_REGEX = "\\.?0+$";
    public static final String SOR = "SOR";
    public static final String SKU = "sku";

    public static final String PROMO_OFFER_SEARCH = "promoOfferSearch";
    public static final String PRICE_RECORDS = "PRICE_RECORDS";
    public static final String TOKEN_SERVICE = "Token Service";
    public static final String PROMOTIONS = "promotions";
    public static final String PRICES = "prices";
    public static final String DOCUMENT_ID = "documentID";
    public static final String LEVEL = "level";
    public static final String WORKSTREAM = "WORKSTREAM";

    private AmdocsConstants() {
    }
}

