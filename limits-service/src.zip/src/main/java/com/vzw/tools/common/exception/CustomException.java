package com.vzw.tools.common.exception;

import lombok.Getter;

@Getter
public class CustomException extends RuntimeException {
    private final String errorMessage;
    private final String errorCode;

    public CustomException(String errorMessage, String errorCode) {
        this.errorMessage = errorMessage;
        this.errorCode = errorCode;
    }
}
