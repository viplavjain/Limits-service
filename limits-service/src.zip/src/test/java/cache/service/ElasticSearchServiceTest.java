package cache.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.vzw.tools.FederatedCatalogToolsMsApplication;
import com.vzw.tools.cache.configuration.ElasticSearchConfigurations;
import com.vzw.tools.cache.properties.ElasticSearchProperties;
import com.vzw.tools.cache.service.ElasticSearchService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.IOException;
import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;


import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;
import com.fasterxml.jackson.databind.ObjectMapper;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ContextConfiguration(classes = FederatedCatalogToolsMsApplication.class)
@SpringBootTest
public class ElasticSearchServiceTest {

    @Mock
    ElasticSearchProperties elasticSearchProperties;
    @Mock
    ElasticSearchConfigurations esConfiguration;
    @SpyBean
    ElasticSearchService elasticSearchService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testElasticSearchPromotionData() throws IOException {
        JsonNode mockResp=new ObjectMapper().createObjectNode().put("Status","Success");
        WebClient webClient= Mockito.mock(WebClient.class);
        WebClient.RequestBodyUriSpec requestBodyUriSpec=Mockito.mock(WebClient.RequestBodyUriSpec.class);
        WebClient.RequestBodySpec requestBodySpec=Mockito.mock(WebClient.RequestBodySpec.class);
        WebClient.RequestHeadersSpec requestHeadersSpec=Mockito.mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpec=Mockito.mock( WebClient.ResponseSpec.class);
        doReturn(webClient).when(elasticSearchService).getWebClient();
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.headers(any(Consumer.class))).thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(JsonNode.class)).thenReturn(Mono.just(mockResp));
        when(elasticSearchProperties.getApiUrl()).thenReturn("apiUrl");

        StepVerifier.create(elasticSearchService.elasticSearchPromotionData("32434"))
                .expectNextCount(1)
                .verifyComplete();
    }

    @Test
    void testGetClient()
    {
       WebClient webClient= elasticSearchService.getWebClient();
       assertNotNull(webClient);
    }
}
