package cache.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.tools.cache.controller.CacheController;
import com.vzw.tools.cache.service.ElasticSearchService;
import com.vzw.tools.cache.service.RedisService;
import com.vzw.tools.common.exception.ErrorBuilder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

import java.io.IOException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class CacheControllerTest {

    @Mock
    ElasticSearchService esService;

    @Mock
    RedisService redisService;
    @Mock
    ErrorBuilder errorBuilder;
    @InjectMocks
    CacheController cacheController;
    private WebTestClient webTestClient;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        cacheController = new CacheController(redisService, esService, errorBuilder);
        webTestClient = WebTestClient.bindToController(new CacheController(redisService, esService, errorBuilder))
                .configureClient()
                .build();
    }

    @Test
    void testGetElasticSearchData() throws IOException {
        String productType = "Promotion";
        String env = "qa2";
        String sorId = "ADR6400LVW";
        JsonNode mockResp = new ObjectMapper().createObjectNode().put("Status", "Success");
        when(esService.elasticSearchPromotionData(any())).thenReturn(Mono.just(mockResp));
        webTestClient.get().uri("/elasticSearch/{productType}/{env}?id={sorId}", productType, env, sorId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus()
                .isOk();
    }

}
