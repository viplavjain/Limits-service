package compare.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.vzw.tools.common.entity.EntityResponse;
import com.vzw.tools.common.exception.XmlConversionException;
import com.vzw.tools.compare.controller.ComparatorController;
import com.vzw.tools.compare.service.ComparatorService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.reactive.server.WebTestClient;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class ComparatorControllerTest {

    @Mock
    private ComparatorService comparatorService;
    @InjectMocks
    private ComparatorController comparatorController;

    private WebTestClient webTestClient;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        webTestClient = WebTestClient.bindToController(comparatorController).build();
    }

//    @Test
//    void testCompareJsonObjets() throws XmlConversionException, JsonProcessingException {
//
//        EntityResponse entityResponse = new EntityResponse();
//        when(comparatorService.compare(anyString(),anyString(),anyString() )).thenReturn(entityResponse);
//
//        webTestClient.get()
//                .uri("/compareJson/device/qa2?sorId=ADR6400LVW")
//                .exchange()
//                .expectStatus()
//                .isOk()
//                .expectHeader()
//                .contentType("application/json")
//                .expectBody(EntityResponse.class)
//                .isEqualTo(entityResponse);
//        verify(comparatorService, times(1)).compare("ADR6400LVW", "device", "qa2" );
//    }

//    @Test
//    void testCompareJsonObjects_NullResponse() throws Exception {
//
//        String productType = "device";
//        String end = "qa2";
//        String sorId = "ADR6400LVW";
//
//        when(comparatorService.compare(sorId, productType, end)).thenReturn(null);
//        ResponseEntity<EntityResponse> response = comparatorController.compareJsonObjects(productType, end, sorId);
//        assertEquals(404, response.getStatusCodeValue());
//    }
}

