package com.vzw.tools.persistence.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.vzw.tools.common.exception.ErrorBuilder;
import com.vzw.tools.common.exception.XmlConversionException;
import com.vzw.tools.persistence.service.CassandraService;
import com.vzw.tools.persistence.service.FedCatalogGetDataService;

import reactor.core.publisher.Mono;

class PersistenceControllerTest {
    @InjectMocks
    private PersistenceController persistenceController;
    private WebTestClient webTestClient;
    @Mock
    private CassandraService cassandraService;
    @Mock
    private FedCatalogGetDataService fedCatalogService;
    @Mock
    private ErrorBuilder errorBuilder;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        persistenceController = new PersistenceController(cassandraService, fedCatalogService, errorBuilder);
        webTestClient = WebTestClient.bindToController(new PersistenceController(cassandraService, fedCatalogService, errorBuilder))
                .configureClient()
                .build();
    }

    @Test
    void testGetCassandraDeviceDetails() {
        String productType = "Device";
        String env = "qa2";
        String sorId = "ADR6400LVW";

        JsonNode jsonNode = JsonNodeFactory.instance.objectNode().put("message", "Success");

        when(cassandraService.getDeviceDetailsUpdated(any(), any(),any())).thenReturn(Mono.just(jsonNode));
        webTestClient.get().uri("/cassandra/{productType}/{env}?id={sorId}", productType, env, sorId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus()
                .isOk()
                .expectHeader()
                .contentType(MediaType.APPLICATION_JSON)
                .expectBody(JsonNode.class)
                .isEqualTo(jsonNode);
        verify(cassandraService, times(1)).getDeviceDetailsUpdated(sorId, productType, env);
    }

    @Test
    void testGetFedCatalogDeviceDetails() throws XmlConversionException {
        String productType = "Device";
        String env = "qa2";
        String sorId = "ADR6400LVW";
        HashMap<String, String> mapResult = new HashMap<>();
        when(fedCatalogService.fedCatalogDeviceDetails(any(), any(), any())).thenReturn(Mono.just(mapResult));
        webTestClient.get().uri("/fedCatalogDetails/{productType}/{env}?id={sorId}", productType, env, sorId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus()
                .isOk();
    }
}
