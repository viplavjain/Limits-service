package com.vzw.tools.source.service;

import com.vzw.tools.common.exception.DataBaseException;
import com.vzw.tools.helpers.jdbc.DeviceDpiJdbcReactiveHelper;
import com.vzw.tools.source.dao.DeviceDPIDAO;
import com.vzw.tools.source.repository.DPIRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.vzw.tools.common.constant.CommonConstants.*;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
 class DPIServiceTest {

    @Mock
    public JdbcTemplate jdbcTemplate;
    @InjectMocks
    private DPIService dpiService;
    @Mock
    private DPIRepository dpiRepository;

    @Mock
    private DeviceDpiJdbcReactiveHelper deviceDpiJdbcReactiveHelper;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }


    @Test
    void testFetchDeviceDPI() throws DataBaseException {
        String sorId = "ADR6400LVW";
        DPIService spyService = spy(dpiService);
        HashMap<String, Object> map = new HashMap<>();
        map.put("key", "value");
        Mockito.lenient().when(dpiRepository.fetchDeviceDPI(any())).thenReturn(map);
        Map<String, Object> result = spyService.getDeviceDPI(sorId);
        assertNotNull(result);
    }

    @Test
    void testFetchDeviceDPIDetails() {
        String sorId = "ADR6400LVW";
        DPIService spyService = spy(dpiService);
        DeviceDPIDAO deviceDPIDAO = new DeviceDPIDAO();
        deviceDPIDAO.setSku("sku");
        when(deviceDpiJdbcReactiveHelper.retrieveDPIResponse(any())).thenReturn(Mono.just(deviceDPIDAO));
        Mono<DeviceDPIDAO> result = spyService.getDPIDeviceDetails(sorId, "Device", "test");
        assertNotNull(result);
    }

    @Test
    void testFetchDeviceDPIDao() throws DataBaseException {
        DPIService spyService = spy(dpiService);

        HashMap<String, Object> deviceDPIDataMap = new HashMap<>();

        deviceDPIDataMap.put(SKU, "");
        deviceDPIDataMap.put(SKU_TYPE, "");
        deviceDPIDataMap.put(LOCATION_CODE, "");
        BigDecimal bigDecimal = BigDecimal.valueOf(123.2);
        deviceDPIDataMap.put(FULL_RETAIL_PRICE, bigDecimal);
        deviceDPIDataMap.put(ONE_YEAR_PRICE, bigDecimal);
        deviceDPIDataMap.put(TWO_YEAR_PRICE, bigDecimal);
        deviceDPIDataMap.put(PREPAY_PRICE, bigDecimal);
        deviceDPIDataMap.put(EDGE_SKU, "");
        deviceDPIDataMap.put(EDGE_FULL_RETAIL_PRICE, bigDecimal);

        List<Map<String, Object>> mapList = new ArrayList<>();
        mapList.add(deviceDPIDataMap);
        HashMap<String, Object> deviceDPIDao = new HashMap<>();

        Mockito.lenient().when(dpiRepository.fetchDeviceDPI(any())).thenReturn(deviceDPIDao);
        DeviceDPIDAO res = spyService.mapDeviceDPIResult(deviceDPIDataMap);
        assertNotNull(res);
    }

}