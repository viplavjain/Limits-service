package com.vzw.tools.source.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.vzw.tools.common.exception.ErrorBuilder;
import com.vzw.tools.common.exception.FCToolsMSException;
import com.vzw.tools.source.dao.DeviceDPIDAO;
import com.vzw.tools.source.service.DMDService;
import com.vzw.tools.source.service.DPIService;
import com.vzw.tools.source.service.OMPService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class SourceControllerTest {

    @Mock
    private DMDService dmdService;
    @Mock
    private DPIService dpiService;
    @Mock
    private OMPService ompService;
    @InjectMocks
    private SourceController sourceController;

    @Mock
    private ErrorBuilder errorBuilder;

    private WebTestClient webTestClient;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        sourceController = new SourceController(dmdService, dpiService, errorBuilder, ompService);
        webTestClient = WebTestClient.bindToController(new SourceController(dmdService, dpiService, errorBuilder, ompService))
                .configureClient()
                .build();
    }

    @Test
    void testGetDMD() throws Exception {
        String productType = "Device";
        String env = "qa2";
        String id = "ADR6400LVW";

        JsonNode jsonNode = JsonNodeFactory.instance.objectNode().put("message", "Success");

        when(dmdService.getDMDDetails(id, productType)).thenReturn(Mono.just(jsonNode));
        webTestClient.get().uri("/dmd/{productType}/{env}?id={id}", productType, env, id)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus()
                .isOk()
                .expectHeader()
                .contentType(MediaType.APPLICATION_JSON)
                .expectBody(JsonNode.class)
                .isEqualTo(jsonNode);
        verify(dmdService, times(1)).getDMDDetails(id, productType);
    }

    @Test
    void testGetDMDThrowsException() throws Exception {
        String productType = "Device";
        String env = "qa2";
        String id = "ADR6400LVW";

        when(dmdService.getDMDDetails(id, productType)).thenReturn(Mono.error(
                new IllegalAccessException("IllegalAccessException occurred")
        ));
        webTestClient.get().uri("/dmd/{productType}/{env}?id={id}", productType, env, id)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus()
                .is5xxServerError();
        verify(dmdService, times(1)).getDMDDetails(id, productType);
    }

    @Test
    void testGetDPI()  {
        String productType = "Device";
        String env = "qa2";
        String id = "ADR6400LVW";

        DeviceDPIDAO dpiDao = populateDPIDAO();
        when(dpiService.getDPIDeviceDetails(id, productType, env)).thenReturn(Mono.just(dpiDao));
        webTestClient.get().uri("/dpi/{productType}/{env}?id={id}", productType, env, id)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus()
                .isOk()
                .expectHeader()
                .contentType(MediaType.APPLICATION_JSON)
                .expectBody(DeviceDPIDAO.class);
        verify(dpiService, times(1)).getDPIDeviceDetails(id, productType, env);
    }

    @Test
    void testGetDPIThrowsException()  {
        String productType = "Device";
        String env = "qa2";
        String id = "ADR6400LVW";

        when(dpiService.getDPIDeviceDetails(id, productType, env)).thenReturn(Mono.error(
                new IllegalAccessException("IllegalAccessException occurred")
        ));
        webTestClient.get().uri("/dpi/{productType}/{env}?id={id}", productType, env, id)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus()
                .is5xxServerError();
        verify(dpiService, times(1)).getDPIDeviceDetails(id, productType, env);
    }

    @Test
    void testGetDMDAccessory() throws Exception {
        String productType = "Accessory";
        String env = "qa2";
        String id = "ADR6400LVW";

        JsonNode jsonNode = JsonNodeFactory.instance.objectNode().put("message", "Success");

        when(dmdService.getDMDDetails(id, productType)).thenReturn(Mono.just(jsonNode));
        webTestClient.get().uri("/dmd/{productType}/{env}?id={id}", productType, env, id)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus()
                .isOk()
                .expectHeader()
                .contentType(MediaType.APPLICATION_JSON)
                .expectBody(JsonNode.class)
                .isEqualTo(jsonNode);
        verify(dmdService, times(1)).getDMDDetails(id, productType);
    }

    @Test
    void testGetOMP()  {

        String productType = "Promotions";
        String env = "QA1";
        String offerId = "403300~1";

        Map<String, String> ompData = new HashMap<>();
        ompData.put("key1", "value1");
        ompData.put("key2", "value2");

        when(ompService.getOMPPromotionDetails(offerId, productType, env)).thenReturn(Mono.just(ompData));
        webTestClient.get().uri("/omp/{productType}/{env}?id={offerId}", productType, env, offerId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus()
                .isOk()
                .expectHeader()
                .contentType(MediaType.APPLICATION_JSON)
                .expectBody(Map.class)
                .isEqualTo(ompData);
        verify(ompService, times(1)).getOMPPromotionDetails(offerId, productType, env);
    }

    @Test
    void testGetOMP_when_exception_occurs() {

        String productType = "Device";
        String env = "qa2";
        String offerId = "123456";

        when(ompService.getOMPPromotionDetails(offerId, productType, env)).thenReturn(Mono.error(
                new IllegalAccessException("IllegalAccessException occurred")
        ));

        webTestClient.get().uri("/omp/{productType}/{env}?id={offerId}", productType, env, offerId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus()
                .is5xxServerError();

        verify(ompService, times(1)).getOMPPromotionDetails(offerId, productType, env);

    }

    @Test
    void testGetOMP_when_exception_FCToolsMSException_occurs()  {

        String productType = "Device";
        String env = "qa2";
        String offerId = "123456";

        when(ompService.getOMPPromotionDetails(offerId, productType, env)).thenReturn(Mono.error(
                new FCToolsMSException()
        ));

        webTestClient.get().uri("/omp/{productType}/{env}?id={offerId}", productType, env, offerId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus()
                .is5xxServerError();

        verify(ompService, times(1)).getOMPPromotionDetails(offerId, productType, env);

    }

    private DeviceDPIDAO populateDPIDAO() {
        DeviceDPIDAO dpiDao = new DeviceDPIDAO();
        dpiDao.setSku("sku");
        dpiDao.setSkuType("skuType");
        dpiDao.setOneYearPrice(BigDecimal.valueOf(312.00));
        dpiDao.setTwoYearPrice(BigDecimal.valueOf(312.00));
        dpiDao.setPrepayPrice(BigDecimal.valueOf(312.00));
        dpiDao.setFullRetailPrice(BigDecimal.valueOf(312.00));
        dpiDao.setLocationCode("locationCode");
        dpiDao.setEdgeSku("DeviceDPContextContextContext");
        dpiDao.setEdgeFullRetailPrice(BigDecimal.valueOf(312.00));
        return dpiDao;
    }

}
