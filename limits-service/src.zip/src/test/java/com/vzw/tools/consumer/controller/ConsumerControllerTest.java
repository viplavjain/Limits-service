package com.vzw.tools.consumer.controller;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.vzw.tools.common.exception.ErrorBuilder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.vzw.tools.consumer.service.CXPService;

import reactor.core.publisher.Mono;

@RunWith(MockitoJUnitRunner.class)
class ConsumerControllerTest {

	@Mock
	private CXPService cxpService;
	@InjectMocks
	private ConsumerController consumerController;

	private WebTestClient webTestClient;
	@Mock
	private ErrorBuilder errorBuilder;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
		consumerController = new ConsumerController(cxpService,errorBuilder);
		webTestClient = WebTestClient.bindToController(new ConsumerController(cxpService,errorBuilder)).configureClient().build();
	}

	@Test
	void testGetCXPDeviceDetails() {
		String productType = "Device";
		String env = "qa2";
		String id = "ADR6400LVW";

		JsonNode jsonNode = JsonNodeFactory.instance.objectNode().put("message", "Success");

		when(cxpService.getCXPCatalogDetails(id, productType, env)).thenReturn(Mono.just(jsonNode));
		webTestClient.get().uri("/cxp/{productType}/{env}?id={sorId}", productType, env, id)
				.accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk().expectHeader()
				.contentType(MediaType.APPLICATION_JSON).expectBody(JsonNode.class).isEqualTo(jsonNode);
		verify(cxpService, times(1)).getCXPCatalogDetails(id, productType, env);
	}
}
