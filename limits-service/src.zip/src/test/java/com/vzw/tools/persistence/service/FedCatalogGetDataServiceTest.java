package com.vzw.tools.persistence.service;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.vzw.tools.FederatedCatalogToolsMsApplication;
import com.vzw.tools.common.exception.ConverterException;
import com.vzw.tools.common.exception.XmlConversionException;
import com.vzw.tools.persistence.configuration.FederatedDBConfiguration;
import com.vzw.tools.source.configuration.RunTimeMapInitializer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedCaseInsensitiveMap;
import reactor.core.publisher.Mono;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@SpringBootTest
@ContextConfiguration(classes = FederatedCatalogToolsMsApplication.class)
class FedCatalogGetDataServiceTest {

    @Mock
    FederatedDBConfiguration fedCatalogConfiguration;
    @MockBean
    RunTimeMapInitializer runTimeMapInitializer;
    @SpyBean
    FedCatalogGetDataService fedCatalogGetDataService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFedCatalogDeviceDetails() throws XmlConversionException, SQLException {
        String sorId = "abc23";
        String productType = "device";
        String env = "qaa1";
        SimpleJdbcCall simpleJdbcCall = Mockito.mock(SimpleJdbcCall.class);
        Map<String, Object> result = new HashMap<>();
        ArrayList<LinkedCaseInsensitiveMap<Object>> al = new ArrayList<LinkedCaseInsensitiveMap<Object>>();
        LinkedCaseInsensitiveMap<Object> obj = new LinkedCaseInsensitiveMap<Object>();
        obj.put("A", "obj");
        obj.put("B", null);
        al.add(obj);
        result.put("P_RESULT_SET", al);
        doReturn(simpleJdbcCall).when(fedCatalogGetDataService).getSimpleJdbcCall(sorId, productType, env);
        Mono<Map<String, String>> map = fedCatalogGetDataService.fedCatalogDeviceDetails(sorId, productType, env);
        Mockito.when(simpleJdbcCall.execute(any(MapSqlParameterSource.class))).thenReturn(result);
        fedCatalogGetDataService.fedCatalogDeviceDetails(sorId, productType, env);
        assertNotNull(map);
    }

    @Test
    void testGetSimpleJdbcCall() {
        String sorId = "abc23";
        String productType = "device";
        String env = "qaa1";
        JdbcTemplate jdbcTemp = Mockito.mock(JdbcTemplate.class);

        Mockito.when(fedCatalogConfiguration.jdbcTemplateForEnv(any())).thenReturn(jdbcTemp);
        verify(fedCatalogConfiguration, never()).jdbcTemplateForEnv(any());

        fedCatalogGetDataService.getSimpleJdbcCall(sorId, productType, env);
    }

    @Test
    void testRetreiveStoredProcedure() {

        String result = fedCatalogGetDataService.retreiveStoredProcedure("Device");
        assertEquals("SP_FEDCATALOG_DEVICE", result);
        result = fedCatalogGetDataService.retreiveStoredProcedure("Accessory");
        assertEquals("SP_FEDCATALOG_ACCESSORY", result);
        result = fedCatalogGetDataService.retreiveStoredProcedure("ABC");
        assertEquals(" ", result);
    }

    @Test
    void testGetFederatedCatalogMappedJson(){

        Map<String, String> federatedCatalogMapWithApiValues=new HashMap<>();
        String productType = "Device";
        federatedCatalogMapWithApiValues.put("key","Value1");
        HashMap<String, String> outMap=new HashMap<>();
        outMap.put("key","Value");
        when(runTimeMapInitializer.getFedCatalogMap(productType)).thenReturn(outMap);
        ReflectionTestUtils.invokeMethod(fedCatalogGetDataService,"getFederatedCatalogMappedJson",federatedCatalogMapWithApiValues,productType) ;
    }

}

