package com.vzw.tools.source.service;

import com.vzw.tools.common.exception.ErrorBuilder;
import com.vzw.tools.helpers.jdbc.OMPJdbcReactiveHelper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

class OMPServiceTest {

    @Mock
    private JdbcTemplate jdbcTemplate;
    @Mock
    private OMPJdbcReactiveHelper ompJdbcReactiveHelper;
    @Mock
    private ErrorBuilder errorBuilder;
    @InjectMocks
    private OMPService ompService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getOMPPromotionDetails_Success() {
        String offerId = "12345~1";
        String productType = "Promotions";
        String env = "QA1";

        Mono<Map<String, String>> mono = Mono.just(new HashMap<>() {
            {
                put("key1", "value1");
                put("key2", "value2");
            }
        });
        when(ompJdbcReactiveHelper.retrieveOMPResponse(offerId)).thenReturn(mono);
        Mono<Map<String, String>> result = ompService.getOMPPromotionDetails(offerId, productType, env);
        assertNotNull(result);
        assertEquals(2, Objects.requireNonNull(result.block()).size());
    }

    @Test
    void getOMPPromotionDetails_Error() {
        String offerId = "12345~1";
        String productType = "Promotions";
        String env = "QA1";

        when(ompJdbcReactiveHelper.retrieveOMPResponse(offerId)).thenReturn(Mono.error(
                new RuntimeException()
        ));
        Mono<Map<String, String>> result = ompService.getOMPPromotionDetails(offerId, productType, env);
        assertThrows(RuntimeException.class, result::block);
    }
}