package com.vzw.tools.consumer.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.vzw.tools.common.exception.ConverterException;
import com.vzw.tools.common.util.JsonToObjectConverter;
import com.vzw.tools.consumer.configuration.FusionConfiguration;
import com.vzw.tools.consumer.service.FusionService;
import com.vzw.tools.source.configuration.RunTimeMapInitializer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

class FusionServiceTest {

    @InjectMocks
    FusionService fusionService;

    @Mock
    private FusionConfiguration fusionConfiguration;

    @Mock
    private RunTimeMapInitializer runTimeMapInitializer;

    private JsonNode jsonNode;

    @Mock
    private WebClient.Builder webClientBuilder;

    @Mock
    private WebClient webClient;

    @Mock
    private WebClient.RequestHeadersUriSpec requestHeadersUriSpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @BeforeEach
    void setUp() throws ConverterException {

        MockitoAnnotations.openMocks(this);
        String env = "qa1";
        when(fusionConfiguration.getHost(env)).thenReturn("https://mocked-url.com");
        when(fusionConfiguration.getUsername(env)).thenReturn("user");
        when(fusionConfiguration.getPassword(env)).thenReturn("pass");
        when(fusionConfiguration.getSearch_By_SOR_API_URL()).thenReturn("/fusion/search");
        when(fusionConfiguration.getHost(env)).thenReturn("https://mocked-url.com");
        when(fusionConfiguration.getUsername(env)).thenReturn("user");
        when(fusionConfiguration.getPassword(env)).thenReturn("pass");
        when(fusionConfiguration.getSearch_By_SOR_API_URL()).thenReturn("/fusion/search");
        when(webClientBuilder.build()).thenReturn(webClient);
        when(webClient.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(anyString())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.headers(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        jsonNode = JsonToObjectConverter.jsonToObject("fusionResponse.json", JsonNode.class);
        ReflectionTestUtils.setField(fusionService,"timeoutInSeconds",10);
    }

    @Test
    void testGetFusionServiceDetails() {
        String sorID = "asv";
        String productType = "device";
        String env = "qa1";

        when(responseSpec.bodyToMono(JsonNode.class)).thenReturn(Mono.just(jsonNode));

        Mono<JsonNode> fusionResponse = fusionService.getFusionServiceDetails(sorID, productType,env);
        assertNotNull(fusionResponse);
    }

    @Test
    void testGetFusionMappedJson() {
        String ispuEligible = "ispuEligible";
        HashMap<String,String> fusionGenericKeMap = new HashMap<>();
        fusionGenericKeMap.put(ispuEligible,"sku_in_store_pickup_flag_b");
        when(runTimeMapInitializer.getFusionMap("Device")).thenReturn(fusionGenericKeMap);
        Mono<Map<String, String>> fusionMappedJson = fusionService.getFusionMappedJson(jsonNode,"Device");

        fusionMappedJson.subscribe(map -> {
            assertEquals("true", map.get(ispuEligible));
        });
    }

    @Test
    void getFusionServiceDetails_WebClientException() {
        WebClientResponseException webClientException = WebClientResponseException.create(
                500, "Internal Server Error", null, "Error".getBytes(StandardCharsets.UTF_8), null
        );
        String sorID = "asv";
        String productType = "device";
        String env = "qa1";

        when(responseSpec.bodyToMono(JsonNode.class)).thenReturn(Mono.error(webClientException));

        assertThrows(WebClientRequestException.class, () -> {
            Mono<JsonNode> result = fusionService.getFusionServiceDetails(sorID, productType, env);
            result.block();
        });// Should return default response (empty Mono)

    }
}

