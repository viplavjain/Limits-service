package com.vzw.tools.source.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.vzw.tools.common.exception.ConverterException;
import com.vzw.tools.common.exception.DataBaseException;
import com.vzw.tools.common.exception.ErrorBuilder;
import com.vzw.tools.common.exception.FCToolsMSException;
import com.vzw.tools.common.util.JsonToObjectConverter;
import com.vzw.tools.helpers.jdbc.DMDAccessoryJdbcReactiveHelper;
import com.vzw.tools.helpers.jdbc.DMDDeviceFamilyJdbcReactiveHelper;
import com.vzw.tools.helpers.jdbc.DMDJdbcReactiveHelper;
import com.vzw.tools.source.dao.AccessoryDMDDAO;
import com.vzw.tools.source.dao.DeviceDMDDAO;
import com.vzw.tools.source.dao.DeviceDMDFamilyDAO;
import com.vzw.tools.source.repository.DMDRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
 class DMDServiceTest {

    @Mock
    public JdbcTemplate jdbcTemplate;
    @InjectMocks
    private DMDService dmdService;

    @Mock
    private SimpleJdbcCall mockJdbccall;
    @Mock
    private DMDRepository dmdRepository;

    @Mock
    private DMDJdbcReactiveHelper dmdJdbcReactiveHelper;

    @Mock
    private DMDDeviceFamilyJdbcReactiveHelper dmdDeviceFamilyJdbcReactiveHelper;

    @Mock
    private DMDAccessoryJdbcReactiveHelper dmdAccessoryJdbcReactiveHelper;

    @Mock
    private ErrorBuilder errorBuilder;

    DeviceDMDFamilyDAO deviceDMDFamilyDAO;


    @BeforeEach
    void setUp() throws ConverterException {

        MockitoAnnotations.openMocks(this);
        deviceDMDFamilyDAO= JsonToObjectConverter.jsonToObject("dmdFamilyDao.json", DeviceDMDFamilyDAO.class);
    }

    @Test
   void testGetDMDDaoForDevice() throws DataBaseException {
        String sorId = "ADR6400LVW";
        String productType = "Device";
        String mockXml = "<DeviceDMDDao><deviceType>4GE</deviceType></DeviceDMDDao>";

        DMDService spyService = spy(dmdService);

        doReturn(Mono.just(mockXml)).when(spyService).getDMDXML(sorId, productType);

        Mono<Object> result = spyService.getDMDDao(sorId, productType);
        result.subscribe(dmdresult -> {
            assertTrue(dmdresult instanceof DeviceDMDDAO, "returned object is not of type DeviceDMDDAO");
            DeviceDMDDAO deviceDMDDAO = (DeviceDMDDAO) dmdresult;
            assertEquals("4GE", deviceDMDDAO.getDeviceType(), "Device type mismatch");
        });
    }

    @Test
    void testGetDMDDaoForAccessory() throws DataBaseException {

        String sorId = "ADR6400LVW";
       String productType = "Accessory";
        String mockXml = "<AccessoryDMDDAO><accessoryType>4GE</accessoryType></AccessoryDMDDAO>";

       DMDService spyService = spy(dmdService);

        doReturn(Mono.just(mockXml)).when(spyService).getDMDXML(sorId, productType);

        Mono<Object> result = spyService.getDMDDao(sorId, productType);
        result.subscribe(dmdresult -> {
            assertInstanceOf(AccessoryDMDDAO.class, dmdresult, "returned object is not of type AccessoryDMDDAO");
            AccessoryDMDDAO accessoryDMDDAO = (AccessoryDMDDAO) dmdresult;
            assertEquals("4GE", accessoryDMDDAO.getAccessoryType(), "Accessory type mismatch");
        });

   }


   @Test void testGetDMDDetails() throws DataBaseException {
  String sorId = "ADR6400LVW";
        String productType = "Device";
       String mockXml = "<DeviceDMDDao><sku>1224</sku></DeviceDMDDao>";

        DMDService spyService = spy(dmdService);

        doReturn(Mono.just(mockXml)).when(spyService).getDMDXML(sorId, productType);
        Mono<JsonNode> result = spyService.getDMDDetails(sorId, productType);

        result.subscribe(jsonNode ->{
            assertNotNull(jsonNode, "jsonNode is null");
            assertEquals("1224", jsonNode.get("sku").asText());
        });

   }

    @Test
    void testGetDMDDetailsWIthException() throws DataBaseException {

        String sorId = "ADR6400LVW";
        String productType = "Device";

        DMDService spyService = spy(dmdService);
        doThrow(new RuntimeException("Mock XML error")).when(spyService).getDMDXML(sorId, productType);

        assertThrows(RuntimeException.class, () -> spyService.getDMDDetails(sorId, productType));

    }

    @Test
    void testGetDMDDeviceFamilyDao() {
        String sorId = "ADR6400LVW";
        DMDService spyService = spy(dmdService);

        String mockXml = "<DeviceDMDFamilyDAO><familyName>4GE</familyName></DeviceDMDFamilyDAO>";
        when(dmdDeviceFamilyJdbcReactiveHelper.retrieveDMDDeviceFamilyResponse(sorId)).thenReturn(Mono.just(mockXml));
        Mono<DeviceDMDFamilyDAO> result =spyService.getDMDDeviceFamilyDao(sorId);
        result.subscribe(deviceDMDFamilyDao -> {
            assertNotNull(deviceDMDFamilyDao, "deviceDMDFamilyDAO is null");
        });


    }

    @Test
    void testGetDMDDeviceFamilyXML_Success() throws DataBaseException {
        String sorId = "ADR6400LVW";
        DMDService spyService = spy(dmdService);

        Map<String, Object> mockResult = new HashMap<>();
        mockResult.put("DEV_FAMILY_RESULTSET", "<DeviceDMDFamilyDAO><familyName>1224</familyName></DeviceDMDFamilyDAO>");
       Mockito.lenient().when(dmdRepository.fetchDeviceFamilyDMD(any())).thenReturn(mockResult);
        String res = spyService.getDMDDeviceFamilyXML(sorId);
        assertNotNull(res);

    }

    @Test
    void testGetDMDDetails_xmlParsingFails_throwsException() throws DataBaseException {
        // Malformed XML to force XmlMapper.readTree() to throw
        String invalidXml = "<Device><sku>123456"; // Missing closing tag
        String sorId = "ADR6400LVW";
        String productType = "Device";
        // Custom application exception returned by errorBuilder
        RuntimeException expectedException = new RuntimeException("Parsing error");
        FCToolsMSException expectedFCToolsMSException = new FCToolsMSException("Parsing error", "error",expectedException);
        DMDService spyService = spy(dmdService);
        // Mock getDMDXML to return malformed XML
        Mockito.doReturn(Mono.just(invalidXml))
                .when(spyService).getDMDXML(sorId, productType);

        // Mock errorBuilder to return custom exception
        Mockito.when(errorBuilder.buildApplicationException(Mockito.any()))
                .thenReturn(expectedFCToolsMSException);

        // Verify the Mono emits the expected exception
        StepVerifier.create(spyService.getDMDDetails(sorId, productType))
                .expectErrorMatches(throwable -> throwable.getMessage().equals("Parsing error"))
                .verify();
    }

    @Test
    void testGetDMDDAO_xmlParsingFails_throwsException() throws DataBaseException {
        // Malformed XML to force XmlMapper.readTree() to throw
        String invalidXml = "<Device><sku>123456"; // Missing closing tag
        String sorId = "ADR6400LVW";
        String productType = "Device";
        // Custom application exception returned by errorBuilder
        RuntimeException expectedException = new RuntimeException("Parsing error");
        FCToolsMSException expectedFCToolsMSException = new FCToolsMSException("Parsing error", "error",expectedException);
        DMDService spyService = spy(dmdService);
        // Mock getDMDXML to return malformed XML
        Mockito.doReturn(Mono.just(invalidXml))
                .when(spyService).getDMDXML(sorId, productType);

        // Mock errorBuilder to return custom exception
        Mockito.when(errorBuilder.buildApplicationException(Mockito.any()))
                .thenReturn(expectedFCToolsMSException);

        // Verify the Mono emits the expected exception
        StepVerifier.create(spyService.getDMDDao(sorId, productType))
                .expectErrorMatches(throwable -> throwable.getMessage().equals("Parsing error"))
                .verify();
    }


    @Test
   void testGetDMDXMLDevice_Success() throws DataBaseException {
        String sorId = "ADR6400LVW";
        String productType = "Device";
        String mockXml = "<DeviceDMDDao><deviceType>4GE</deviceType></DeviceDMDDao1>";
        DMDService spyService = spy(dmdService);
        when(dmdJdbcReactiveHelper.retrieveDMDResponse(sorId)).thenReturn(Mono.just(mockXml));
        when(spyService.getDMDDevice(sorId)).thenReturn(Mono.empty());
        Mono<String> res = spyService.getDMDXML(sorId, productType);
        assertNotNull(res);

    }

      @Test
      void testGetDMDXMLAccessory_Success() throws DataBaseException {
        String sorId = "ADR6400LVW";
        String mockXml = "<DeviceDMDDao><deviceType>4GE</deviceType></DeviceDMDDao1>";
        String productType = "Accessory";
        DMDService spyService = spy(dmdService);
        Mockito.lenient().when(dmdAccessoryJdbcReactiveHelper.retrieveDMDAccessoryResponse(sorId)).thenReturn(Mono.just(mockXml));
        Mockito.lenient().when(spyService.getDMDDevice(sorId)).thenReturn(Mono.just(mockXml));

        Mono<String> res = spyService.getDMDXML(sorId, productType);
        assertNull(res);

    }


}



