package com.vzw.tools.authoring.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.tools.authoring.configuration.EpcConfiguration;
import com.vzw.tools.authoring.dto.DeviceEpcDto;
import com.vzw.tools.authoring.entity.*;
import com.vzw.tools.common.constant.AmdocsConstants;
import com.vzw.tools.common.exception.ConverterException;
import com.vzw.tools.common.exception.CustomThrowableException;
import com.vzw.tools.common.exception.XmlConversionException;
import com.vzw.tools.common.service.TokenService;
import com.vzw.tools.common.util.GenericWebClient;
import com.vzw.tools.common.util.JsonToObjectConverter;
import com.vzw.tools.source.configuration.RunTimeMapInitializer;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class EPCServiceTest {

    @Mock
    private GenericWebClient genericWebClient;

    @Mock
    private TokenService tokenService;

    @Mock
    private RunTimeMapInitializer runTimeMapInitializer;

    @InjectMocks
    private EPCService epcService;

    @Mock
    private EpcConfiguration epcConfiguration;

    private ProductOfferSearchRequest searchRequest;

    private AmdocsSearchResponse mockAmdocsResponse;
    private ProductOfferingResponse mockProductOfferingResponse;
    private ProductOfferingPriceResponse mockProductOfferingPriceResponse;
    private DeviceEpcDto deviceEpcDto;
    private Token mockToken;

    @Mock
    ObjectMapper mapper;
    @BeforeEach
    void setUp() throws JsonProcessingException, ConverterException {
        // mockAmdocsResponse = populateAmdocsSearchResponse();
        //mockProductOfferingResponse = populateProductOfferingResponse();
        deviceEpcDto = new DeviceEpcDto();
        mockToken = new Token();
        searchRequest = createSearchRequest("2345");
        mockAmdocsResponse= JsonToObjectConverter.jsonToObject("amdocs_searchResponse.json", AmdocsSearchResponse.class);
        mockProductOfferingResponse= JsonToObjectConverter.jsonToObject("productOfferingResponse.json", ProductOfferingResponse.class);
        mockProductOfferingPriceResponse= JsonToObjectConverter.jsonToObject("productOfferingPriceResponse.json", ProductOfferingPriceResponse.class);
       // mapper = new ObjectMapper();
    }

//    @Test
//    void testGetEPCDeviceDetails_Success() throws JsonProcessingException, JsonProcessingException, ConverterException {
//       // Mock token service
//        when(tokenService.getToken("qa1")).thenReturn(Mono.just(mockToken));
//        when(epcConfiguration.getProductOfferingPrice("qa1")).thenReturn("https://catalogone-apigw-qa1b-at-npge.ebiz.verizon.com/catalogManagement/pricing/v2/price/%s/viewPriceRecord?level=WORKSTREAM");
//
//       // Mock WebClient API call
//       when(genericWebClient.callPostApi(any(), any(), any(), eq(ProductOfferingResponse.class),any()))
//               .thenReturn(Mono.just(mockProductOfferingResponse));
//
//       when(genericWebClient.callPostApi(any(), any(), any(), eq(AmdocsSearchResponse.class),any()))
//                .thenReturn(Mono.just(mockAmdocsResponse));
//
//        when(genericWebClient.callPostApi(any(), any(), eq(null), eq(ProductOfferingPriceResponse.class),any()))
//                .thenReturn(Mono.just(mockProductOfferingPriceResponse));
//
//       // Call the method
//       Mono<DeviceEpcDto> result = epcService.getEPCDeviceDetails("12345", "qa1","device");
//
//        // Verify interactions
//       verify(tokenService, times(1)).getToken("qa1");
//       Assertions.assertNotNull(result.block()); // Ensures no null response
//   }

    @Test
    void testGetEpcMappedJson_Success() throws JsonProcessingException, XmlConversionException, ConverterException {
        EPCService spyService = spy(epcService);
        doReturn(Mono.just(deviceEpcDto)).when(spyService).getEPCDeviceDetails(any(), any(),any());

        Mono<Map<String, String>> result = spyService.getEpcMappedJson1("12345", "testEnv","device");

        Assertions.assertNotNull(result);
    }

    @Test
    void testCreateSearchRequest_Success() throws JsonProcessingException, ConverterException {
        ProductOfferSearchRequest request = epcService.createSearchRequest("12345");
        Assertions.assertNotNull(request);
    }
//
//   @Test
//    void testFetchProductOffering_Success() throws JsonProcessingException {
//       when(epcConfiguration.getProductOfferingPrice("qa1")).thenReturn("https://catalogone-apigw-qa1b-at-npge.ebiz.verizon.com/catalogManagement/pricing/v2/price/%s/viewPriceRecord?level=WORKSTREAM");
//        when(genericWebClient.callPostApi(any(), any(), any(), eq(ProductOfferingResponse.class),any()))
//               .thenReturn(Mono.just(mockProductOfferingResponse));
//        when(genericWebClient.callPostApi(any(), any(), any(), eq(AmdocsSearchResponse.class),any()))
//                .thenReturn(Mono.just(mockAmdocsResponse));
//        when(mapper.writeValueAsString(any())).thenReturn("");
//       Mono<DeviceEpcDto> result = epcService.fetchProductOffering("mockToken", "testEnv", searchRequest);
//
//       assertNotNull(result.block());
//   }

    @Test
    void testRetrieveDocumentId_EmptyResponse() {
        AmdocsSearchResponse response = new AmdocsSearchResponse();
        response.setDocuments(Collections.emptyList());

        String result = epcService.retrieveDocumentId(response);
        assertTrue(result.isEmpty());
    }

    @Test
    void testReturnGenericKeyMap_Success() {
        HashMap<String, String> epcMap = new HashMap<>();
        epcMap.put("key1", "value1");

        HashMap<String, String> result = epcService.returnGenericKeyMap(epcMap);
        assertNotNull(result);
    }

    @Test
    void testReturnDeviceEpcDTO_Success() throws IllegalAccessException {
        HashMap<String, Object> responseMap = new HashMap<>();
        responseMap.put("key1", mockProductOfferingResponse);

        DeviceEpcDto result = epcService.returnDeviceEpcDTO(responseMap);
        assertNotNull(result);
    }

    @Test
    void testConcatenateMapsIntoOne_Success() {
        Map<String, String> map1 = new HashMap<>();
        map1.put("key1", "value1");
        Map<String, String> map2 = new HashMap<>();
        map2.put("key2", "value2");

        Map<String, String> result = epcService.concatenateMapsIntoOne(List.of(map1, map2));

        assertEquals(2, result.size());
        assertEquals("value1", result.get("key1"));
        assertEquals("value2", result.get("key2"));
    }

//    @Test
//    void testGetEPCDeviceDetails_TokenServiceFailure() throws ConverterException, JsonProcessingException {
//        when(tokenService.getToken(anyString())).thenReturn(Mono.error(new RuntimeException("Token error")));
//
//        Mono<DeviceEpcDto> result = epcService.getEPCDeviceDetails("12345", "qa1","device");
//
//        StepVerifier.create(result)
//                .expectErrorMatches(throwable -> throwable instanceof CustomThrowableException && throwable.getMessage().contains("Unexpected error in generating token"))
//                .verify();
//    }

//    @Test
//    void testFetchProductOffering_ExceptionHandling() throws JsonProcessingException {
//        when(genericWebClient.callPostApi(any(), any(), any(), eq(AmdocsSearchResponse.class), any()))
//                .thenReturn(Mono.just(new AmdocsSearchResponse()));
//
//        Mono<DeviceEpcDto> result = epcService.fetchProductOffering("bearerToken", "qa1", new ProductOfferSearchRequest());
//
//        Assertions.assertNotNull(result);
//    }

//    @Test
//    void testFetchProductSpecification_ExceptionHandling() throws ConverterException, JsonProcessingException {
//        when(genericWebClient.callPostApi(any(), any(), any(), eq(ProductOfferingResponse.class), any()))
//                .thenReturn(Mono.just(new ProductOfferingResponse()));
//
//        Mono<DeviceEpcDto> result = epcService.fetchProductSpecification("bearerToken", "qa1", "documentID");
//
//        Assertions.assertNotNull(result);
//    }

    @Test
    void testEpcMappedJson1(){
        DeviceEpcDto deviceEpcDto = new DeviceEpcDto();
        deviceEpcDto.setActiveFlag("True");
        HashMap<String,String> genericKeyMap = new HashMap<>();
        genericKeyMap.put("activeFlag","activeFlag");
        when(runTimeMapInitializer.getAuthorizationMap("Device")).thenReturn(genericKeyMap);
        Mono<HashMap<String,String>> map = epcService.getEpcMappedJson1(deviceEpcDto,"Device");
        Assertions.assertEquals(Objects.requireNonNull(map.block()).size(), 1);
     }



    public ProductOfferSearchRequest createSearchRequest(String sorId) throws JsonProcessingException, ConverterException {
        ProductOfferSearchRequest request = JsonToObjectConverter.jsonToObject(AmdocsConstants.AMDOCS_DOCUMENT_SEARCH_JSON, ProductOfferSearchRequest.class);
        request.getItem().getOr().get(0).setText("\"" + sorId + "\"");
        request.getItem().getOr().get(1).getCriteria().getFilterCondition().getCondition().getValues().set(0,sorId);
        return request;
    }
}