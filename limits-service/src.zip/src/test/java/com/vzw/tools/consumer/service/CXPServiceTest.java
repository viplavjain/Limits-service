package com.vzw.tools.consumer.service;

import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.JsonNode;
import com.vzw.tools.consumer.configuration.CXPConfiguration;

import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(MockitoJUnitRunner.class)
class CXPServiceTest {

	@Mock
	private CXPConfiguration cxpConfiguration;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@InjectMocks
	CXPService cxpService;

	@Mock
	WebClient webClient;

	@Mock
	WebClient.RequestBodyUriSpec requestBodyUriSpec;

	@SuppressWarnings("rawtypes")
	@Mock
	WebClient.RequestHeadersSpec requestHeadersSpec;

	@Mock
	WebClient.RequestBodySpec requestBodySpec;

	@Mock
	WebClient.ResponseSpec responseSpec;

	@SuppressWarnings("unchecked")
	@ParameterizedTest
	@ValueSource(strings = {"Device","Accessory"})
	void testGetCXPCatalogDetails(String productType) {
		when(webClient.post()).thenReturn(requestBodyUriSpec);
		when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
		when(requestBodySpec.headers(any())).thenReturn(requestBodySpec);
		when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
		when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
		when(responseSpec.bodyToMono(ArgumentMatchers.<Class<String>>notNull())).thenReturn(Mono.just("resp"));
		when(cxpConfiguration.getAPIUrl(anyString()))
				.thenReturn("https://oa.verizon.com/b6vv-cxp-customerprofile/b6vv/qa1/catalog/catalogRefData");
		when(cxpConfiguration.getHeader()).thenReturn(new HttpHeaders());
		StepVerifier.create(cxpService.getCXPCatalogDetails("123", productType, "qa1")).expectError().verify();
	}

	@SuppressWarnings("unchecked")
	@ParameterizedTest
	@ValueSource(strings = {"Device","Default"})
	void testGetCXPCatalogDetailsError(String productType) {
		when(webClient.post()).thenReturn(requestBodyUriSpec);
		when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
		when(requestBodySpec.headers(any())).thenReturn(requestBodySpec);
		when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
		when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
		when(responseSpec.bodyToMono(ArgumentMatchers.<Class<String>>notNull())).thenReturn(Mono.just("resp"));
		when(cxpConfiguration.getAPIUrl(anyString()))
				.thenReturn("https://oa.verizon.com/b6vv-cxp-customerprofile/b6vv/qa1/catalog/catalogRefData");
		Mono <JsonNode> monoResp = cxpService.getCXPCatalogDetails("123", productType, "qa1");
		assertNull(monoResp);
	}
}
