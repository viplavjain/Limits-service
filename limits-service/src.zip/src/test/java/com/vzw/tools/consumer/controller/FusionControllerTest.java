package com.vzw.tools.consumer.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.tools.consumer.controller.FusionController;
import com.vzw.tools.consumer.entity.FusionResponse;
import com.vzw.tools.consumer.service.FusionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

class FusionControllerTest {

    @InjectMocks
    FusionController fusionController;

    @Mock
    FusionService fusionService;
    private WebTestClient webTestClient;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        webTestClient = WebTestClient.bindToController(fusionController).build();
    }

    @Test
    void testFusionController() {
        String sorId = "12345";
        String env = "test";
        String productType = "device";
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonNode = objectMapper.createObjectNode();
        when(fusionService.getFusionServiceDetails(any(), any(),any())).thenReturn(Mono.just(jsonNode));
        webTestClient.get()
                .uri("/fusion/{productType}/{env}?id={sorId}", productType, env, sorId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectBody(JsonNode.class);
    }

}
