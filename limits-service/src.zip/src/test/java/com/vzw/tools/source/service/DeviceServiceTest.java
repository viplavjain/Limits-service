package com.vzw.tools.source.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.tools.FederatedCatalogToolsMsApplication;
import com.vzw.tools.common.exception.ConverterException;
import com.vzw.tools.common.exception.DataBaseException;
import com.vzw.tools.common.exception.ErrorBuilder;
import com.vzw.tools.common.util.JsonToObjectConverter;
import com.vzw.tools.source.configuration.RunTimeMapInitializer;
import com.vzw.tools.source.dao.AccessoryDMDDAO;
import com.vzw.tools.source.dao.DeviceDMDFamilyDAO;
import com.vzw.tools.source.dao.DeviceDPIDAO;
import com.vzw.tools.source.dto.AccessorySourceDto;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.modelmapper.config.Configuration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.HashMap;
import java.util.Map;

import static com.vzw.tools.cache.constant.ElasticServiceConstants.DEVICE;
import static com.vzw.tools.common.constant.CommonConstants.EMPTY_STRING;
import static com.vzw.tools.common.constant.SQLQueryConstants.ACCESSORY;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
@ContextConfiguration(classes = FederatedCatalogToolsMsApplication.class)
class DeviceServiceTest {

    @InjectMocks
    private DeviceService deviceService;

    @Mock
    private DMDService dmdService;

    @Mock
    private DPIService dpiService;

    @Spy
    private ModelMapper modelMapper;

    @Mock
    private RunTimeMapInitializer runTimeMapInitializer;

    @Mock
    private ErrorBuilder errorBuilder;

    JsonNode dmdDeviceSourceJsonNode;

    DeviceDPIDAO dpiDeviceDPIDao;

    DeviceDMDFamilyDAO deviceDMDFamilyDAO;

    @BeforeEach
    void setUp() throws ConverterException {
        dmdDeviceSourceJsonNode= JsonToObjectConverter.jsonToObject("dmd_deviceResponse.json", JsonNode.class);
        dpiDeviceDPIDao= JsonToObjectConverter.jsonToObject("deviceDPIResponse.json", DeviceDPIDAO.class);
        deviceDMDFamilyDAO= JsonToObjectConverter.jsonToObject("dmdFamilyDao.json", DeviceDMDFamilyDAO.class);
    }

    @Test
    void testGetDeviceSourceSuccess() throws Exception {
        String sorId = "123";
        String productType = "Device";
        Configuration configuration = mock(Configuration.class);
        when(modelMapper.getConfiguration()).thenReturn(configuration);

        // Mock DMD JSON Node
        when(dmdService.getDMDDetails(sorId, productType)).thenReturn(Mono.just(dmdDeviceSourceJsonNode));

        // DPI
        when(dpiService.getDPIDeviceDetails(any(), any(), any())).thenReturn(Mono.just(dpiDeviceDPIDao));

        // DMD Device Family
        when(dmdService.getDMDDeviceFamilyDao(sorId)).thenReturn(Mono.just(deviceDMDFamilyDAO));

        // Map
        HashMap<String, String> sourceMap = new HashMap<>();
        sourceMap.put("SKU", "SKU");
        when(runTimeMapInitializer.getSourceMap(productType)).thenReturn(sourceMap);

        StepVerifier.create(deviceService.getDeviceSource(sorId, productType))
                .assertNext(map -> assertTrue(map.containsKey("SKU")))
                .verifyComplete();
    }

    @Test
    void testGetSourceMappedJsonForDevice() throws DataBaseException {
        String sorId = "456";
        String productType = DEVICE;

        Map<String, String> mockMap = Map.of("k", "v");
        DeviceService spyService = spy(deviceService);
        doReturn(Mono.just(mockMap)).when(spyService).getDeviceSource(sorId, productType);

        StepVerifier.create(spyService.getSourceMappedJson(sorId, productType))
                .expectNext(mockMap)
                .verifyComplete();
    }

    @Test
    void testGetSourceMappedJsonFromDto() {
        AccessorySourceDto dto = new AccessorySourceDto();
        dto.setProdCode1("RET");
        HashMap<String, String> sourceMap = new HashMap<>();
        sourceMap.put("prodCode1", "prodCode1");

        DeviceService spyService = spy(deviceService);

        when(runTimeMapInitializer.getSourceMap(ACCESSORY)).thenReturn(sourceMap);

        Map<String, String> result = spyService.getSourceMappedJsonFromDTO(dto, ACCESSORY);
        Assertions.assertEquals("RET", result.get("prodCode1"));
    }

    @Test
    void testGetSourceMappedJsonFromDtoThrowsRuntimeException() {
        AccessorySourceDto dto = new AccessorySourceDto();
        dto.setProdCode1("RET");

        DeviceService spyService = spy(deviceService);

        when(runTimeMapInitializer.getSourceMap(ACCESSORY)).thenThrow(new RuntimeException("Mock XML error"));
        assertThrows(RuntimeException.class, () -> spyService.getSourceMappedJsonFromDTO(dto, ACCESSORY));

    }

    @Test
    void testfetchAndPopulateDMDDetailsForACC() throws DataBaseException {
        String sorId = "789";
        String productType = ACCESSORY;
        AccessoryDMDDAO accessoryDMDDAO = new AccessoryDMDDAO();
        accessoryDMDDAO.setProdCode1("RET");
        when(dmdService.getDMDDao(sorId, productType)).thenReturn(Mono.just(accessoryDMDDAO));
        Mono<AccessoryDMDDAO> accessoryDMDDAOMono= deviceService.fetchAndPopulateDMDDetailsForACC(sorId, productType);
        accessoryDMDDAOMono.subscribe(dmdresult ->
                Assertions.assertEquals("RET", dmdresult.getProdCode1()));
    }

    @Test
    void testfetchAndPopulateDMDDetailsForACCThrowsException() throws DataBaseException {
        String sorId = "789";
        String productType = ACCESSORY;
        AccessoryDMDDAO accessoryDMDDAO = new AccessoryDMDDAO();
        accessoryDMDDAO.setProdCode1("RET");
        when(dmdService.getDMDDao(sorId, productType)).thenThrow(new RuntimeException("Mock XML error"));
        assertThrows(RuntimeException.class, () -> deviceService.fetchAndPopulateDMDDetailsForACC(sorId, productType));
    }

    @Test
    void getAccessorySourceDto() {
        String sorId = "789";
        String productType = "Accessory";
        AccessoryDMDDAO accessoryDMDDAO = new AccessoryDMDDAO();
        accessoryDMDDAO.setProdCode1("RET");
        DeviceDPIDAO deviceDPIDAO = new DeviceDPIDAO();
        deviceDPIDAO.setEdgeSku("sku");
        DeviceService spyDeviceService = spy(deviceService);
        doReturn(Mono.just(accessoryDMDDAO)).when(spyDeviceService).fetchAndPopulateDMDDetailsForACC(sorId, productType);
        when(dpiService.getDPIDeviceDetails(sorId,productType,EMPTY_STRING)).thenReturn(Mono.just(deviceDPIDAO));
        Mono<AccessorySourceDto> accessorySourceDtoMono= spyDeviceService.getAccessorySourceDto(sorId, productType);
        accessorySourceDtoMono.subscribe(Assertions::assertNotNull);
    }

    @Test
    void testGetSourceMappedJsonMapFromDtoThrowsRuntimeException() {
        Map<String,String> sourceMap = new HashMap<>();
        sourceMap.put("prodCode1", "prodCode1");
        String productType = "Device";
        DeviceService spyService = spy(deviceService);

        when(runTimeMapInitializer.getSourceMap(productType)).thenThrow(new RuntimeException("Mock XML error"));
        assertThrows(RuntimeException.class, () -> spyService.getSourceMappedJson(sourceMap, productType));

    }

    @Test
    void testErrorHandlingWithInvalidJson() throws Exception {
        String sorId = "999";
        String productType = DEVICE;
        JsonNode invalidNode = new ObjectMapper().readTree("\"unparseable\"");

        when(dmdService.getDMDDetails(sorId, productType)).thenReturn(Mono.just(invalidNode));

        StepVerifier.create(deviceService.getDeviceSource(sorId, productType))
                .expectError(NullPointerException.class)
                .verify();
    }

    @Test
    void testgetSourceMappedJson() throws DataBaseException {
        String productType = "Accessory";
        String sorId = "999";
        AccessorySourceDto dto = new AccessorySourceDto();
        dto.setProdCode1("RET");
        HashMap<String, String> sourceMap = new HashMap<>();
        sourceMap.put("prodCode1", "prodCode1");

        DeviceService spyDeviceService = spy(deviceService);
        doReturn(Mono.just(dto)).when(spyDeviceService).getAccessorySourceDto(sorId, productType);
        Mockito.lenient().when(runTimeMapInitializer.getSourceMap(productType)).thenReturn(sourceMap);
        Mono<Map<String, String>> hashMap = spyDeviceService.getSourceMappedJson(sorId, productType);
        hashMap.subscribe(result -> Assertions.assertEquals("RET", result.get("prodCode1")));
    }

}
